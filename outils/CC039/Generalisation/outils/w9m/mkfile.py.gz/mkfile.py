#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
# 
#****************************    Fiche signaletique shell  encodage: iso-8859-15    ****************************************    #
# Nom du programme : mkfile.py    But du programme : Creation de fichiers et repertoires - Version minimum de python : 2.4
#***********************************************    Syntaxe    **************************************************************   #
# mkfile.py -t <type> -d target_directory -n name [-v]
#**********************************************    Historique    *************************************************************  #
# Version       Date            AUTEUR          ENTREPRISE      Commentaires
# 1.0           03/09/2015      R.SAVIGNY       GER - PIXON     Creation
#
#**********************************************    Codes retour    ***********************************************************  #
# code 0: Normal - Code retour normal : L enchainement est poursuivi
# code 1: Warning - Detection d une anomalie : L enchainement peut etre poursuivi
# code 2: Erreur - Erreur Non bloquante : possibilite de lancer une procedure de reprise
# code 3: Critique - Erreur Critique
# code 3: Exemple d erreur - Erreur parametres incorrects
# code > 3 : Traitement en erreur avec un code retour particulier
#*****************************************************************************************************************************  #

# -------------------------
# Import des modules python
# -------------------------
import os
import sys
import getopt
import os.path
import glob
import string
import shutil
import datetime
import time


# -------------------------

# Definition des variables systeme
__SYSTEM = sys.platform
__PYTHON_VERSION = sys.version

# Version du CC a completer
version = "mkfile.py v1.0 - python "+__PYTHON_VERSION+" - "+__SYSTEM

# code retour ordo
vg_bl=3
vg_wg=1
vg_ok=0
vg_f_exist=0

#*****************************************************************************************************************************  #
# Variables globales
#*****************************************************************************************************************************  #
vg_file_type=None
vg_file_name=None
vg_file_range=None
vg_sep_range=None
vg_deb_range=None
vg_fin_range=None
vg_target_dir=None
vg_date=None
vg_short=False
vg_verbeux=False
vg_force=False
vg_secure=False

#*****************************************************************************************************************************  #
# Definitions des procedures locales
#*****************************************************************************************************************************  #
def p_print_usage(err):
#   Affiche le message d utilisation du script
    print r"""
    Usage de la commande : 
    mkfile.py -t <type> -d <repertoire(s) clible(s)> -n <nom>

    Parametres obligatoires :
            [-t <type>] : Fichier "f", repertoire "r"
            [-d <repertoire>] : Un ou plusieurs repertoire(s) cible(s). Liste separee par des ',' ou REGEX
            [-n <nom>] : Nom du fichier
            [-r <sep>,<num debut>,<num fin>] : Ajout un indice au nom du fichier (ex: -r -,1,20)
                                               Si la chaine "RANGE" est trouvee dans le nom, elle est remplacee par l'indice
                                               Sinon l'indice est place a la fin du nom du fichier
                               <sep> : Separateur entre le nom du fichier et l'indice (carateres acceptes : vide (aucun separateur), ".", "-", "_" 
                         <num debut> : Debut du RANGE d'indice
                           <num fin> : Fin du RANGE d'indice

    Parametres optionnels :
            [--short] :	Passe le TIMESTAMP en format court (AAAAMMJJ)
            [-w] (desactive le mode secure)
                 (A utiliser dans le cas ou les dossiers ne contiennent pas les chaines de caracteres suivantes :
                    TEMP, TMP, TRACE, LOG, DONNEE, DUMP, AUDIT, TRANSFERT,
                    TRAVAIL, SVDB, EXPORT, IMPORT, DATA, DIAG, SAS, ENVOI, RECU
                    BACKUP, BKP)

    La chaine TIMESTAMP est valorisee UNIQUEMENT dans le cas des fichiers (-t f)
    Par defaut le format est le suivant : AAAAMMJJHHMMSS

    Sous UNIX / Linux les caracteres speciaux "*", "?", "[", "]" doivent etre precedes par le caractere "\"
    Exemples :
       La REGEX : l5x[at]aa?a.de    doit etre ecrite ainsi : l5x\[at\]aa\?a.de
       La REGEX : file*             doit etre ecrite ainsi : file\*

    [-h | --help] (produit l'aide suivante)
    [-v] (verbose - permet de debugger)
    [-B | --bouchon] <code_retour> (utilise par le CCO)
    [-f | --force] Force l'ecrasement des fichiers cibles s'ils existent deja
    """
    p_error(err)

def p_param_commande():
    p_debug("p_param_commande()")
    # Gestion des arguments passes en parametre de la ligne de commandes

    global vg_file_type
    global vg_file_name
    global vg_file_range
    global vg_target_dir
    global vg_output_file
    global vg_date
    global vg_short
    global vg_verbeux
    global vg_force
    global vg_secure

    print "Initialisation des parametres : "
    ind_t = ind_d = ind_n = ind_r = 0
    try:
        opts, args = getopt.getopt(sys.argv[1:], "t:d:n:r:hvfwB:", ["help","bouchon=","short", "force"])

    except getopt.GetoptError, err:
        print "!!! ERREUR !!! l'option n'est pas reconnue : " + str(err)
        p_print_usage(vg_bl)

    for o, a in opts:
        p_debug("Option, Argument : "+o+", "+a)
        if o == ("-v"):
            vg_verbeux = True
            p_debug("Mode verbeux actif")
        elif o in ("-h", "--help"):
            p_print_usage(vg_bl)
        elif o in ("-B", "--bouchon"):
            p_debug("Mode bouchon")
            p_error(int(a))
        elif o in ("-f", "--force"):
            p_debug("Mode force actif")
            vg_force = True
        elif o == ("-t"):
            if ind_t >= 1 :
                print "Parametre -t en double ..."
                p_error(vg_bl)
            if (a == "f" or a == "r") :
                vg_file_type = a
            else:
                print "L'argument \""+a+"\" n'est pas valide pour l'option \"-t\""
                p_error(vg_bl)
            p_debug("Type de fichier a creer : " + str(vg_file_type))
            ind_t +=1
        elif o == ("-d"):
            if ind_d >= 1 :
                print "Parametre -d en double ..."
                p_error(vg_bl)
            vg_target_dir = a
            p_debug("Repertoire cible : " + str(vg_target_dir))
            ind_d +=1
        elif o == ("-n"):
            if ind_n >= 1 :
                print "Parametre -n en double ..."
                p_error(vg_bl)
            vg_file_name = a
            p_debug("Nom du fichier : " + str(vg_file_name))
            ind_n +=1
        elif o == ("-r"):
            if ind_r >= 1 :
                print "Parametre -r en double ..."
                p_error(vg_bl)
            vg_file_range = a
            p_debug("Parametres du range : " + str(vg_file_range))
            ind_n +=1
        elif o == ("--short"):
            vg_short = True
            p_debug("TIMESTAMP mode short actif")
        elif o == ("-w"):
            vg_secure = False
            p_debug("Mode secure actif")
        else:
            assert False, "Option invalide !!!"
    p_test_options() # Verifie les param obligatoires
    return True

def p_test_options():
    p_debug("p_test_options()")
    global vg_sep_range
    global vg_deb_range
    global vg_fin_range
    print "Test des arguments passes en entree du script... "
    if (vg_file_type == None or vg_target_dir == None or vg_file_name == None) :
        print "*** un argument est manquant ***"
        p_print_usage(vg_bl)
    if vg_file_type == "r" and vg_short == True :
        print "l'option \"--short\" est incompatible avec l'option \"-d\""
        p_print_usage(vg_bl)
    if vg_file_range <> None :
        sep_autorise=['.','-','_','']
        lst_range = vg_file_range.split(",")
        vg_sep_range=lst_range[0]
        vg_deb_range=lst_range[1]
        vg_fin_range=lst_range[2]
        if (vg_sep_range not in sep_autorise) :
            print "le separateur \""+vg_sep_range+"\" n'est pas autorise pour l'option \"-r\""
            p_print_usage(vg_bl)
        if not vg_deb_range.isdigit() :
            print "la valeur debut du range \""+vg_deb_range+"\" n'est pas un nombre entier\""
            p_print_usage(vg_bl)
        if not vg_fin_range.isdigit():
            print "la valeur fin du range \""+vg_fin_range+"\" n'est pas un nombre entier\""
            p_print_usage(vg_bl)
        if vg_deb_range > vg_fin_range :
            print "la valeur debut du range \""+deb_range+"\" est superieure � la valeur fin du range \""+fin_range+"\""
            p_print_usage(vg_bl)
    if vg_verbeux :  print ("Les parametres obligatoires sont renseignes")

def p_debug(chaine):
    if vg_verbeux == True : print str(chaine)

def p_error(num):
    # retourne le message d erreur et sort en code retour
    print "Sortie en code retour " + str(num)
    sys.exit(num)

def p_var_system(chemin): # permet de valoriser des $ sous unix ou % sous windows
    p_debug("p_var_system("+chemin+")")
    resultat = os.path.expandvars(chemin)
    p_debug("Resultat de la valorisation " + str(resultat))
    return resultat

def p_verif_chemin_dangeureux(chemin,secure) :
    p_debug("p_var_system("+chemin+", "+str(secure)+")")
    Erreur = False
    if secure == True :
        if "TEMP"  in str(string.upper(chemin)) :
            Erreur = True
        if "TMP" in str(string.upper(chemin)) :
            Erreur = True
        if "TRACE" in str(string.upper(chemin)) :
            Erreur = True
        if "LOG" in str(string.upper(chemin)) :
            Erreur = True
        if "DONNEE" in str(string.upper(chemin)) :
            Erreur = True
        if "DUMP" in str(string.upper(chemin)) :
            Erreur = True
        if "AUDIT" in str(string.upper(chemin)) :
            Erreur = True
        if "TRANSFERT" in str(string.upper(chemin)) :
            Erreur = True
        if "TRAVAIL" in str(string.upper(chemin)) :
            Erreur = True
        if "SVDB" in str(string.upper(chemin)) :
            Erreur = True
        if "IMPORT" in str(string.upper(chemin)) :
            Erreur = True
        if "EXPORT" in str(string.upper(chemin)) :
            Erreur = True
        if "DATA" in str(string.upper(chemin)) :
            Erreur = True
        if "DIAG" in str(string.upper(chemin)) :
            Erreur = True
        if "SAS" in str(string.upper(chemin)) :
            Erreur = True
        if "ENVOI" in str(string.upper(chemin)) :
            Erreur = True
        if "RECU" in str(string.upper(chemin)) :
            Erreur = True
        if "BACKUP" in str(string.upper(chemin)) :
            Erreur = True
        if "BKP" in str(string.upper(chemin)) :
            Erreur = True
        if Erreur == False :
            print "Le chemin n est pas un dossier de traces, logs, temps, donnees, dump, audit, travail, transfert, svdb, import, export, data, diag, sas, envoi, recu, backup, bkp. Utiliser l'option -w"
            p_error(vg_bl)

#*****************************************************************************************************************************  #
# Definitions des fonctions locales
#*****************************************************************************************************************************  #
def f_set_timestamp():
    p_debug("f_set_timestamp()")
    # retourne un timestamp au format chaine de caractere
    # ajout des option de format de timestamp
    today = datetime.datetime.now()
    resultat = str(today.strftime("%Y%m%d%H%M%S"))
    if vg_short == True :
        resultat = str(today.strftime("%Y%m%d"))
    return resultat

def f_replace_timestamp(file_name):
    p_debug("f_replace_timestamp("+file_name+")")
    # Valorise la chaine TIMESTAMP si pr�sente dans la chaine
    p_debug("Recherche de la chaine \"TIMESTAMP\" dans le nom de fichier")
    if file_name <> None :
        p_debug("traitemenent de la variable TIMESTAMP dans le nom de fichier")
        while "TIMESTAMP" in file_name :
            file_name = file_name.replace("TIMESTAMP", f_set_timestamp())
    return file_name

def f_file_range(file_name):
    p_debug("f_file_range("+file_name+")")
    # Valorise la chaine RANGE si pr�sente dans la chaine
    p_debug("Recherche de la chaine \"RANGE\" dans le nom de fichier")
    global vg_sep_range
    global vg_deb_range
    global vg_fin_range
    file_list=[]
    p_debug("traitemenent de la variable RANGE dans le nom de fichier")
    for i in range(int(vg_deb_range), int(vg_fin_range)+1) :
        if "RANGE" in file_name :
            file_name_tmp = file_name.replace("RANGE", vg_sep_range+str(i))
            file_list.append(file_name_tmp)
        else :
            file_list.append(file_name+vg_sep_range+str(i))
    return file_list

def f_list_dir(path):
    p_debug("f_list_dir("+path+")")
    lst_dir=[] # liste retournee
    for file in glob.glob(path) :
        if os.path.isdir(file) : lst_dir.append(file)
    p_debug("Liste des repertoires : " + str(lst_dir))
    return lst_dir

def f_verif_dir(dossier): # sort en erreur dans le cas ou le dossier n existe pas
    p_debug("f_verif_dir("+dossier+")")
    if os.path.exists(dossier) == False :
        print "Erreur dossier : " + str(dossier) + " absent"
        p_error(vg_bl)
    if os.access(dossier,os.R_OK) == False :
        print "Erreur de droits !!! le dossier ne peut-etre lu : " + str(dossier)
        p_error(vg_bl)

def f_mkfile(list_dir, list_name):
    p_debug("f_mkfile("+str(list_dir)+", "+str(list_name)+")")
    global vg_file_type
    global vg_f_exist
    print("Debut de la creation des fichiers")
    for dir in list_dir :
        for name in list_name :
            if vg_file_type == "r" :
                if name != None :
                    fichier=dir+os.sep+name
                else :
                    fichier=dir
                if (not os.path.exists(fichier) or vg_force == True) :
                    try:
                        os.mkdir(dir+os.sep+name)
                    except:
                        print("Warning : Le repertoire \""+fichier+"\" n'a pas pu etre cree")
                        pass
                else :
                        print("Warning : Le repertoire \""+fichier+"\" exite deja, il est ignore")
                        vg_f_exist=1

            if vg_file_type == "f" :
                if name != None :
                    repertoire=dir+os.sep+name
                else :
                    repertoire=dir
                if (not os.path.exists(repertoire) or vg_force == True) :
                    try:
                        os.system('touch '+dir+os.sep+name)
                    except:
                        print("Warning : Le fichier \""+repertoire+"\" n'a pas pu etre cree")
                        pass
                else :
                        print("Warning : Le fichier \""+repertoire+"\" exite deja, il est ignore")
                        vg_f_exist=1
    return True


#*****************************************************************************************************************************  #
# definition des fonctions par system d exploitation
#*****************************************************************************************************************************  #

def lancement_windows():

    global vg_target_dir
    global vg_file_type
    global vg_file_name

    #*************************************************************************************************************************  #
    # fabrique la liste des repertoires cibles
    #*************************************************************************************************************************  #
    # Creation liste des targets dir
    lst_dir=[]
    lst_target_dir=[]
    if ',' in vg_target_dir :
        lst_dir = vg_target_dir.split(",")
    else :
        lst_dir.append(vg_target_dir)

    # fabrique la liste des repertoires cibles
    for target_dir in lst_dir : 
        lst_target_dir.extend(f_list_dir(target_dir))
    p_debug("liste des repertoires a traiter : " + str(lst_target_dir))

    # Valorise les variables d environnement system
    lst_var_env_dir=[]
    for target_dir in lst_target_dir : 
        lst_var_env_dir.append(p_var_system(target_dir))

    # verification de l existence des dossiers cibles
    for target_dir in lst_var_env_dir :
        f_verif_dir(target_dir)
        p_verif_chemin_dangeureux(target_dir, vg_secure)

    # liste dir finale
    lst_target_dir = lst_var_env_dir

    #*************************************************************************************************************************  #
    # fabrique la liste des noms cibles
    #*************************************************************************************************************************  #
    # Traitement TIMESTAMP dans le nom de fichier
    if vg_file_type == "f" : vg_file_name = f_replace_timestamp(vg_file_name)
        
    # Traitement option RANGE pour les noms de fichiers
    lst_name=[]
    if vg_file_range != None :
        lst_name=f_file_range(vg_file_name)
    else :
        lst_name.append(vg_file_name)
        
    # execute la creation
    if (f_mkfile(lst_target_dir, lst_name) == True):
        code_retour_fonction = 0

    # retourne le code retour de l execution de la commande
    return code_retour_fonction

def lancement_hpux():
    return lancement_windows()

def lancement_solaris():
    return lancement_windows()

def lancement_linux():
    return lancement_windows()

#*****************************************************************************************************************************  #
# Main
#*****************************************************************************************************************************  #
if __name__ == "__main__":
    # Variables du programme principal
    
    # Affiche la version
    print version + "\n"
    
    # Affiche la commande lancee
    print "Execution de la commande : " + str(sys.argv)

    #*****************************************************************************************************************************  #
    # Lancement de la commande selon la plateforme utilisee
    #*****************************************************************************************************************************  #

    if __SYSTEM == "win32":
            if (p_param_commande() != True):
                p_error(vg_bl)
            code_retour = lancement_windows()
    elif __SYSTEM == "hp-ux11":
            if (p_param_commande() != True):
                p_error(vg_bl)
            code_retour = lancement_hpux()
    elif __SYSTEM == "linux2":
            if (p_param_commande() != True):
                p_error(vg_bl)
            code_retour = lancement_linux()
    elif __SYSTEM == "solaris":
            if (p_param_commande() != True):
                p_error(vg_bl)
            code_retour = lancement_solaris()
    else:
            print "Plateforme inconnue - sortie en CR 3"
            p_error(vg_bl)


    #######################################
    # Verification du code retour         #
    #######################################
    if code_retour not in (0, None):
            print "ping: Erreur inattendue - sortie en CR 3"
            p_error(vg_bl)
    if vg_f_exist != 0 : code_retour = vg_f_exist
    #######################################
    # Fin du Programme avec code_retour   #
    #######################################
    print "Fin du programme - code retour : " + str(code_retour)
    sys.exit(code_retour)
