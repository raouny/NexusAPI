#!/usr/bin/python
# -*- coding: iso-8859-15 -*-

#****************************    Fiche signaletique shell  encodage: iso-8859-15    ****************************************    #
# Nom du programme : zippy.py    But du programme : zipper     Version minimum de l'interpreteur python : 2.4
#***********************************************    Syntaxe    **************************************************************   #
#                      zip.py file
#**********************************************    Historique    *************************************************************  #
# Version       Date            AUTEUR          ENTREPRISE      Commentaires
# 1.0          21/01/2013       Y.HERVE         La Poste        Creation
# 1.1          21/04/2015       R.SAVIGNY       PIXON           Gestion des REGEX pour l'option "-i" lors de la decompression
#                                                               correction option "--debugg" => "--debug"
# 1.2          30/06/2015       R.SAVIGNY       PIXON           Correction : sys.version_info
# 1.3          12/08/2015       R.SAVIGNY       PIXON           I08079305  : Prise en compte fichier deja zippe (non pertinante)
#                                                               Correction : Repertoire est cree la ou est lance le script
#                                                               Detail de l'utilisation des caracteres speciaux sous unix/linux
# 1.4          12/08/2015       R.SAVIGNY       PIXON           I08090296  : De-compression de fichier > 3Go
#**********************************************    Codes retour    ***********************************************************  #
# code 0: Normal - Code retour normal : L enchainement est poursuivi
# code 1: Warning - Detection d une anomalie : L enchainement peut etre poursuivi
# code 2: Warning - Detection d une anomalie : L enchainement peut etre poursuivi
# code 3: Critique - Erreur Critique
#*****************************************************************************************************************************  #

# Import des modules python
import os
import os.path
import glob
import sys
import getopt
import platform
import subprocess
#import ctypes deplace en fin de code pour compatibilite os
import zipfile

# Definition des variables systeme
__SYSTEM = sys.platform
__PYTHON_VERSION = sys.version


# Definition des variables

vg_file_zip = None
vg_filtre = "*"
vg_compress = None
vg_decompress = None
vg_liste = False
vg_force = False
vg_path_to_zip = None
vg_path_to_dezip = None
vg_stored_mode = False
vg_recursif_mode = False
vg_verbeux = False # Mode Verbeux permet un debugage plus precis / l option -v n affiche pas les parametres en entree


# Variables globales des code retour
vg_bl=3
vg_wg=1
vg_ok=0


# Version du CC a completer
version = "zippy.py v1.4 - python "+__PYTHON_VERSION+" - "+__SYSTEM

#*****************************************************************************************************************************  #
# Definitions des fonctions locales
#*****************************************************************************************************************************  #

#*****************************************************************************************************************************  #
# Fonction de test de presence de l argument obligatoire
#*****************************************************************************************************************************  #
def p_test_options():
        p_debug("Test des arguments passes en entree du script ... ")
        if (( vg_file_zip  == None) and ((vg_compress == None) or (vg_decompress == None) or (vg_liste == False))):
            print "*** au moins un argument est manquant ***"
            f_printusage(vg_bl)
        p_debug("Les parametres obligatoires sont renseignes")


#*****************************************************************************************************************************  #
# Fonction d'aide a l utilisation du script
#*****************************************************************************************************************************  #

def f_printusage(err):
#   Affiche le message d utilisation du script
    print r"""
    Usage de la commande :
    Compression
    zippy.py -i fichier.zip -c Chemin du dossier a zipper [-f filtre (exemple *.txt)] [-R prend en compte les sous-dossiers]

    Decompression
    zippy.py -i fichier.zip -d Destination de la decompression [--force (creer le dossier si inexistant)]
    zippy.py -i fichier_\[1-5\].zip -d Destination (match "fichier_1.zip" jusqu a "fichier_5.zip")
    zippy.py -i fichier_\*.zip -d Destination (match : commencant par "fichier_" et finissant par ".zip")
    zippy.py -i fichier_\?.zip -d Destination (meme matching que precedement avec 1 seul caractere entre debut et fin)

    Liste le contenu du zip
    zippy.py -i fichier.zip -l

            parametres obligatoires :
                [-i]                               : Nom du fichier zip (extention .zip non obligatoire)
                [-c ou --compress]                 : compression du dossier place en argument
           ou   [-d ou --decompress]               : decompression du zip dans le dossier place en argument
           ou   [-l ou --liste]                    : liste le contenu du fichier zip


            parametres facultatifs :
                [-f ou --filtre]                   : filtre le contenu du dossier en mode compression compatible avec le mode recursif
                [-R ou --recursif]                 : compresse egalement les sous-dossiers
                [-S ou --stored]                   : sans compression
                [--force]                          : en mode compression ecrase le fichier zip si existant
                [--force]                          : en mode decompression creer le dossier si inexistant

                [-B ou --bouchon=]      : mode bouchon utilise par le CCO
                [--help]                : affiche l'aide
                [--debug]              : mode "verbeux" debug

            Sous UNIX / Linux les caracteres speciaux "*", "?", "[", "]" doivent etre precedes par le caractere "\"
            Exemples :
               La REGEX : l5x[at]aa?a.de    doit etre ecrite ainsi : l5x\[at\]aa\?a.de
               La REGEX : file*             doit etre ecrite ainsi : file\*

    """
    p_print_error("",err)


#*****************************************************************************************************************************  #
# Fonction de gestion des erreurs
#*****************************************************************************************************************************  #

def p_print_error(mesg, num):
    # retourne le message d erreur et sort en fonction du code retour
    print mesg
    print "Sortie en code retour " + str(num)
    sys.exit(num)


#*****************************************************************************************************************************  #
# Fonction de gestion des arguments passes en parametre de la ligne de commandes
#*****************************************************************************************************************************  #

def f_param_lg_commande():

    global vg_file_zip
    global vg_path_to_zip
    global vg_filtre
    global vg_path_to_dezip
    global vg_compress
    global vg_decompress
    global vg_force
    global vg_liste
    global vg_recursif_mode
    global vg_stored_mode
    global vg_verbeux  # utiliser pour le debugage


    p_debug("ligne de commande : "+ str(sys.argv) )

    #recuperation des arguments
    if (len(sys.argv) < 2) or ((len(sys.argv) == 2) and (sys.argv[1] != '-h') and (sys.argv[1] != '--help') and ('--bouchon' not in sys.argv[1])) :
        print "argument(s) manquant(s)"
        f_printusage(vg_bl)

    try:
        opts, args = getopt.getopt(sys.argv[1:], "i:c:f:d:lSRhB:", ["compress=","filtre=","decompress=","force","liste","stored","Recursif","help","bouchon=","debug"])

    except getopt.GetoptError, err:
        # print help information and exit:
        # tests des options non reconnues"
        print "!!! ERREUR !!! l option n est pas reconnue : ", str(err)
        f_printusage(vg_bl)

    #test des arguments et enrichissement des variables
    for o, a in opts:
        p_debug(str(o) +" , " + str(a))
        if o in ("-h", "--help"):
            f_printusage(3)
        elif o == ("-i"):
            vg_file_zip = a
            p_debug("nom du fichier en entree : "+ str(vg_file_zip) )
        elif o in ("-c", "--compress"):
            vg_compress = True
            p_debug("mode compression actif")
            vg_path_to_zip = a
            p_debug("Contenu a archiver : " + str(vg_path_to_zip))
        elif o in ("-f", "--filtre"):
            p_debug("mode filtre actif")
            vg_filtre = a
            p_debug("filtre a prendre en compte : " + str(vg_filtre))
        elif o in ("-d", "--decompress"):
            vg_decompress = True
            p_debug("mode decompression actif")
            vg_path_to_dezip = a
            p_debug("nom du repertoire ou sera effectuee la decompression : " + str(vg_path_to_dezip))
        elif o == ("--force"):
            vg_force = True
            p_debug("mode force actif pour creation arborescence de decompression si n'existe pas")
        elif o in ("-l", "--liste"):
            vg_liste = True
            p_debug("mode liste actif")
        elif o in ("-S", "--Stored"):
            vg_stored_mode = True
            p_debug("mode force actif")
        elif o in ("-R", "--Recursif"):
            vg_recursif_mode = True
            p_debug("mode recursif actif")
        elif o in ("-B", "--bouchon"):
            p_print_error("mode bouchon",int(a))
        elif o == ("--debug"):
            vg_verbeux = True
            p_debug("mode verbeux actif")
        else:
            assert False, "option invalide !!!"

    # test de presence des options obligatoires
    p_test_options()

    return True

def p_debug(chaine):
    if vg_verbeux : print str(chaine)

def f_get_free_space(folder):
    p_debug("f_get_free_space("+folder+")")
    # retourne l espace libre d un dossier ou disque
    if platform.system() == 'Windows':
        free_bytes = ctypes.c_ulonglong(0)
        ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(folder), None, None, ctypes.pointer(free_bytes))
        return long(free_bytes.value)
    else:
        p_debug("test place dispo sauf windows")
        stat = os.statvfs(folder)
        return long(stat.f_bsize * stat.f_bavail)

def f_calcul_assez_de_place(nom_fichier, dossier_arrivee):
    p_debug("f_calcul_assez_de_place("+nom_fichier+", "+dossier_arrivee+")")
    p_debug("Nom du dossier de destination : " + dossier_arrivee)
    total_libre = f_get_free_space(dossier_arrivee)
    p_debug("Espace disponible du dossier de destination : " + str(total_libre))
    zfile = zipfile.ZipFile(nom_fichier, 'r')
    taille_fichier=0
    for zinfo_file in zfile.infolist():
        taille_fichier +=  zinfo_file.file_size
    p_debug("Volumetrie du contenu du fichier ZIP : " + str(taille_fichier))
    if taille_fichier < total_libre :
        return True
    else :
        return False

def f_calc_files_size(liste_fichiers):
    p_debug("f_calc_files_size("+str(liste_fichiers)+")")
    size = long(0)
    for file in liste_fichiers:
        size += os.path.getsize(file) # in byt
    return long(size)

def f_listdirectory(path, filtre, mode_recursif, char_os):
    p_debug("f_listdirectory("+path+", "+filtre+", "+str(mode_recursif)+", "+char_os+")")
    fichier=[]
    if mode_recursif == "True" : print "mode recursif active"
    chemin_full = path+char_os+"*"
    l = glob.glob(chemin_full)
    # * - necessaire pour pouvoir lister la totalite en cas de recursivite
    # recup la liste des fichiers filtres dans le dossier courant
    chemin_filtre = path+char_os+filtre
    l_filtree = glob.glob(chemin_filtre)
    for i in l:
        if os.path.isdir(i):
            if mode_recursif == True :
                fichier.extend(f_listdirectory(i, filtre, mode_recursif, char_os))
                fichier.append(i)
        else:
            if i in l_filtree :
                p_debug("fichier : " + i + " ajoute")
                fichier.append(i)
    return fichier

def f_generation_liste_fichiers_en_entree(input_directory, input_file, mode_recursif, char_os):
    p_debug("f_generation_liste_fichiers_en_entree("+input_directory+", "+input_file+", "+mode_recursif+", "+char_os+")")
    # retourne la liste des fichiers a traiter
    path = input_directory + char_os + input_file
    print "Recherche des fichiers presents : " + str(path)
    # recup la liste de tous les fichiers
    list_fichiers = f_listdirectory(input_directory ,input_file, mode_recursif, char_os)
    if len(list_fichiers) != 0 :
        return list_fichiers

def p_create_zip(fichier_zip,contenu_a_archiver,vg_filtre,vg_stored_mode,vg_recursif_mode,vg_force,char_os):
    p_debug("p_create_zip("+fichier_zip+", "+contenu_a_archiver+", "+vg_filtre+", "+str(vg_stored_mode)+", "+str(vg_recursif_mode)+", "+str(vg_force)+", "+char_os+")")
    code_retour = vg_ok
    if os.path.exists(contenu_a_archiver) == False:
        p_print_error("Le dossier a archiver : " + contenu_a_archiver + " n existe pas",vg_bl)
    else:
        tab_list_fic=sorted(f_listdirectory(contenu_a_archiver, vg_filtre, vg_recursif_mode, char_os))#construction du tableau listant le contenu a archiver
        if tab_list_fic == []:
            p_print_error("Aucune donnee a archiver",vg_wg)
        else:
            #verifie l espace disponible pour la creation du zip
            if os.path.exists(fichier_zip) and not vg_force:
                p_print_error("Le fichier : " + fichier_zip + " existe deja utiliser le mode force pour l ecraser",vg_wg)
            else:
                if os.path.dirname(fichier_zip) == "":
                    rep_dest_zip = os.getcwd()
                else :
                    rep_dest_zip = os.path.dirname(fichier_zip)
                print "repertoire de destination du ZIP :", rep_dest_zip
                if rep_dest_zip in tab_list_fic:
                    p_print_error("Le zip ne peut etre cree dans l arborescence a archiver ",vg_bl)
                else:
                    espace_dispo_dest_zip = f_get_free_space(rep_dest_zip)
                    taille_contenu_a_archiver = f_calc_files_size(tab_list_fic)
                    p_debug("Espace dispo du repertoire ou va etre cree le ZIP : " + str(espace_dispo_dest_zip))
                    p_debug("Taille du contenu a archiver avant compression : " + str(taille_contenu_a_archiver))
                    if espace_dispo_dest_zip >= taille_contenu_a_archiver:
                        try:
                            if vg_stored_mode == False :
                                if __PYTHON_VERSION > '2.5':
                                    zip_file = zipfile.ZipFile(fichier_zip, 'w', zipfile.ZIP_DEFLATED,allowZip64=True)
                                else:
                                    zip_file = zipfile.ZipFile(fichier_zip, 'w', zipfile.ZIP_DEFLATED)
                            else:
                                if __PYTHON_VERSION > '2.5':
                                    zip_file = zipfile.ZipFile(fichier_zip, 'w', zipfile.ZIP_STORED,allowZip64=True)
                                else:
                                    zip_file = zipfile.ZipFile(fichier_zip, 'w', zipfile.ZIP_STORED)
                            # NE GERE PAS LES DOSSIERS VIDES SI VERSION PYTHON < 2.5.0
                            if int(sys.version_info[1]) >= 6:
                                for i in tab_list_fic:
                                    zip_file.write(i)
                            else:
                                for i in tab_list_fic:
                                    if os.path.isfile(i):
                                        zip_file.write(i)
                            print "'%s' created successfully." % fichier_zip
                            zip_file.close()
                        except IOError, message:
                            print message
                            sys.exit(vg_bl)
                        except OSError, message:
                            print message
                            sys.exit(vg_bl)
                        except zipfile.BadZipfile, message:
                            print message
                            sys.exit(vg_bl)
                    else :
                        print "Il n'y a pas assez d'espace disque disponible pour creer le fichier ZIP"
                    return code_retour

def p_extract_zip(fichier_zip,path_dest,char_os):
    p_debug("p_extract_zip("+fichier_zip+", "+path_dest+", "+char_os+")")
    code_retour = vg_ok
    global vg_bl
    if path_dest == "CURRENT":
        path_dest = os.getcwd()  ## on dezippe dans le repertoire courrant
    if os.path.exists(path_dest)==False:
        if vg_force:
            os.mkdir(path_dest)
            print "creation du repertoire :" + path_dest
        else :
            code_retour=p_print_error("Le dossier de decompression : " + path_dest + " n existe pas, mode force non actif",vg_wg)
    if os.path.isfile(fichier_zip) == False :
        p_print_error("Le fichier : " + fichier_zip + " n existe pas",vg_bl)
    else:
        try :
            if f_calcul_assez_de_place(fichier_zip, path_dest) == True:
                p_debug("f_calcul_assez_de_place("+fichier_zip+", "+path_dest+" = True")
                if __PYTHON_VERSION > '2.5':
                    p_debug("__PYTHON_VERSION > 2.5 ("+__PYTHON_VERSION+")")
                    zf = zipfile.ZipFile(fichier_zip, 'r', allowZip64=True)
                else:
                    p_debug("__PYTHON_VERSION < 2.5 ("+__PYTHON_VERSION+")")
                    zf = zipfile.ZipFile(fichier_zip, 'r')

                p_debug("Liste du contenu du fichier "+fichier_zip)
                p_debug("Namelist : "+str(zf.namelist()))
                for name in zf.namelist():
                    p_debug("Name : "+name)
                    (dirname, filename) = os.path.split(name)
                    p_debug("dirname, filename : "+dirname+", "+filename)
                    arbo=(path_dest+char_os+dirname)
                    new_arbo=arbo.replace("/", char_os)
                    file=(path_dest+char_os+name)
                    new_file=file.replace("/", char_os)
                    if filename == '':
                    # directory
                        if not os.path.exists(new_arbo):
                            try: os.mkdir(new_arbo)
                            except: pass
                    else:
                    # file
                        if not os.path.exists(new_arbo):
                            try: os.makedirs(new_arbo)
                            except: pass
                        if __SYSTEM == "linux2" :
                            p_debug("\"unzip "+fichier_zip+" "+name+" -d "+path_dest+"\"")
                            command=str("unzip "+fichier_zip+" "+name+" -d "+path_dest)
                            res = subprocess.call(command, shell=True)
                            if res != 0 and res != 1 : code_retour = res
                        else:
                            p_debug("Decompression avec la methode EXTRACT...")
                            p_debug("zf.extract("+name+", "+path_dest+")")
                            zf.extract(name, path_dest)
                    #zf.close()
            else:
                print "Il n'y a pas assez d'espace disque disponible pour extraire le fichier ZIP"
        except OSError , (errno,strerror):
            print "OSerror (", str(errno), ") : ",str(strerror)
            p_print_error ("", vg_bl)
        except IOError :
            print "IOerror : anomalie dans le ficher zip"
            p_print_error ("", vg_bl)
        except :
            p_print_error ("Erreur inconnue - sortie en code retour", vg_bl)
    return code_retour

def p_liste_zip(fichier_zip):
    p_debug("p_liste_zip("+fichier_zip+")")
    code_retour = vg_ok
    print "Debut de la fonction liste contenu du zip"
    if os.path.isfile(fichier_zip) == False :
        p_print_error("Le fichier : " + fichier_zip + " n existe pas",vg_bl)
    else:
        if __PYTHON_VERSION > '2.5':
            file = zipfile.ZipFile(fichier_zip, "r",allowZip64=True)
        else:
            file = zipfile.ZipFile(fichier_zip, "r")
        for name in file.namelist():
            print name
        print
    return code_retour

def lancement(char_os):
    p_debug("lancement("+char_os+")")
    code_retour = 56
    if ( f_param_lg_commande() != True):
            p_print_error("sortie du programme en CR 3",vg_bl)
    if vg_compress == True:
        print "Mode compression"
        code_retour = p_create_zip(vg_file_zip,vg_path_to_zip,vg_filtre,vg_stored_mode,vg_recursif_mode,vg_force,char_os)
    if vg_decompress == True :
        print "Mode decompression"
        if ('*' in vg_file_zip) or ('?' in vg_file_zip) or ('[' in vg_file_zip) :
            print "vg_file_zip is a REGEX : " + vg_file_zip
            files_zip = glob.glob(vg_file_zip)
            print "files_zip : " + str(files_zip)
            for file_zip in files_zip :
                code_retour =  p_extract_zip(file_zip,vg_path_to_dezip,char_os)
        else :
            code_retour =  p_extract_zip(vg_file_zip,vg_path_to_dezip,char_os)
    if vg_liste == True:
        print "Mode liste contenu du ZIP"
        code_retour = p_liste_zip(vg_file_zip)
    return code_retour

#*****************************************************************************************************************************  #
# Main
#*****************************************************************************************************************************  #
if __name__ == "__main__":
    # Variables du programme principal
    #Variable code_retour
    #Elle est positionnee avec un code retour different de 0 afin que la fonction modifie sa valeur
    code_retour = 56
    # Affiche la version
    print version + "\n"

    #*****************************************************************************************************************************  #
    # Lancement de la commande selon la plateforme utilisee
    #*****************************************************************************************************************************  #

    if __SYSTEM == "win32":
            import ctypes
            char_os = "\\"
            code_retour = lancement(char_os)
    elif __SYSTEM == "hp-ux11":
            char_os = "/"
            code_retour = lancement(char_os)
    elif __SYSTEM == "linux2":
            char_os = "/"
            code_retour = lancement(char_os)
    else:
            p_print_error("Plateforme inconnue",vg_bl)


    #######################################
    # Verification du code retour         #
    #######################################
    if code_retour not in (0,1, None):
            p_print_error ("Erreur inattendue - sortie en CR :", vg_bl)

    #######################################
    # Fin du Programme avec code_retour   #
    #######################################
    p_print_error ("Fin du programme", code_retour)

