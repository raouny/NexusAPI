#!/usr/bin/python
# -*- coding: iso-8859-15 -*-

#****************************    Fiche signaletique shell  encodage: iso-8859-15    ****************************************    #
# Nom du programme : chmod.py    But du programme : rendre ordonnancable le chmod   Version minimum de l'interpreteur python : 2.4
#***********************************************    Syntaxe    **************************************************************   #
#                       chmod.py arguments
#**********************************************    Historique    *************************************************************  #
# Version       Date            AUTEUR          ENTREPRISE      Commentaires
# 1.0           20/11/2013      Y.HERVE        La Poste        Creation
# 1.1           05/11/2015      P.BAUMES       La Poste        Ajout de la fonctionnalite du script sous windows
# 1.2			02/08/2017		Z.BEN ALI	   La Poste		   Modification nom d une variable incorrecte
#**********************************************    Codes retour    ***********************************************************  #
# code 0: Normal - Code retour normal : L enchainement est poursuivi
# code 1: Warning - Detection d une anomalie : L enchainement peut etre poursuivi
# code 3: Critique - Erreur Critique
# code 3: Exemple d erreur - Erreur parametres incorrects
# code > 3 : Traitement en erreur avec un code retour particulier
#*****************************************************************************************************************************  #


# Constantes : nom et version du script
__NOM_SCRIPT="chmod.py"
__VERSION_SCRIPT="1.1"


# Import des modules python

import sys
import subprocess
import copy
import getopt
import os
import re
import glob

# Import des modules clients ou fonctions globales

# Mode Bouchon mis en place pour les besoins du CCO: False ou True
vg_Code_Retour_Bouchon_CCO = 5 # Code retour dans le cas de l'utilisation du mode bouchon
# Fin du parametrage du mode bouchon

# Definition des constantes systemes
__SYSTEM = sys.platform
__PYTHON_VERSION = sys.version

# Definition des constantes code retour VTOM
CR_WG = 1 # code retour warning
CR_BL = 3 # code retour bloquant
CR_OK = 0 # code retour bonne execution

# Definitions des variables globales :
vg_param       = None
vg_debug       = False
vg_recursiv_mode = False
vg_rights = 0
vg_path = ''
vg_filtre = '*'

# Version du CC a completer
__VERSION = __NOM_SCRIPT + "  v" + __VERSION_SCRIPT + " - python "+__PYTHON_VERSION+" - "+__SYSTEM

#*****************************************************************************************************************************  #
# Definitions des fonctions et procedures
#*****************************************************************************************************************************  #
def p_debug(chaine):
    # affiche la chaine lorsque l option debug est positionnee a True
    if vg_debug : print str(chaine)

def p_test_options_script(arguments):
    # tests les arguments passes en parametres au script
    if (arguments == []) or (arguments is None):
        print "*** un argument est manquant ***"
        p_print_usage(CR_BL)

def p_print_usage(err):
#   Affiche le message d utilisation du script
#   quitte le programme avec le code retour passe en argument
    print r"""
    Usage de la commande:
    chmod.py [-R][--debugg][-f filtre (exemple *.txt)] mode path
             <-B|--bouchon CR_CCO>
    
    Sous UNIX / Linux le caractere * doit etre remplace par \*
    Pour Windows le mode est 777 ou 444
    Les modes de permissions sont convertis en octale
    
    parametres facultatifs:
    [-f ou filtre]              : filtre le contenu du dossier
    [-h ou --help]              : produit l'aide suivante
    [--bouchon=<code retour>]   : bouchon CCO
    [--debugg]                  : Fournit les informations detaillees de l'execution du script
    """

    sys.exit(err)

def p_print_error(mesg, num):
    # retourne le message d erreur et sort en code retour
    print mesg
    print "Sortie en code retour " + str(num)
    sys.exit(num)

def f_param_lg_commande(params):
    # Gestion des arguments passes en parametre de la ligne de commandes
    global vg_Code_Retour_Bouchon_CCO
    global vg_debug
    global vg_recursiv_mode
    global vg_rights
    global vg_path
    global vg_filtre

    try:
	opts, args = getopt.getopt(sys.argv[1:], "hB:f:R", ["help","bouchon=","filtre=","debugg"])
    except getopt.GetoptError, err:
        print "!!! ERREUR !!! l option n est pas reconnue : " + str(err)
        p_print_usage(CR_BL)

    for o, a in opts:
	if o in ("--debugg"):
	    vg_debug = True
	    p_debug("Option debugg renseignee")
        elif o in ("-h", "--help"):
            p_debug("Option help renseignee")
            p_print_usage(CR_OK)
        elif o in ("-B","--bouchon"):
            p_debug("Debut du mode bouchon")
            vg_Code_Retour_Bouchon_CCO = int(a)
            p_print_error("Mode bouchon ",vg_Code_Retour_Bouchon_CCO)
        elif o in ("-f","--filtre"):
            p_debug("Mode filtre actif")
	    vg_filtre = a
	    p_debug("filtre a prendre en compte : " + str(vg_filtre))
        elif o in ("-R"):
            vg_recursiv_mode = True
	    p_debug("Mode recursif actif")
        else:
            assert False, "option invalide !!!"
    
    #Recherche des droits a attribuer dans les arguments donnes (sous forme octale)
    for i in args:
        if(re.search('[0-7]{3}', i)):
            vg_rights = int(i, 8) #Transformation en int BASE 8 donc en octal !!!
        else:
            vg_path = i

    p_test_options_script(params)
    return True

def f_os_system(cmd):
    return subprocess.call((cmd),shell=True)

def f_listdirectory(path, filtre):
    fichier = []
    chemin_full = path + os.sep + "*"
    l = glob.glob(chemin_full)
    chemin_filtre = path + os.sep + filtre
    l_filtre = glob.glob(chemin_filtre)
    for i in l:
        if os.path.isdir(i):
            fichier.extend(f_listdirectory(i, filtre))
	    fichier.append(i)
        elif (i in l_filtre):
            p_debug("fichier :" + i + " ajoute")
	    fichier.append(i)
    print("FICHIER " + str(fichier))
    return fichier

#*****************************************************************************************************************************  #
# definition des fonctions par system d exploitation
#*****************************************************************************************************************************  #

def f_lancement_windows(params):
    global vg_path
    global vg_rights
    global vg_recursiv_mode
    global vg_filtre
    
    # global code_retour_fonction si pas modifie ...
    vl_code_retour = 256

    # print "debut de la fonction Linux"
    p_debug("Arguments valides - Lancement de la commande chmod")
    print("") 
    if (vg_rights == 292):
	if (vg_recursiv_mode == True):
            vl_Files = f_listdirectory(vg_path, vg_filtre)
	    for i in vl_Files:
                try:
                    p_debug("Commande executee : "+str("os.chmod("+i+", 0444)"))
                    os.chmod(i, 0444)
                    vl_code_retour = 0
                except OSError, e:
                    if e.errno == 2:
                        print "fichier \"" + e.filename + "\" inexistant (" + e.strerror + ")"
                        print "Sortie en code warning 1"
                        sys.exit(CR_WG)
                    else:
                        print "(" + e.strerror + ")"
                        vl_code_retour = 3
        else:
            try:
                p_debug("Commande executee : "+str("os.chmod("+vg_path+", 0444)"))
                os.chmod(vg_path, 0444)
                vl_code_retour = 0
            except OSError, e:
                if e.errno == 2:
                    print "fichier \"" + e.filename + "\" inexistant (" + e.strerror + ")"
                    print "Sortie en code warning 1"
                else:
                    print "(" + e.strerror + ")"
                    vl_code_retour = 3
    elif (vg_rights == 511):
        if(vg_recursiv_mode == True):
            vl_Files = f_listdirectory(vg_path, vg_filtre)
            for i in vl_Files:
                try:
                    p_debug("Commande executee : "+str("os.chmod("+i+", 0777)"))
                    os.chmod(i, 0777)
                    vl_code_retour = 0
                except OSError, e:
                    if e.errno == 2:
                        print "fichier \"" + e.filename + "\" inexistant (" + e.strerror + ")"
                        print "Sortie en code warning 1"
                    else:                   
                        print "(" + e.strerror + ")"
                        vl_code_retour = 3
        else:
            try:
                p_debug("Commande executee : "+str("os.chmod("+vg_path+", 0777)"))
                os.chmod(vg_path, 0777)
                vl_code_retour = 0
            except OSError, e:
                if e.errno == 2:
                    print "fichier \"" + e.filename + "\" inexistant (" + e.strerror + ")"
                    print "Sortie en code warning 1"
                else:                   
                    print "(" + e.strerror + ")"
                    vl_code_retour = 3
    else:
        p_print_error("Ces droits ne sont pas pris en compte sur cette plateforme", 3)

    return vl_code_retour

def f_lancement_hpux(params):
    return f_lancement_linux(params)

def f_lancement_solaris(params):
    p_print_error("OS non supporte", CR_BL)

def f_lancement_linux(params):
    global vg_rights
    global vg_recursiv_mode
    global vg_filtre
    global vg_path

    # global code_retour_fonction si pas modifie ...
    vl_code_retour = 256

    # print "debut de la fonction Linux"
    p_debug ("Arguments valides - Lancement de la commande chmod")
    if(vg_recursiv_mode == True):
        vl_Files = f_listdirectory(vg_path, vg_filtre)
	for i in vl_Files:
            try:
                p_debug("Commande executee : "+str("os.chmod("+i+", "+vg_rights+")"))
                vl_code_retour = os.chmod(i, vg_rights)
            except OSError, e:
                if e.errno == 2:
                    print "fichier \"" + e.filename + "\" inexistant (" + e.strerror + ")"
                    print "Sortie en code warning 1"
                    sys.exit(CR_WG)
                else:
                    print "(" + e.strerror + ")"
                    vl_code_retour = 3
    else:
        p_debug("Commande executee : "+str("os.chmod("+vg_path+", "+str(vg_rights)+")"))
        try:
            os.chmod(str(vg_path), vg_rights)
            vl_code_retour = 0
        except OSError, e:
            if e.errno == 2:
                print "fichier \"" + e.filename + "\" inexistant (" + e.strerror + ")"
                print "Sortie en code warning 1"
                sys.exit(CR_WG)
            else:
                print "(" + e.strerror + ")"
                vl_code_retour = 3

    return vl_code_retour





#*****************************************************************************************************************************  #
# Main
#*****************************************************************************************************************************  #
if __name__ == "__main__":
    # Variables du programme principal


    # Affiche la version
    print __VERSION + "\n"

    #vl_param = f_Valorisation_Variable_System(vg_param)

    # ++++++++++++++++++++++++++++++++++

    #*****************************************************************************************************************************  #
    # Lancement de la commande selon la plateforme utilisee
    #*****************************************************************************************************************************  #

    if __SYSTEM == "win32":
	if( f_param_lg_commande(sys.argv[1:]) != True):
            print_error(vg_bl)
        #vl_param = f_param_lg_commande(sys.argv[1:])
	vl_param = sys.argv[1:]
        vl_code_retour = f_lancement_windows(vl_param)
    elif __SYSTEM == "hp-ux11":
        vl_param = f_param_lg_commande(sys.argv[1:])
        vl_code_retour = f_lancement_hpux(vl_param)
    elif __SYSTEM == "linux2":
        vl_param = f_param_lg_commande(sys.argv[1:])
        vl_code_retour = f_lancement_linux(vl_param)
    elif __SYSTEM == "solaris":
        p_print_error("OS non supporte", CR_BL)
    else:
        p_print_error("OS inconnue",CR_BL)


    #######################################
    # Verification du code retour         #
    #######################################
    if vl_code_retour not in (0, None):
        p_print_error("Erreur inattendue", CR_BL)
    else :
        vl_code_retour = CR_OK
    #######################################
    # Fin du Programme avec code_retour   #
    #######################################
    p_print_error("Fin du programme. " ,vl_code_retour)



