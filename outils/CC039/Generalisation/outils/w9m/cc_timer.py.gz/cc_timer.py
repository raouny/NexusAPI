#!/usr/bin/python
# -*- coding: iso-8859-15 -*-

#****************************    Fiche signaletique shell  encodage: iso-8859-15    ****************************************    #
# Nom du programme : cc_timer.py    But du programme : rechercher des valeurs de variables systemes     Version minimum de l'interpreteur python : 2.4
#***********************************************    Syntaxe    **************************************************************   #
#                       cc_timer.py -t param1
#**********************************************    Historique    *************************************************************  #
# Version       Date            AUTEUR          ENTREPRISE      Commentaires
# 1.0           09/09/2013      A.LUVISON       La Poste        Creation
# 1.1           11/10/2013      A.LUVISON       La Poste        mise en conformite avec cr
# 1.2           26/11/2013      A.LUVISON       La Poste        Mise a jour help et correction erreur option -h
#**********************************************    Codes retour    ***********************************************************  #
# code 0: Normal - Code retour normal : L enchainement est poursuivi
# code 1: Warning - Detection d une anomalie : L enchainement peut etre poursuivi
# code 3: Critique - Erreur Critique
# code 3: Exemple d erreur - Erreur parametres incorrects
# code > 3 : Traitement en erreur avec un code retour particulier
#*****************************************************************************************************************************  #

# bonnes pratiques :
# ------------------

# Cas des constantes :
#    Tout en majuscule
#    S�parer les mots par des underscore
#    Donner des noms simples et descriptifs
#    N'utiliser que des lettres [a-z][A-Z] et [0-9]

# Cas des variables :
#    Premi�re lettre en minuscule
#    M�lange de minuscule, majuscule avec la premi�re lettre de chaque mot en majuscule
#    Donner des noms simples et descriptifs
#    Variable d'une seule lettre � �viter au maximum sauf dans des cas pr�cis et locaux (tour de boucle)
#    N'utiliser que des lettres [a-z][A-Z] et [0-9]

#    pour debuter une variable :
#    vg_ Variable Globale
#    vl_ Variable Locale

# Cas des fonctions et procedures :

#    Premi�re lettre en majuscule
#    M�lange de minuscule, majuscule avec la premi�re lettre de chaque mot en majuscule
#    Donner des noms simples et descriptifs
#    Eviter les acronymes hormis les communs (Xml, Url, Html)
#    N'utiliser que des lettres [a-z][A-Z] et [0-9]
#    Mettre un commentaire en dessous pour decrire la fonction / procedure

#    pour d�buter une fonction pr�fixer par :
#    f_ pour les fonctions
#    p_ pour les proc�dures

# Syntaxe des parametres transmis au script

#  -x     option oligatoire passee en argument
# [-x]    option optionnelle passe en argument
# <x>     champ obligatoire
# |       separe des options correspond a un ou
# (text)  message de description


# ____________________________


# Constantes : nom et version du script
__NOM_SCRIPT="cc_timer.py"
__VERSION_SCRIPT="1.2"


# Import des modules python
import os
import sys
import platform
import getopt
import re
import os.path
import glob
import string

import time

# Import des modules clients ou fonctions globales

# Mode Bouchon mis en place pour les besoins du CCO: False ou True
vg_Bouchon_CCO = False
vg_Code_Retour_Bouchon_CCO = 5 # Code retour dans le cas de l'utilisation du mode bouchon
# Fin du parametrage du mode bouchon

# Definition des constantes systemes
__SYSTEM = sys.platform
__PYTHON_VERSION = sys.version

# Definition des constantes code retour VTOM
CR_WG = 1 # code retour warning
CR_BL = 3 # code retour bloquant
CR_OK = 0 # code retour bonne execution

# Definitions des variables globales :
vg_Debug = True
vg_Param_d = None
vg_Param_t = None
vg_Param_f = int(55)

# Version du CC a completer
__VERSION = __NOM_SCRIPT + "  v" + __VERSION_SCRIPT + " - python "+__PYTHON_VERSION+" - "+__SYSTEM

#*****************************************************************************************************************************  #
# Definitions des fonctions et procedures
#*****************************************************************************************************************************  #
def p_Timer():
    if vg_Param_t < 0:
        print "*** ERREUR : la valeur temps est negative ***"
        p_Print_Usage(CR_BL)
    
    else:
        time.sleep(vg_Param_t)
        tps = str(vg_Param_t)
        print("")
        print("Vous avez attendu : " + tps + "s")

    p_Debug("Fin de p_Timer")

def p_Debug(chaine):
    # affiche la chaine lorsque l option debug est positionnee a True
    if vg_Debug : print str(chaine)

def p_Test_Options_Script(params):
    # tests les arguments passes en parametres au script
        print "Tests des arguments du script"

        if '-t' not in params :
                print "*** un argument est manquant ***"
                p_Print_Usage(CR_BL)

        p_Debug("Fin de p_Test_Options")

def p_Print_Usage(err):
#   Affiche le message d utilisation du script
#   quitte le programme avec le code retour passe en argument
    print r"""
    Usage de la commande :
    cc_timer.py -t <message>

    [-h]         : produit l'aide suivante
    [--help]     : produit l'aide suivante
    [--debug]    : mode verbose - permet de debugger
    [-B | --bouchon=<code retour>]   : bouchon CCO
    [-f <num>]   : Force le code retour a num
    -t <duree>   : duree exprimee en seconde

    """

    print("Sortie code retour " +str(err))
    sys.exit(err)

def f_Valorisation_Variable_System(chaine): # permet de valoriser des $ sous unix ou % sous windows
    vl_Resultat = os.path.expandvars(chaine)
    p_Debug("Resultat de la valorisation " + str(vl_Resultat))
    return vl_Resultat

def f_Replace_Backshlashs(chaine):
        # Remplace les \ des chemins Windows par des \\ lisibles par python
        # Attention la chaine ne doit pas etre vide
        if chaine != None :
           vl_Resultat = chaine.replace("\\","\\\\")
           p_Debug("Resultat du Replace_Backshlashs : "+str(vl_Resultat))
           return vl_Resultat

def p_Print_Error(mesg, num):
    # retourne le message d erreur et sort en code retour
    print mesg
    print "Sortie en code retour " + str(num)
    sys.exit(num)

def p_Param_Lg_Commande(params):
    # Gestion des arguments passes en parametre de la ligne de commandes
    global vg_Bouchon_CCO
    global vg_Code_Retour_Bouchon_CCO
    global vg_Param_t
    global vg_Param_f
    try:
        opts, args = getopt.getopt(params, "hf:t:B:", ["help", "debug","bouchon="])

    except getopt.GetoptError , err:
        # print help information and exit:
        print str(err) # will print something like "option -a not recognized"
        p_Print_Usage(CR_BL)

    for o, a in opts:
        if o == ("--help"):
            p_Print_Usage(CR_BL)
        elif o == ("-h"):
            p_Print_Usage(CR_BL)
        elif o == ("-f"):
            vg_Param_f = int(a)
        elif o == ("-t"):
            try :
                vg_Param_t = int(a)
            except:
                print "*** ERREUR : Veuiller entrer un chiffre/nombre et non des caracteres ***"
                p_Print_Usage(CR_BL)
        elif o in ("--bouchon","-B"): # UTILISER POUR LE MODE BOUCHON
            vg_Bouchon_CCO = True
            vg_Code_Retour_Bouchon_CCO = int(a)
            p_Print_Error("Mode bouchon",vg_Code_Retour_Bouchon_CCO)
        elif o in ("--debug"):
            vg_Debug = True
            p_Debug("Mode DEBUG Actif")
        else:
            assert False, "option invalide"


    # affiche un message d erreur en cas de params incorrects
    p_Test_Options_Script(params)
    


#*****************************************************************************************************************************  #
# definition des fonctions par system d exploitation
#*****************************************************************************************************************************  #

def f_Lancement_Windows(params):
    # global code_retour_fonction si pas modifie ...
    vl_Code_Retour = 256

    # print "debut de la fonction windows"

    # appel de la commande "wait"
    p_Timer()

    return CR_OK

def f_Lancement_Hpux(params):
    return f_Lancement_Windows(params)

def f_Lancement_Solaris(params):
    p_Print_Error("OS non supporte", CR_BL)

def f_Lancement_Linux(params):
    return f_Lancement_Windows(params)




#*****************************************************************************************************************************  #
# Main
#*****************************************************************************************************************************  #
if __name__ == "__main__":
    # Variables du programme principal


    # Affiche la version
    print __VERSION + "\n"
    
    p_Param_Lg_Commande(sys.argv[1:])  
    
    vl_Param = vg_Param_d
    # ++++++++++++++++++++++++++++++++++

    #*****************************************************************************************************************************  #
    # Lancement de la commande selon la plateforme utilisee
    #*****************************************************************************************************************************  #

    if __SYSTEM == "win32":
            vl_Code_Retour = f_Lancement_Windows(vl_Param)
    elif __SYSTEM == "hp-ux11":
            vl_Code_Retour = f_Lancement_Hpux(vl_Param)
    elif __SYSTEM == "linux2":
            vl_Code_Retour = f_Lancement_Linux(vl_Param)
    elif __SYSTEM == "solaris":
            vl_Code_Retour = f_Lancement_Solaris(vl_Param)
    else:
            p_Print_Error("PF inconnue",CR_BL)


    #######################################
    # Verification du code retour         #
    #######################################
    if vl_Code_Retour not in (0, None):
        p_Print_Error("Erreur inattendue", CR_BL)

    #######################################
    # Fin du Programme avec code_retour   #
    #######################################
    else :
        if vg_Param_f != 55 :
            p_Print_Error("Fin du programme avec code retour force.",vg_Param_f)
        else:
            p_Print_Error("Fin du programme. " ,vl_Code_Retour)




