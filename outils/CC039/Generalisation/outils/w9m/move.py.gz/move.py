#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
# 
#****************************    Fiche signaletique shell  encodage: iso-8859-15    ****************************************    #
# Nom du programme : move.py    But du programme : Deplacement de fichiers - Version minimum de l'interpreteur python : 2.4
#***********************************************    Syntaxe    **************************************************************   #
# move.py -f input_filter -i input_directory -o output_directory
#**********************************************    Historique    *************************************************************  #
# Version       Date            AUTEUR          ENTREPRISE      Commentaires
# 1.0           29/06/2015      R.SAVIGNY       GER - PIXON     Creation
#
#**********************************************    Codes retour    ***********************************************************  #
# code 0: Normal - Code retour normal : L enchainement est poursuivi
# code 1: Warning - Detection d une anomalie : L enchainement peut etre poursuivi
# code 2: Erreur - Erreur Non bloquante : possibilite de lancer une procedure de reprise
# code 3: Critique - Erreur Critique
# code 3: Exemple d erreur - Erreur parametres incorrects
# code > 3 : Traitement en erreur avec un code retour particulier
#*****************************************************************************************************************************  #

# -------------------------
# Import des modules python
# -------------------------
import os
import sys
import getopt
import os.path
import glob
import string
from shutil import copy2, copytree, move
import datetime
import time
import zipfile
import re


# -------------------------

# Definition des variables systeme
__SYSTEM = sys.platform
__PYTHON_VERSION = sys.version

# Version du CC a completer
version = "move.py v1.0 - python "+__PYTHON_VERSION+" - "+__SYSTEM

# code retour ordo
vg_bl=3
vg_wg=1
vg_ok=0

#*****************************************************************************************************************************  #
# Variables globales
#*****************************************************************************************************************************  #
vg_input_filter=None
vg_input_directory=None
vg_output_directory=None
vg_time=None
vg_secure=True
vg_verbeux=False # Mode Verbeux permet un debuggage plus precis / l option -v n affiche pas les parametres en entree
vg_force=False
vg_recursif=False
vg_preserve=False

#*****************************************************************************************************************************  #
# Definitions des fonctions locales
#*****************************************************************************************************************************  #
# Procedures
def p_chk_options():
    p_debug("Procedure : p_chk_options()")
    print "Test des arguments passes en entree du script ... "
    if (vg_input_directory == None or vg_output_directory == None):
            print "*** un argument est manquant ***"
            p_usage(vg_bl)
    if (vg_time != None or vg_recursif == True) and (vg_input_filter == None):
            print "*** un argument est manquant ***"
            p_usage(vg_bl)
    p_debug("Les parametres obligatoires sont renseignes")

def p_usage(err):
    p_debug("Procedure : p_usage()")
#   Affiche le message d utilisation du script
    print r"""
    Usage de la commande : 
    move.py -d <input_directory> -o <output_directory> [-p]
    move.py -i <REGEX input_filter> -d <input_directory> -o <output_directory> [-t] [-r] [-p]

            [-t <fichiers de + de x jours>] (date de derniere modification)
            [-r | --recursif] (Active le mode recursif)
            [-p | --preserve] Preserve l'originale (effectue une copie au lieu de deplacer)

            [-f | --force] Force l'ecrasement des fichiers cibles s'ils existent deja
            [-w] (desactive le mode secure)
                (A utiliser dans le cas ou les dossiers ne contiennent pas les chaines de caracteres suivantes :
                    TEMP, TMP, TRACE, LOG, DONNEE, DUMP, AUDIT, TRANSFERT,
                    TRAVAIL, SVDB, EXPORT, IMPORT, DATA, DIAG, SAS, ENVOI, RECU
                    BACKUP, BKP)

    Les parametres suivants sont obligatoires :
            -d, -o
    
    Les parametres suivants sont indissociables :
            -t, -r requierent l'option -i

    [-h] (produit l'aide suivante)
    [-v] (verbose - permet de debugger)
    [-B | --bouchon] <code_retour> (utilise par le CCO)

    Sous UNIX / Linux les caracteres speciaux "*", "?", "[", "]" doivent etre precedes par le caractere "\"
    Exemples :
       La REGEX : l5x[at]aa?a.de    doit etre ecrite ainsi : l5x\[at\]aa\?a.de
       La REGEX : file*             doit etre ecrite ainsi : file\*

    """
    p_error(err)

def p_debug(chaine):
    if (vg_verbeux == True): print "Debug :\t\t"+str(chaine)

def p_error(num):
    p_debug("Procedure : p_error("+str(num)+")")
    # retourne le message d erreur et sort en code retour
    print "Erreur : Sortie en code retour " + str(num)
    sys.exit(num)

def p_system_var(chemin): # permet de valoriser des $ sous unix ou % sous windows
    p_debug("Procedure : p_system_var("+chemin+")")
    resultat = os.path.expandvars(chemin)
    p_debug ("Resultat de la valorisation " + str(resultat))
    return resultat

def param_lg_commande():
    p_debug("Procedure : param_lg_commande()")
    # Gestion des arguments passes en parametre de la ligne de commandes

    global vg_input_filter
    global vg_input_directory
    global vg_output_directory
    global vg_time
    global vg_secure
    global vg_verbeux  # utiliser pour le debuggage
    global vg_force
    global vg_recursif
    global vg_preserve

    ind_d = ind_i = ind_o = ind_t = ind_w = 0
    try:
        opts, args = getopt.getopt(sys.argv[1:], "i:d:o:B:t:fhpvwr", ["help", "bouchon=", "preserve", "recursif", "force"])

    except getopt.GetoptError, err:
        # print help information and exit:
        # will print something like "option -z not recognized"
        print "!!! ERREUR !!! l'option n'est pas reconnue : " + str(err)
        p_usage(vg_bl)

    for o, a in opts:
        p_debug("Option : "+o+", Argument : "+str(a))
        if o in ("-h", "--help"):
            p_usage(vg_bl)
        elif o in ("-B", "--bouchon"):
            print "Mode bouchon"
            p_error(int(a))
        elif o in ("-f", "--force"):
            print "Mode force"
            vg_force = True
        elif o in ("-r", "--recursif"):
            print "Mode recursif actif"
            vg_recursif = True
        elif o in ("-p", "--preserve"):
            print "Mode preserve actif"
            vg_preserve = True
        elif o == ("-i"):
            if ind_i >= 1 :
                print "Parametre -i en double ..."
                p_error(vg_bl)
            vg_input_filter = a
            p_debug("Nom du fichier en entree : " + str(vg_input_filter))
            ind_i +=1
        elif o == ("-d"):
            if ind_d >= 1 :
                print "Parametre -d en double ..."
                p_error(vg_bl)
            vg_input_directory = a
            if vg_input_directory[len(vg_input_directory)-1] == os.sep :
                p_debug("Suppression de : " + str(os.sep) + " en fin de repertoire source")
                vg_input_directory = vg_input_directory.rstrip(os.sep)
            p_debug("Nom du repertoire source : " + str(vg_input_directory))
            ind_d +=1
        elif o == ("-o"):
            if ind_o >= 1 :
                print "Parametre -o en double ..."
                p_error(vg_bl)
            vg_output_directory = a
            if vg_output_directory[len(vg_output_directory)-1] == os.sep :
                p_debug("Suppression de : " + str(os.sep) + " en fin de repertoire cible")
                vg_output_directory = vg_output_directory.rstrip(os.sep)
            p_debug("Nom du repertoire cible : " + str(vg_output_directory))
            ind_o +=1
        elif o == ("-t"):
            if ind_t >= 1 :
                print "Parametre -t en double ..."
                p_error(vg_bl)
            vg_time = int(a)
            p_debug("Mode retention de : " + str(vg_time) + "jour(s), actif")
            ind_t +=1
        elif o == ("-w"):
            if ind_w >= 1 :
                print "Parametre -w en double ..."
                p_error(vg_bl)
            vg_secure = False
            print "Mode secure desactive"
            ind_w +=1
        elif o == ("-v"):
            vg_verbeux = True
            print("Mode verbeux actif")
        else:
            assert False, "Option invalide !!!"
    p_chk_options() # Verifie les param obligatoires
    return True

def mk_regex(regex):
    p_debug("Fonction : mk_regex("+regex+")")
    regex=regex.replace('.', '\.')
    regex=regex.replace('?', '.?')
    regex=regex.replace('*', '.*')
    p_debug("REGEX syntaxe python : " + regex)
    p_debug("Chaine de remplacement : " + vg_replace)
    return regex

def list_directory(path, filter):
    p_debug("Fonction : list_directory("+path+", "+filter+")")
    global vg_recursif
    # liste les fichiers dans un dossier avec un filtre
    l_files=[] # liste retournee
    l_files_full = glob.glob(path+os.sep+"*")
    p_debug("Liste full fichiers : " + str(l_files_full))
    l_files_filter = glob.glob(path+os.sep+filter)
    p_debug("Liste filtree fichiers : " + str(l_files_filter))
    for i in l_files_full:
        if os.path.isdir(i):
            p_debug("Chemin isdir : "+i)
            if vg_recursif == True :
                extend=list_directory(i, filter)
                l_files.extend(extend)
        else:
            if i in l_files_filter :
                p_debug("Fichier : " + i + " ajoute")
                l_files.append(i)
    p_debug("Liste filtree des fichiers : " + str(l_files))
    return l_files

def filter_retention(input_list):
    p_debug("Fonction : filter_retention("+str(input_list)+")")
    global vg_time
    l_files=[] # liste retournee
    if vg_time <> None : # evite de recalculer a chaque iteration la retention
        date_du_jour = datetime.datetime.now()
        date_retention = date_du_jour - datetime.timedelta(days=vg_time) # calcul de la retention
        p_debug("Date limite de retention : " + date_retention.ctime()) #.strftime("%Y%m%d%H%M%S)

    for file in input_list:
        p_debug("test si fichier existe : "+file)
        if os.path.isfile(file) == True :
            if vg_time <> None : # gestion de la retention de fichier
                if __SYSTEM == "win32": # cas windows on calcule la date sur la creation et la modification
                    date_derniere_modif_fichier = datetime.datetime.fromtimestamp(os.stat(file).st_mtime)
                    date_creation_fichier = datetime.datetime.fromtimestamp(os.stat(file).st_ctime)
                    if date_creation_fichier > date_derniere_modif_fichier :
                        p_debug("warning date de creation plus recente que la date de modification - date de creation utilise")
                        date_du_fichier = date_creation_fichier
                    else :
                        date_du_fichier = date_derniere_modif_fichier
                else : # cas unix/linux on calcule la date sur la modification
                    date_du_fichier = datetime.datetime.fromtimestamp(os.stat(file).st_mtime)
                p_debug("date du fichier : " + file + "-" + str(date_du_fichier))
                if (date_retention > date_du_fichier):
                    l_files.append(file)
                    p_debug("fichier plus ancien - ajout du fichier : " + str(file))
                else:
                    p_debug("fichier :" + file+"-"+ str(date_du_fichier)+ "trop recent - ignore" + date_retention.ctime())
                    print "fichier ignore : " , file,"-", str(date_du_fichier), "car trop recent"
            else :
                l_files.append(file)
                p_debug("ajout du fichier : "+str(file))
        else:
            p_debug(str(file)+ " n'est pas un fichier")
    return l_files

def mk_file_list(directory, filter):
    p_debug("Fonction : mk_file_list("+directory+", "+filter+")")
    global vg_input_directory
    global vg_input_filter
    global vg_recursif
    # retourne la liste des fichiers a traiter
    path = directory + os.sep + vg_input_filter
    print "Recherche des fichiers presents : " + str(path)
    file_list_full = list_directory(vg_input_directory, vg_input_filter)
    list_fichiers = filter_retention(file_list_full)
    if len(list_fichiers) !=0 :
        return list_fichiers
    else :
        print "Aucun fichier a traiter"
        print "Sortie en code warning 1"
        sys.exit(vg_wg)

def chk_directory_exist(directory): # sort en erreur dans le cas ou le fichier existe ou un dossier du meme nom
    p_debug("Fonction : chk_directory_exist("+directory+")")
    if os.path.isdir(directory) == True and vg_force == False :
        print "Erreur : repertoire \""+str(directory)+"\" deja present"
        p_error(vg_bl)
    if os.path.isfile(directory) == True :
        print "Erreur un fichier porte deja ce nom : "+ str(directory)
        p_error(vg_bl)
    if os.path.islink(directory) == True :
        print "Erreur un lien symbolique porte deja ce nom : "+ str(directory)
        p_error(vg_bl)

def chk_file_exist(fichier): # sort en erreur dans le cas ou le fichier existe ou un dossier du meme nom
    p_debug("Fonction : chk_file_exist("+fichier+")")
    if os.path.isfile(fichier) == True and vg_force == False :
        print "Erreur fichier : " + str(fichier) + " deja present"
        p_error(vg_bl)
    if os.path.isdir(fichier) == True :
        print "Erreur un dossier porte deja ce nom : "+ str(fichier)
        p_error(vg_bl)
    if os.path.islink(fichier) == True :
        print "Erreur un lien symbolique porte deja ce nom : "+ str(fichier)
        p_error(vg_bl)

def chk_input_directory(directory): # sort en erreur dans le cas ou le dossier n existe pas
    p_debug("Fonction : chk_input_directory("+directory+")")
    if os.path.exists(directory) == False :
        print "Erreur dossier : " + str(directory) + " absent"
        p_error(vg_bl)
    if os.access(directory,os.R_OK) == False :
        print "Erreur de droits !!! le dossier ne peut-etre lu : " + str(directory)
        p_error(vg_bl)

def chk_input_files(list_fichiers):
    p_debug("Fonction : chk_input_files("+str(list_fichiers)+")")
    # Verifie les attributs des fichiers en entree
    for i in list_fichiers :
        if vg_verbeux :  print "Verification des attributs sur le fichier : " + str(i)
        if os.access(i, os.R_OK):
            p_debug("Le fichier peut-etre lu")
        else :
            print "Le fichier : " + str(i) + " ne peut etre lu - verifier les droits"
            p_error(vg_bl)
        if not(os.access(i, os.W_OK)) and vg_suppression :
            print "Attention l option lecture seule sur le fichier : " + str(i) + " est incompatible avec le mode suppression"
            p_error(vg_bl)
        else :
            p_debug("L'option est compatible avec le mode suppression de la source")
    return True

def chk_secure_directory(chemin, secure) :
    p_debug("Fonction : chk_secure_directory("+chemin+", "+str(secure)+")")
    Erreur = False
    if secure == True :
        if "TEMP"  in str(string.upper(chemin)) :
            Erreur = True
        if "TMP" in str(string.upper(chemin)) :
            Erreur = True
        if "TRACE" in str(string.upper(chemin)) :
            Erreur = True
        if "LOG" in str(string.upper(chemin)) :
            Erreur = True
        if "DONNEE" in str(string.upper(chemin)) :
            Erreur = True
        if "DUMP" in str(string.upper(chemin)) :
            Erreur = True
        if "AUDIT" in str(string.upper(chemin)) :
            Erreur = True
        if "TRANSFERT" in str(string.upper(chemin)) :
            Erreur = True
        if "TRAVAIL" in str(string.upper(chemin)) :
            Erreur = True
        if "SVDB" in str(string.upper(chemin)) :
            Erreur = True
        if "IMPORT" in str(string.upper(chemin)) :
            Erreur = True
        if "EXPORT" in str(string.upper(chemin)) :
            Erreur = True
        if "DATA" in str(string.upper(chemin)) :
            Erreur = True
        if "DIAG" in str(string.upper(chemin)) :
            Erreur = True
        if "SAS" in str(string.upper(chemin)) :
            Erreur = True
        if "ENVOI" in str(string.upper(chemin)) :
            Erreur = True
        if "RECU" in str(string.upper(chemin)) :
            Erreur = True
        if "BACKUP" in str(string.upper(chemin)) :
            Erreur = True
        if "BKP" in str(string.upper(chemin)) :
            Erreur = True
        if Erreur == False :
            print "Le chemin n est pas un dossier de traces, logs, temps, donnees, dump, audit, travail, transfert, svdb, import, export, data, diag, sas, envoi, recu, backup, bkp. Utiliser l'option -w"
            p_error(vg_bl)

def execute_move_dir(input, output):
    p_debug("Fonction : execute_move_dir("+input+", "+output+")")
    global vg_preserve
    if (vg_preserve == True):
        if os.path.exists(output+os.sep+str(input).rsplit(os.sep, 1)[1]):
            os.system('rm -rf '+output+os.sep+str(input).rsplit(os.sep, 1)[1])
        try :
            copytree(input, output+os.sep+str(input).rsplit(os.sep, 1)[1])
        except :
            print "Erreur lors du copy directory"
            p_error(vg_bl)
    else :
        if os.path.exists(output+os.sep+str(input).rsplit(os.sep, 1)[1]):
            os.system('rm -rf '+output+os.sep+str(input).rsplit(os.sep, 1)[1])
        try :
            move(input, output+os.sep+str(input).rsplit(os.sep, 1)[1])
        except :
            print "Erreur lors du move directory"
            p_error(vg_bl)
    p_debug("la commande move directory a reussie")
    return True

def execute_move_file(list_fichiers, input, output):
    p_debug("Fonction : execute_move_file("+str(list_fichiers)+", "+input+", "+output+")")
    global vg_preserve
    for file_in in list_fichiers :
        file_out = file_in.replace(input, output)
        file_out_dir=os.path.dirname(file_out)
        file_out_dir_ext = file_out_dir.replace(output, '')
        p_debug("file_out_dir_ext : "+file_out_dir_ext)
        lst_dir_ext = file_out_dir_ext.split(os.sep)
        p_debug("lst_dir_ext : "+str(lst_dir_ext))
        input_tmp=input
        output_tmp=output
        for dir_ext in lst_dir_ext:
            if dir_ext:
                dir_mode = os.stat(input_tmp+os.sep+dir_ext)[0]
                if (os.path.exists(output_tmp+os.sep+dir_ext) == False):
                    try:
                        os.makedirs(output_tmp+os.sep+dir_ext, dir_mode)
                    except OSError , (errno, strerror):
                        print "OSerror (", str(errno), ") : ",str(strerror)
                        p_error(vg_bl)
                input_tmp=input_tmp+os.sep+dir_ext
                output_tmp=output_tmp+os.sep+dir_ext
        chk_file_exist(file_out)
        if (vg_preserve == True):
            try :
                copy2(file_in, file_out)
            except :
                print "Erreur lors du copy file : "+file_in+" vers "+file_out
                p_error(vg_bl)
        else :
            try :
                move(file_in, file_out)
            except :
                print "Erreur lors du move file : "+file_in+" vers "+file_out
                p_error(vg_bl)
    p_debug("la commande move file a reussie")
    return True

#*****************************************************************************************************************************  #
# definition des fonctions par system d'exploitation
#*****************************************************************************************************************************  #

def lancement_windows():
    global vg_input_filter
    global vg_input_directory
    global vg_output_directory

    # Valorise les variables d environnement system
    vg_input_directory=p_system_var(vg_input_directory)
    vg_output_directory=p_system_var(vg_output_directory)
    output_directory=vg_output_directory+os.sep+str(vg_input_directory).rsplit(os.sep, 1)[1]

    # verification du dossiers input
    chk_input_directory(vg_input_directory)
    chk_secure_directory(vg_input_directory, vg_secure)

    # verification du dossiers output
    chk_directory_exist(output_directory)

    # Cas1 : Move repertoire
    if (vg_input_filter == None):
        # execute le move
        if (execute_move_dir(vg_input_directory, vg_output_directory) == True):
            code_retour_fonction = 0

    # Cas2 : Move fichiers
    else:
        # fabrique la liste des fichiers a traiter
        list_fichiers_entree = mk_file_list(vg_input_directory, vg_input_filter)
        list_fichiers_entree = filter_retention(list_fichiers_entree)
        p_debug("liste des fichiers a traiter : " + str(list_fichiers_entree))
        CR_chk_input_files = chk_input_files(list_fichiers_entree)
        if CR_chk_input_files <> True :
            print "Erreur lors de la verification des parametres sur les fichiers d entree"
            p_error(vg_bl)
        # execute le move
        if (execute_move_file(list_fichiers_entree, vg_input_directory, vg_output_directory) == True):
            code_retour_fonction = 0

    # retourne le code retour de l execution de la commande
    return code_retour_fonction

def lancement_hpux():
    return lancement_windows()

def lancement_solaris():
    return lancement_windows()

def lancement_linux():
    return lancement_windows()

#*****************************************************************************************************************************  #
# Main
#*****************************************************************************************************************************  #
if __name__ == "__main__":
    # Variables du programme principal
    
    # Affiche la version
    print version + "\n"
    
    # Affiche la commande lancee
    print "Execution de la commande : " + str(sys.argv)

    #*****************************************************************************************************************************  #
    # Lancement de la commande selon la plateforme utilisee
    #*****************************************************************************************************************************  #

    if __SYSTEM == "win32":
            print "Liste des parametres : "
            if (param_lg_commande() != True):
                p_error(vg_bl)
            code_retour = lancement_windows()
    elif __SYSTEM == "hp-ux11":
            print "Liste des parametres : "
            if (param_lg_commande() != True):
                p_error(vg_bl)
            code_retour = lancement_hpux()
    elif __SYSTEM == "linux2":
            print "Liste des parametres : "
            if (param_lg_commande() != True):
                p_error(vg_bl)
            code_retour = lancement_linux()
    elif __SYSTEM == "solaris":
            print "Liste des parametres : "
            if (param_lg_commande() != True):
                p_error(vg_bl)
            code_retour = lancement_solaris()
    else:
            print "Plateforme inconnue - sortie en CR 3"
            p_error(vg_bl)


    #######################################
    # Verification du code retour         #
    #######################################
    if code_retour not in (0, None):
            print "ping: Erreur inattendue - sortie en CR 3"
            p_error(vg_bl)

    #######################################
    # Fin du Programme avec code_retour   #
    #######################################
    print "Fin du programme - code retour : " + str(code_retour)
    sys.exit(code_retour)
