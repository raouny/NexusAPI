#!/usr/bin/python
# -*- coding: iso-8859-15 -*-

#****************************    Fiche signaletique shell  encodage: iso-8859-15    ****************************************    #
# Nom du programme : tarpy.py    But du programme : tarpy     Version minimum de l'interpreteur python : 2.4
#***********************************************    Syntaxe    **************************************************************   #
#                       tarpy.py -c <nom du fichier tar> -d <repertoire ou fichier(s) a mettre dans le tar> [-z]
#                       tarpy.py -x <fichier tar a extraire> [-d] <Repertoire d'extraction> [-z]
#                       tarpy.py -t <fichier tar> [-z]maquette.py -d param1 | param2
#**********************************************    Historique    *************************************************************  #
# Version       Date            AUTEUR         ENTREPRISE      Commentaires
# 1.0           31/08/2011      C.CHAPUT       La Poste        Creation
# 2.0           26/11/2013      Y.HERVE        La Poste        R�-�criture compl�te du script ( utilisation des librairies python
#                                                              + gestion muti-fichiers + Multi os
# 2.1           07/10/2014      R.SAVIGNY      La Poste        Modification "f_Liste_Fichiers" muti-r�pertoires/fichiers + REGEX
#                                                              avec "," comme separateur. Correction option --help
# 2.2           15/04/2015      R.SAVIGNY      La Poste        Correction generation du tar sous Windows - ajout tar.close()
# 2.3           12/08/2015      R.SAVIGNY      PIXON           I08079305  : Prise en compte fichier deja compresse
#                                                              Detail de l'utilisation des caractere speciaux sous unix/linux
#                                                              Ajout de l'option "-C"
#**********************************************    Codes retour    ***********************************************************  #
# code 0: Normal - Code retour normal : L enchainement est poursuivi
# code 1: Warning - Detection d une anomalie : L enchainement peut etre poursuivi
# code 3: Critique - Erreur Critique
# code 3: Exemple d erreur - Erreur parametres incorrects
# code > 3 : Traitement en erreur avec un code retour particulier
#*****************************************************************************************************************************  #

# Constantes : nom et version du script
__NOM_SCRIPT="tarpy.py"
__VERSION_SCRIPT="2.3"


# Import des modules python
import os
import sys
import getopt
import os.path
import glob
import tarfile

# Import des modules clients ou fonctions globales

# Mode Bouchon mis en place pour les besoins du CCO: False ou True
vg_Bouchon_CCO = False
vg_Code_Retour_Bouchon_CCO = 5 # Code retour dans le cas de l'utilisation du mode bouchon
# Fin du parametrage du mode bouchon

# Definition des constantes systemes
__SYSTEM = sys.platform
__PYTHON_VERSION = sys.version

# Definition des constantes code retour VTOM
CR_WG = 1 # code retour warning
CR_BL = 3 # code retour bloquant
CR_OK = 0 # code retour bonne execution

# Definitions des variables globales :
vg_Debug = True
vg_Param_Tar = None
vg_Param_Input = None
vg_Param_Directory_Extract = None
vg_Mode = None
vg_Compress = False
vg_Change_Dir = False

# Version du CC a completer
__VERSION = __NOM_SCRIPT + "  v" + __VERSION_SCRIPT + " - python "+__PYTHON_VERSION+" - "+__SYSTEM

#*****************************************************************************************************************************  #
# Definitions des fonctions et procedures
#*****************************************************************************************************************************  #
def p_Debug(chaine):
    # affiche la chaine lorsque l option debug est positionnee a True
    if vg_Debug : print "\n"+str(chaine)

def p_Test_Options_Script(arguments):
    # tests les arguments passes en parametres au script
        p_Debug("Tests des arguments du script")

        if (arguments == []) or (arguments is None) :
            print "*** argument(s) manquant(s) ***"
            p_Print_Usage(CR_BL)

        if ((vg_Param_Directory_Extract != None) and ( vg_Mode != "Extract")):
            print "*** option -o compatible uniquement avec l'option -x ***"
            p_Print_Usage(CR_BL)

        if (( vg_Mode == "Create") and (vg_Param_Input == None)):
            print "*** l'option -i est obligatoire avec l'option -c ***"
            p_Print_Usage(CR_BL)

        if ((vg_Param_Input != None) and ( vg_Mode != "Create")):
            print "*** option -i compatible uniquement avec l'option -c ***"
            p_Print_Usage(CR_BL)

        if (( vg_Mode == None ) and ( vg_Bouchon_CCO == False )):
            print "*** Option non reconnue ***"
            p_Print_Usage(CR_BL)

        p_Debug("Fin de p_Test_Options")

def p_Print_Usage(err):
#   Affiche le message d utilisation du script
#   quitte le programme avec le code retour passe en argument
    print r"""
    Usage de la commande :
    tarpy.py -c <nom du fichier tar> -i <repertoire(s) ou fichier(s) a mettre dans le tar> [-z]
    tarpy.py -x <fichier tar a extraire> [-o] <Repertoire d'extraction>
    tarpy.py -t <fichier tar> [-z]

    Options obligatoires : -c | -x | -t
    -c <nom du fichier tar> -i <repertoire(s) et/ou fichier(s) a mettre dans le tar> : Pour creer une archive
                                si plusieurs fichiers/repertoires sources utilisez "," comme separateur.

    -x <fichier(s) tar a extraire> [-o] <Repertoire d'extraction> : Pour extraire les fichiers 
                                                                    (gere le multifichier exemple *.tar)
                                si [-o] absent l'extraction se fait dans le repertoire courant

    -t <fichier tar> : Pour visualiser le contenu du fichier tar ou tgz (gere le multifichier exemple *.tar)

    Options facultative :
    [-C] : Chemin relatif : Supprime le repertoire source du nom des fichiers dans l'archive
    [-z] : gere la compression au format gz 
    Attention, pour que la gestion multi fichiers par filtre fonctionne, il faut que la liste soit compos�e uniquement de fichiers au format tar, tgz ou tar.gz (peut importe son nom)

    Sous UNIX / Linux les caracteres speciaux "*", "?", "[", "]" doivent etre precedes par le caractere "\"
    Exemples :
       La REGEX : l5x[at]aa?a.de    doit etre ecrite ainsi : l5x\[at\]aa\?a.de
       La REGEX : file*             doit etre ecrite ainsi : file\*

    [--help]     : produit l'aide suivante
    [--debug]    : mode verbose - permet de debugger
    [-B | --bouchon=<code retour>]   : bouchon CCO
    """

    sys.exit(err)

def f_Valorisation_Variable_System(chaine): # permet de valoriser des $ sous unix ou % sous windows
    vl_Resultat = os.path.expandvars(chaine)
    p_Debug("Resultat de la valorisation " + str(vl_Resultat))
    return vl_Resultat

def f_Replace_Backshlashs(chaine):
        # Remplace les \ des chemins Windows par des \\ lisibles par python
        # Attention la chaine ne doit pas etre vide
        if chaine != None :
           vl_Resultat = chaine.replace("\\","\\\\")
           p_Debug("Resultat du Replace_Backshlashs : "+str(vl_Resultat))
           return vl_Resultat

def p_Print_Error(mesg, num):
    # retourne le message d erreur et sort en code retour
    print mesg
    print "Sortie en code retour " + str(num)
    sys.exit(num)

def p_Param_Lg_Commande(params):
    # Gestion des arguments passes en parametre de la ligne de commandes
    global vg_Bouchon_CCO
    global vg_Debug
    global vg_Code_Retour_Bouchon_CCO
    global vg_Param_Tar
    global vg_Param_Input
    global vg_Param_Directory_Extract
    global vg_Mode
    global vg_Compress
    global vg_Change_Dir

    # Necessaire pour compatibilite avec version precedente#####################
    if 'cf' in params and __SYSTEM == "win32":
        if len(params) == 3:
            print "Fichier tar cree: "+params[1]
            print "Arborescence(s) ou fichier(s) a integrer dans le fichier tar: "+str(params[2])
            vg_Param_Tar = f_Valorisation_Variable_System(params[1])
            vg_Param_Input = f_Valorisation_Variable_System(params[2])
            vg_Mode = 'Create'
            p_Debug ("Mode : "+vg_Mode)
        else :
            p_Print_Usage(CR_BL)

    ############################################################################
    else :
        try:
            opts, args = getopt.getopt(params, "c:x:t:zi:o:B:C", ["help", "debugg","bouchon="])

        except getopt.GetoptError, err:
            # print help information and exit:
            print str(err) # will print something like "option -a not recognized"
            p_Print_Usage(CR_BL)

        for o, a in opts:
            if o == ("--help"):
                p_Print_Usage(CR_BL)
            elif o == ("-c"):
                vg_Mode = "Create"
                vg_Param_Tar = f_Valorisation_Variable_System(a)
            elif o == ("-x"):
                vg_Mode = "Extract"
                vg_Param_Tar = f_Valorisation_Variable_System(a)
            elif o == ("-t"):
                vg_Mode = "Read"
                vg_Param_Tar = f_Valorisation_Variable_System(a)
            elif o == ("-z"):
                vg_Compress = True
            elif o == ("-i"):
                vg_Param_Input = f_Valorisation_Variable_System(a)
            elif o == ("-o"):
                vg_Param_Directory_Extract = f_Valorisation_Variable_System(a)
            elif o == ("-C"):
                vg_Change_Dir = True
                p_Debug("Mode vg_Change_Dir Actif")
            elif o in ("--bouchon","-B"): # UTILISER POUR LE MODE BOUCHON
                vg_Bouchon_CCO = True
                vg_Code_Retour_Bouchon_CCO = int(a)
                p_Print_Error("Mode bouchon",vg_Code_Retour_Bouchon_CCO)
            elif o == ("--debugg"):
                vg_Debug = True
                p_Debug("Mode DEBUG Actif")
            else:
                assert False, "option invalide"

    # affiche un message d erreur en cas de params incorrects
    p_Test_Options_Script(params)

def p_Make_Tarfile(output_filename, source_dir, Mode_Compress):
    p_Debug ("Debut de la fonction p_Make_Tarfile("+output_filename+", "+source_dir+", "+str(Mode_Compress)+")")
    print "Fichier tar cree: "+output_filename
    print "Arborescence(s) ou fichier(s) a integrer dans le fichier tar: "+source_dir+"\n"
    if Mode_Compress == True:
        vl_option = 'w:gz'
    else:
        vl_option = 'w:'
    try :
        p_Debug ("Fichier tar a creer dans: "+str(os.path.dirname(output_filename)))
        if os.path.dirname(output_filename) != "":
            if os.path.exists(os.path.dirname(output_filename)):
                tar = tarfile.open(output_filename, vl_option)
                files = f_Liste_Fichiers(source_dir)
                p_Debug ("affichage de la liste de fichiers : "+str(files))
                for f in files:
                    if vg_Change_Dir :
                        if f[len(f)-1] == os.sep : f = os.path.split(f)[0]
                        vl_new_name = os.path.split(f)[1]
                        print("Fichier ajoute au tar : "+f+" avec comme nom : "+vl_new_name)
                        tar.add(f, arcname=vl_new_name)
                    else:
                        print("Fichier ajoute au tar : "+f)
                        tar.add(f)
                tar.close()
            else:
                p_Print_Error ("Arborescence pour creation du fichier tar inexistante", CR_BL)
        else:
            vl_tar = f_Replace_Backshlashs(os.getcwd()+ "/" + output_filename )
            tar = tarfile.open(vl_tar, vl_option)
            files = f_Liste_Fichiers(source_dir)
            p_Debug ("affichage de la liste de fichiers : "+str(files))
            for f in files:
                if vg_Change_Dir == True :
                    if f[len(f)-1] == os.sep : f = os.path.split(f)[0]
                    vl_new_name = os.path.split(f)[1]
                    print("Fichier ajoute au tar : "+f+" avec comme nom : "+vl_new_name)
                    tar.add(f, arcname=vl_new_name)
                else: 
                    print "Fichier ajoute au tar : "+f
                    tar.add(f)
            tar.close()
    except OSError , (errno,strerror):
        print "OSerror (", str(errno), ") : ",str(strerror)
        p_Print_Error ("", CR_BL)
    except IOError :
        print "IOerror : anomalie dans le ficher tar"
        p_Print_Error ("", CR_BL)
    except :
        p_Print_Error ("Erreur inconnue - sortie en code retour", CR_BL)

def p_Read_Tarfile (input_filename, Mode_Compress):
    p_Debug ("Debut de la fonction p_Read_Tarfile")
    p_Debug ("Lecture du contenu du fichier tar : "+input_filename)
    vl_Liste_Tar = f_Liste_Fichiers(input_filename)
    for i in vl_Liste_Tar:
        if tarfile.is_tarfile(i) and (i.split('.')[-1] == 'tgz' or i.split('.')[-1] == 'gz'):
            try :
                tar = tarfile.open(i, 'r:gz')
                print "\nContenu du fichier : " + i
                for tarinfo in tar:
                    print tarinfo.name, "is", tarinfo.size, "bytes in size and is",
                    if tarinfo.isreg():
                        print "a regular file."
                    elif tarinfo.isdir():
                        print "a directory."
                    else:
                        print "something else."
                tar.close()
            except OSError , (errno,strerror):
                print "OSerror (", str(errno), ") : ",str(strerror)
                p_Print_Error ("", CR_BL)
            except IOError :
                print "IOerror : anomalie dans le ficher tar"
                tar.close()
                p_Print_Error ("", CR_BL)
            except :
                p_Print_Error ("Erreur inconnue - sortie en code retour", CR_BL)
        else:
            if tarfile.is_tarfile(i):
                try :
                    tar = tarfile.open(i, 'r:')
                    print "\nContenu du fichier : " + i
                    for tarinfo in tar:
                        print tarinfo.name, "is", tarinfo.size, "bytes in size and is",
                        if tarinfo.isreg():
                            print "a regular file."
                        elif tarinfo.isdir():
                            print "a directory."
                        else:
                            print "something else."
                    tar.close()
                except OSError , (errno,strerror):
                    print "OSerror (", str(errno), ") : ",str(strerror)
                    p_Print_Error ("", CR_BL)
                except IOError :
                    print "IOerror : anomalie dans le ficher tar"
                    tar.close()
                    p_Print_Error ("", CR_BL)
                except :
                    p_Print_Error ("Erreur inconnue - sortie en code retour", CR_BL)
            else:
                p_Print_Error ("Le fichier %s place en argument n'est pas un fichier tar" %(i), CR_BL)



def p_Extract_Tarfile (input_filename, rep_extract, Mode_Compress):
    p_Debug ("Debut de la fonction p_Extract_Tarfile")
    p_Debug ("Extraction du contenu du fichier tar : "+input_filename)
    if rep_extract == None:
        vl_dest_untar = os.getcwd()
        p_Debug ("L'extraction se fera dans le repertoire COURRANT : "+vl_dest_untar)
    else:
        vl_dest_untar = f_Valorisation_Variable_System(rep_extract)
        p_Debug ("Le repertoire d'extraction sera le suivant : "+vl_dest_untar)
    vl_Liste_Tar = f_Liste_Fichiers(input_filename)
    p_Debug ("Liste de fichier Tar : "+str(vl_Liste_Tar))
    for i in vl_Liste_Tar:
        p_Debug ("element de la liste : "+str(i))
        if tarfile.is_tarfile(i) and (i.split('.')[-1] == 'tgz' or i.split('.')[-1] == 'gz'):
            p_Debug ("Le fichier "+str(i)+" est bien un fichier tar")
            try :
                tar = tarfile.open(i,'r:gz')
                print "\nContenu du fichier : " + i
                for tarinfo in tar:
                    print tarinfo.name, "is", tarinfo.size, "bytes in size and is",
                    if tarinfo.isreg():
                        print "a regular file."
                        tar.extract(tarinfo,vl_dest_untar)
                    elif tarinfo.isdir():
                        print "a directory."
                        tar.extract(tarinfo,vl_dest_untar)
                    else:
                        print "something else."
                tar.close()

            except OSError , (errno,strerror):
                print "OSerror (", str(errno), ") : ",str(strerror)
                p_Print_Error ("", CR_BL)
            except IOError :
                print "IOerror : anomalie dans le ficher tar"
                tar.close()
                p_Print_Error ("", CR_BL)
            except :
               p_Print_Error ("Erreur inconnue - sortie en code retour", CR_BL)
        else:
            if tarfile.is_tarfile(i):
                p_Debug ("Le fichier "+str(i)+" est bien un fichier tar")
                try :
                    tar = tarfile.open(i,'r:')
                    print "\nContenu du fichier : " + i
                    for tarinfo in tar:
                        print tarinfo.name, "is", tarinfo.size, "bytes in size and is",
                        if tarinfo.isreg():
                            print "a regular file."
                            tar.extract(tarinfo,vl_dest_untar)
                        elif tarinfo.isdir():
                            print "a directory."
                            tar.extract(tarinfo,vl_dest_untar)
                        else:
                            print "something else."
                    tar.close()

                except OSError , (errno,strerror):
                    print "OSerror (", str(errno), ") : ",str(strerror)
                    p_Print_Error ("", CR_BL)
                except IOError :
                    print "IOerror : anomalie dans le ficher tar"
                    tar.close()
                    p_Print_Error ("", CR_BL)
                except :
                   p_Print_Error ("Erreur inconnue - sortie en code retour", CR_BL)
            else:
                p_Print_Error ("Le fichier %s place en argument n'est pas un fichier tar" %(i), CR_BL)

def f_Liste_Fichiers(Multi_Tars):
    Liste_Fichiers = []
    p_Debug ("Fonction Liste_Fichiers")
    if (',' in Multi_Tars) :
        for Multi_Tar in Multi_Tars.split(","):
            Liste_Fichiers.extend(glob.glob(Multi_Tar))
    else :
        for Multi_Tar in Multi_Tars.split(" "):
            Liste_Fichiers.extend(glob.glob(Multi_Tar))
    if Liste_Fichiers == [] or None:
        p_Print_Error ("Fichier absent", CR_BL)
    else :
        p_Debug ("Listes des fichiers :\n"+(str(Liste_Fichiers)))
        return Liste_Fichiers

#*****************************************************************************************************************************  #
# definition des fonctions par system d exploitation
#*****************************************************************************************************************************  #

def f_Lancement_Windows():
    # global code_retour_fonction si pas modifie ...
    vl_Code_Retour = 0
    # print "debut de la fonction windows"

    # la commande que je veux executer
    if vg_Mode == "Extract":
        p_Extract_Tarfile(vg_Param_Tar, vg_Param_Directory_Extract, vg_Compress)

    if vg_Mode == "Create":
        p_Make_Tarfile(vg_Param_Tar, vg_Param_Input, vg_Compress)

    if vg_Mode == "Read":
        p_Read_Tarfile (vg_Param_Tar, vg_Compress)

    return vl_Code_Retour

def f_Lancement_Hpux():
    return f_Lancement_Windows()

def f_Lancement_Solaris():
    p_Print_Error("OS non supporte", CR_BL)

def f_Lancement_Linux():
    return f_Lancement_Windows()


#*****************************************************************************************************************************  #
# Main
#*****************************************************************************************************************************  #
if __name__ == "__main__":

    # Affiche la version
    print __VERSION + "\n"

    # Affiche la commande lancee
    p_Debug ("Execution de la commande : " + str(sys.argv))

    p_Param_Lg_Commande(sys.argv[1:])
    
    # ++++++++++++++++++++++++++++++++++

    #*****************************************************************************************************************************  #
    # Lancement de la commande selon la plateforme utilisee
    #*****************************************************************************************************************************  #

    if __SYSTEM == "win32":
            vl_Code_Retour = f_Lancement_Windows()
    elif __SYSTEM == "hp-ux11":
            vl_Code_Retour = f_Lancement_Hpux()
    elif __SYSTEM == "linux2":
            vl_Code_Retour = f_Lancement_Linux()
    elif __SYSTEM == "solaris":
            vl_Code_Retour = f_Lancement_Solaris()
    else:
            p_Print_Error("PF inconnue",CR_BL)


    #######################################
    # Verification du code retour         #
    #######################################
    if vl_Code_Retour not in (0, None):
        p_Print_Error("Erreur inattendue", CR_BL)
    else :
        vl_Code_Retour = CR_OK
    #######################################
    # Fin du Programme avec code_retour   #
    #######################################
    p_Print_Error("\nFin du programme. " ,vl_Code_Retour)



