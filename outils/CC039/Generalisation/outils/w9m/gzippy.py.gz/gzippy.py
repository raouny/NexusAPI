#!/usr/bin/python
# -*- coding: iso-8859-15 -*-

#****************************    Fiche signaletique shell  encodage: iso-8859-15    ****************************************    #
# Nom du programme : gzippy.py    But du programme : Gzip     Version minimum de l'interpreteur python : 2.4
#***********************************************    Syntaxe    **************************************************************   #
#                       gzippy.py -i file
#**********************************************    Historique    *************************************************************  #
# Version       Date            AUTEUR          ENTREPRISE      Commentaires
# 1.0          02/09/2011       J.TARRASSON        ProximIT        Creation
# 1.1          18/10/2011       C CHAPUT           La Poste        Bouchons linux /unix
# 2.0          15/06/2012       Y HERVE            La Poste        Re-ecriture du script sans gzip.exe + option force
#                                                                  + gestion multi-fichiers + mode decompression + modif mode Bouchon
# 2.1          13/08/2012       C CHAPUT           La Poste        Modification de la decompression suite incident + modification taille buffer
# 2.2          16/01/2013       Y HERVE            La Poste        D�compression des fichiers .gz uniquement sauf option nogzextend
# 2.3          17/01/2013       Y HERVE            La Poste        Correctif dysfonctionnement LPE-DSS-CCOBO-NOT-004 pb si version python < 2.7
# 2.4          04/06/2015       R SAVIGNY          GER - PIXON     Prise en compte des fichiers deja gzippes (copie des fichiers)
# 2.5          04/06/2015       R SAVIGNY          GER - PIXON     Detail de l'utilisation des caractere speciaux sous unix/linux
#**********************************************    Codes retour    ***********************************************************  #
# code 0: Normal - Code retour normal : L enchainement est poursuivi
# code 1: Warning - Detection d une anomalie : L enchainement peut etre poursuivi
# code 2: Warning - Detection d une anomalie : L enchainement peut etre poursuivi
# code 3: Critique - Erreur Critique
#*****************************************************************************************************************************  #

# Import des modules python
import os
import sys
import getopt
import gzip
import os.path
import glob
import mimetypes
from shutil import copyfile


# Definition des variables systeme
__SYSTEM = sys.platform
__PYTHON_VERSION = sys.version


# Definition des variables

vg_file_gzip = None
vg_decompress = None
vg_force_mode = False
vg_nogzextend_mode = False
vg_verbeux = False # Mode Verbeux permet un debuggage plus precis / l option -v n affiche pas les parametres en entree
vg_compress = 9 # taux de compression max, plus lent en temps de calcul
vg_preserve = False

# Variables globales des code retour
vg_bl=3
vg_wg=1


# Version du CC a completer
version = "gzippy.py v2.5 - python "+__PYTHON_VERSION+" - "+__SYSTEM

#*****************************************************************************************************************************  #
# Definitions des fonctions locales
#*****************************************************************************************************************************  #

#*****************************************************************************************************************************  #
# Fonction de test de presence de l argument obligatoire
#*****************************************************************************************************************************  #
def p_test_options():
        p_debugg("Test des arguments passes en entree du script ... ")

        if (( vg_file_gzip ) == None):
            print "*** au moins un argument est manquant ***"
            f_printusage(vg_bl)


        p_debugg("Les parametres obligatoires sont renseignes")


#*****************************************************************************************************************************  #
# Fonction d'aide a l utilisation du script
#*****************************************************************************************************************************  #

def f_printusage(err):
#   Affiche le message d utilisation du script
    print r"""
    gzippy.py <nom du fichier avec son chemin absolu>
              -->> possibilite de gerer une liste de fichier ccyyaaaa.\*

            parametres optionnels :
                [-d ou --decompress]    : decompression du .gz place en argument
                [--force]               : ecrase le fichier .gz si deja present
                [--preserve]            : ne supprime pas le fichier source
                [--nogzextend]          : compresse et decompresse les fichiers meme differents de .gz
                [--taux=]               : taux de compression par de 1 a 9.
                                          valeur par default = 9
                [-B ou --bouchon=]      : mode bouchon utilise par le CCO
                [--help]                : affiche l'aide
                [--debugg]              : mode "verbeux" debugg

            Sous UNIX / Linux les caracteres speciaux "*", "?", "[", "]" doivent etre precedes par le caractere "\"
            Exemples :
               La REGEX : l5x[at]aa?a.de    doit etre ecrite ainsi : l5x\[at\]aa\?a.de
               La REGEX : file*             doit etre ecrite ainsi : file\*
    """
    p_print_error("",err)


#*****************************************************************************************************************************  #
# Fonction de gestion des erreurs
#*****************************************************************************************************************************  #

def p_print_error(mesg, num):
    # retourne le message d erreur et sort en fonction du code retour
    print mesg
    print "Sortie en code retour " + str(num)
    sys.exit(num)


#*****************************************************************************************************************************  #
# Fonction de gestion des arguments passes en parametre de la ligne de commandes
#*****************************************************************************************************************************  #

def f_param_lg_commande():

    global vg_file_gzip
    global vg_decompress
    global vg_verbeux  # utiliser pour le debuggage
    global vg_force_mode
    global vg_nogzextend_mode
    global vg_compress
    global vg_preserve

    p_debugg("ligne de commande : "+ str(sys.argv) )

    #recuperation des arguments
    if len(sys.argv) == 1 :
        print "Parametre(s) manquant(s)"
        f_printusage(vg_bl)

    if sys.argv[1] == '-h' or sys.argv[1] == '--help' or sys.argv[1] == '-B' or '--bouchon' in sys.argv[1]:
        vl_arg = 1
    else:
        vg_file_gzip = sys.argv[1]
        vl_arg = 2
        p_debugg("nom du fichier en entree : "+ str(vg_file_gzip) )

    try:
        opts, args = getopt.getopt(sys.argv[vl_arg:], "dhB:", ["decompress","force","nogzextend","help","bouchon=","debugg","taux=","preserve"])

    except getopt.GetoptError, err:
        # print help information and exit:
        # will print something like "option -z not recognized"
        print "!!! ERREUR !!! l option n est pas reconnue : ", str(err)
        f_printusage(vg_bl)

    #test des arguments et enrichissement des variables
    for o, a in opts:
        p_debugg(str(o) +" , " + str(a))
        if o in ("-h", "--help"):
            f_printusage(vg_bl)
        elif o == ("--taux"):
            if a.isdigit():
                if int(a) not in range(10): p_print_error ("Taux de compression non compris entre 0 et 9",vg_bl)
                vg_compress = int(a)
                p_debugg("taux de compression : " + str(vg_compress))
            else:
                p_print_error ("Taux de compression non compris entre 0 et 9",vg_bl)
        elif o == ("--preserve"):
            vg_preserve = True
            p_debugg("mode preserve actif")
        elif o in ("-d", "--decompress"):
            vg_decompress = True
            p_debugg("mode decompress actif")
        elif o == ("--force"):
            vg_force_mode = True
            p_debugg("mode force actif")
        elif o == ("--nogzextend"):
            vg_nogzextend_mode = True
            p_debugg("mode all extension actif")
        elif o in ("-B", "--bouchon"):
            p_print_error("mode bouchon",int(a))
        elif o == ("--debugg"):
            vg_verbeux = True
            p_debugg("mode verbeux actif")
        else:
            assert False, "option invalide !!!"

    # test de presence des options obligatoires
    p_test_options()

    return True

def p_debugg(chaine):
    if vg_verbeux : print str(chaine)


def f_valorisation_var_system(chemin):
    # permet de valoriser des $ sous unix ou % sous windows
    if chemin != None :
        resultat = os.path.expandvars(chemin)
        p_debugg("Resultat de la valorisation " + str(resultat))
    return resultat

def p_gzip(fichier_gziper_in,fichier_gziper_out):
    p_debugg("Debut de la fonction p_gzip")
    try :
        p_debugg("Nom du fichier a gzipper: "+fichier_gziper_in)
        f_in = open(fichier_gziper_in, 'rb',-1)
        p_debugg("Nom du fichier gzipper: "+fichier_gziper_out)
        directory = os.path.dirname(fichier_gziper_in+"\"")
        os.chdir(directory)
        p_debugg("Repertoire de travail: "+ directory)
        nom_fic = fichier_gziper_out[len(directory)+1:]
        p_debugg("Nom du fichier sans le path: "+nom_fic)
        f_out = gzip.GzipFile(filename=nom_fic, mode='w+b', compresslevel=vg_compress)
        try :
            buff = f_in.read(4096)
            while buff :
                f_out.write(buff)
                buff = f_in.read(4096)

        finally:
            f_out.flush()
            f_out.close()
            f_in.close()
        
        print "Fichier traite :", fichier_gziper_in
    except OSError , (errno,strerror):
        print "OSerror (", str(errno), ") : ",str(strerror)
        p_print_error ("", vg_bl)
    except IOError , (errno,strerror):
        print "IOerror (", str(errno), ") : ",str(strerror)
        p_print_error ("", vg_bl)
    except :
        p_print_error ("Erreur inconnue - sortie en code retour", vg_bl)

def p_gunzip(fichier_gziper_in,fichier_nogzip_out):
    p_debugg("Debut de la fonction p_gunzip")
    try :
        f_in = gzip.GzipFile(fichier_gziper_in, 'rb');
        f_out = open(fichier_nogzip_out, "wb",-1)
        f_out.writelines(f_in)
        f_in.close()
        f_out.close()
        print "Fichier traite :", fichier_gziper_in

    except OSError , (errno,strerror):
        print "OSerror (", str(errno), ") : ",str(strerror)
        p_print_error ("", vg_bl)
    except IOError :
        print "IOerror : anomalie dans le ficher gz"
        f_out.close()
        p_supp_fic (fichier_nogzip_out)
        p_print_error ("", vg_bl)
    except :
        p_print_error ("Erreur inconnue - sortie en code retour", vg_bl)

def p_supp_fic(le_fichier):
    try :
        os.remove(le_fichier)
    except OSError , (errno,strerror):
        print "OS error (", str(errno), ") : ",str(strerror)
        p_print_error ("Erreur lors de la suppression du fichier", vg_bl)


def f_compression_file(fichier_in,char_os):
    print "Debut de la fonction de gzip du fichier"

    # valorise les variables system
    nom_absolu_fichier_entree = f_valorisation_var_system(fichier_in)
    vl_path_fic_in = nom_absolu_fichier_entree
    p_debugg("test existence du path")
    if os.path.dirname(vl_path_fic_in) == "":
        nom_absolu_fichier_entree = os.getcwd()+char_os+vl_path_fic_in

    #Test la presence du fichier a gzipper
    if os.path.isfile(nom_absolu_fichier_entree) == False :
        p_print_error("Le fichier : " + nom_absolu_fichier_entree + " n existe pas",vg_wg)

    p_debugg("Debut de la fonction de compression gzip du fichier en entree")

    # Ecrase le fichier .gz si option --force presente
    nom_absolu_fichier_sortie=nom_absolu_fichier_entree + '.gz'

    if vg_preserve == True and vg_nogzextend_mode == True:
         p_print_error("Les deux options --preserve et --nogzextend ne sont pas compatibles et ne peuvent pas �tre utilis�es simultan�ment",vg_bl)

    type = mimetypes.guess_type(nom_absolu_fichier_entree)
    if ('gzip' not in type) :
        if vg_nogzextend_mode == False:
            if vg_force_mode == True:
                p_debugg ("Nom du fichier en sortie: "+nom_absolu_fichier_sortie)
                if os.path.isfile(nom_absolu_fichier_sortie) == False :
                    p_gzip(nom_absolu_fichier_entree,nom_absolu_fichier_sortie)
                else :
                    p_supp_fic(nom_absolu_fichier_sortie)
                    p_gzip (nom_absolu_fichier_entree,nom_absolu_fichier_sortie)
            else :
                if os.path.isfile(nom_absolu_fichier_sortie) == False :
                    p_gzip (nom_absolu_fichier_entree,nom_absolu_fichier_sortie)
                else :
                    p_print_error ("le fichier de sortie existe deja", vg_bl)
        else:
            nom_absolu_fichier_sortie=nom_absolu_fichier_entree
            nom_absolu_fichier_tempo=nom_absolu_fichier_entree + '.tmpgz'
            p_gzip (nom_absolu_fichier_entree,nom_absolu_fichier_tempo)
            p_supp_fic(nom_absolu_fichier_entree)
            os.renames(nom_absolu_fichier_tempo, nom_absolu_fichier_sortie)
        if vg_preserve == False and vg_nogzextend_mode == False :
            p_supp_fic(nom_absolu_fichier_entree)
    else:
        p_debugg("Fichier : "+nom_absolu_fichier_entree+", deja gzipper on ne fait rien")

    p_debugg("Compression terminee")
    return 0

def f_decompression_file(fichier_in):

    if vg_preserve == True and vg_nogzextend_mode == True:
         p_print_error("Les deux options --preserve et --nogzextend ne sont pas compatibles et ne peuvent pas �tre utilis�es simultan�ment",vg_bl)
    else:
        nom_absolu_fichier_entree = f_valorisation_var_system(fichier_in)
        if nom_absolu_fichier_entree.split(".")[-1] == "gz" :
            nom_absolu_fichier_sortie = '.'.join(nom_absolu_fichier_entree.split('.')[:-1])
            # Ecrase le fichier .gz si option --force presente
            if vg_force_mode == True :
                if os.path.isfile(nom_absolu_fichier_sortie) == False :
                    p_gunzip(nom_absolu_fichier_entree,nom_absolu_fichier_sortie)
                else :
                    p_supp_fic(nom_absolu_fichier_sortie)
                    p_gunzip (nom_absolu_fichier_entree,nom_absolu_fichier_sortie)
            else :
                if os.path.isfile(nom_absolu_fichier_sortie) == False :
                    p_gunzip (nom_absolu_fichier_entree,nom_absolu_fichier_sortie)
                else :
                    p_print_error ("le fichier de sortie existe deja", vg_bl)

            if vg_preserve == False :
                p_supp_fic(nom_absolu_fichier_entree)
        else:
            if vg_nogzextend_mode == True:
                nom_absolu_fichier_sortie = nom_absolu_fichier_entree
                nom_absolu_fichier_tempo = nom_absolu_fichier_entree+'.tmpgz'
                p_gunzip (nom_absolu_fichier_entree,nom_absolu_fichier_tempo)
                p_supp_fic (nom_absolu_fichier_entree)
                os.renames(nom_absolu_fichier_tempo, nom_absolu_fichier_sortie)
            else:
                p_print_error ("Il n'y a pas de fichier gz a d�compresser, eventuellement utiliser l'option --nogzextend", vg_bl)

    return 0


def lancement(char_os):
    code_retour = 56
    if ( f_param_lg_commande() != True):
            p_print_error("sortie du programme en CR 3",vg_bl)
    if vg_decompress == True :
        print "Mode decompression active"
        list = glob.glob(vg_file_gzip)
        if list == [] :
            p_print_error("Pas de fichier en entree",vg_wg)
        for fichier in glob.glob(vg_file_gzip):
            code_retour = f_decompression_file(fichier)
    else :
        print "Mode compression active"
        list = glob.glob(vg_file_gzip)
        if list == [] :
            p_print_error("Pas de fichier en entree",vg_wg)
        for fichier in list:
            code_retour = f_compression_file(fichier,char_os)
    return code_retour

#*****************************************************************************************************************************  #
# Main
#*****************************************************************************************************************************  #
if __name__ == "__main__":
    # Variables du programme principal

    #Variable code_retour
    #Elle est positionnee avec un code retour different de 0 afin que la fonction modifie sa valeur
    code_retour = 56

    # Affiche la version
    print version + "\n"


    #*****************************************************************************************************************************  #
    # Lancement de la commande selon la plateforme utilisee
    #*****************************************************************************************************************************  #

    if __SYSTEM == "win32":
        char_os = "\\"
        code_retour = lancement(char_os)
    elif __SYSTEM == "hp-ux11":
        char_os = "/"
        code_retour = lancement(char_os)
    elif __SYSTEM == "linux2":
        char_os = "/"
        code_retour = lancement(char_os)
    else:
        print "Plateforme inconnue - sortie en CR 3"
        print_error(vg_bl)


    #######################################
    # Verification du code retour         #
    #######################################
    if code_retour not in (0,1, None):
            p_print_error ("Erreur inattendue - sortie en CR :", vg_bl)

    #######################################
    # Fin du Programme avec code_retour   #
    #######################################
    p_print_error ("Fin du programme", code_retour)

