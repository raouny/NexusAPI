#!/bin/ksh
########################################## Variables essentielles #######################################################
if [ $OUTILEXP/shells.diff ]
then
        . /procedure/outils/exploitation/shells.diff # Particularites shells des differents Unix
else
        echo "ERREUR: fichier source ${OUTILEXP}/shells.diff inexistant, traitement interrompu" && exit 3
fi
IDDATE=$(date '+%y%m%d%H%M%S') # Identifiant date
SHLLNAME=$(basename $0) # Nom des fichiers issus du shell
VERSION=" $SHLLNAME v2.4 - sur systeme $__SYSTEM $__DISTRIBUTION\n" # VERSION du shell (a changer a chaque modif)
RETCODE=0 # Code retour des traitements
LOGFILE=$TRACES/${IDDATE}.${SHLLNAME}.log # Fichier de log
########################################## Valeurs par defaut ############################################################
verbose="true" #${verbose:-""}
EXPREG=${EXPREG:-""}
HISTO=${HISTO:-""}
COMPRESS=${COMPRESS:-""}
DIRECTORY=${DIRECTORY:-""}
RECURSIVE=${RECURSIVE:-""}
NON_RECURSIVE=${NON_RECURSIVE:-""}
typeset -i  i=1 && typeset -i  j=1 && typeset -i  HEAD=0 && typeset -i RETENTION
#########################################Fichiers temporaires#############################################################
TMPRET=/tmp/${SHLLNAME}_$$.ret
TMPFILE=/tmp/${SHLLNAME}_$$.tmp
TMPFILE2=/tmp/${SHLLNAME}2_$$.tmp
TMPREP=/tmp/${SHLLNAME}_$$.rep
TMPEXP=/tmp/${SHLLNAME}_$$.exp
##########################################FONCTIONS#######################################################################
testvariable() # Test des variables du .profile
{
                [ -z "${TRACES}" ] && echo "La variable TRACES n'est pas positionnee. Renseignez-la et recommencez." && exit 3
                LOGFILE=${TRACES}/${IDDATE}.${SHLLNAME}.log
                if [ ! -d ${TRACES} ]
                then echo "le repertoire de traces $TRACES specifie dans le .profile n'existe pas" && exit 2
                fi
                touch $LOGFILE
                if [ $? -ne 0 ]
                then echo "verifier les droits d'ecriture sur le repertoire de traces $TRACES" && exit 2
                fi
}

verbose () # Fonction de logging
{
            [ "$SAYVER" ] && echo "\n$*" && return # Juste pour afficher la VERSION
            [ "verbose" ] && echo "\n$*" | tee -a $LOGFILE
}

Usage () # Usage du shell pour l'utilisateur
{
   [ "$1" ] && verbose "\n$SHLLNAME: $*"
   echo "
   $VERSION

   Usage:     $SHLLNAME
   !!Les parametres suivants sont obligatoires:!!
   -R: repertoire racine a purger
  (-D: retention des objets a purger ou -Q: nombre de VERSIONs des fichiers cibles a conserver)
   !Les parametres suivants sont optionnels:!
   -E: expression(s) reguliere(s) des fichiers a supprimer
   -H: historisation souhaitee des fichiers (liee a l'option -E et incompatible avec l'option -d)
   -C: compression des fichiers a historiser (liee a l'option -H et incompatible avec l'option -d)
   -d: indique que les objets a purger seront de type repertoire (l'option -E doit lui etre associee mais pas l'option -d)
   -N: indique que la purge ne sera pas RECURSIVE
   -r: indique que la purge sera recursive
   -P: pourcentage d'occupation du filesystem avant suppression
   "
}

TauxOccupation () # Taux d'occupation du repertoire cible
{
  TOCCUP=$(df ${NOMREP} | awk '{print $4}' | sed s/Available//| sed s/%// | tail -n 1)
}

CodeRetour () # Sortie du traitement et gestion du code retour
{
    CODE=$1 ; shift
    RAISON=$*
    echo "$CODE" >> ${TMPRET}
    case $CODE in
        0)
        verbose "SUCCES: =>> $RAISON"
           ;;
        1)
            verbose "ATTENTION: =>> $RAISON"
            ;;
        2)
            verbose "ATTENTION: =>> $RAISON"
            verbose "\t\t*** Arret du programme ***\n"
            RETCODE=$(cat ${TMPRET} |sort -n -u |tail -1)
            verbose " $(grep -c '[^0]' $TMPRET) Erreur(s) , code retour le plus haut : ${RETCODE}\n"\
                "# ~~~~ ----+ verifiez le resultat du script dans: $LOGFILE\n"\
                "# ~~~~ _________________________________________________________________________\n"\
                "# ~~~~ -=-=-=-=-=-= Fin du script $SHLLNAME. Code retour: $RETCODE =-=-=--=-=-="
            exit $CODE;
            ;;
        3)
            verbose "ERREUR: =>> $RAISON"
            verbose "\t\t*** Arret du programme ***\n"
            RETCODE=$(cat ${TMPRET} |sort -n -u |tail -1)
            verbose " $(grep -c '[^0]' $TMPRET) Erreur(s) , code retour le plus haut : ${RETCODE}\n"\
                "# ~~~~ ----+ verifiez le resultat du script dans: $LOGFILE\n"\
                "# ~~~~ _________________________________________________________________________\n"\
                "# ~~~~ -=-=-=-=-=-= Fin du script $SHLLNAME. Code retour: $RETCODE =-=-=--=-=-="
            exit $CODE;
            ;;
    esac
}

Suppression() # Suppression des rertoires
{
                cat $NOMSUP|while read ligne # On lit le fichier temporaire
                do
                        rm -$MODE $ligne; # pour chaques lignes trouvs on supprime
                done
}

Debug() # Moyen simple de deboguer le script
{
        DEBUG=${DEBUG:=0} # passer 1 pour activer
        if [[ ${DEBUG} -gt 0 ]]; then
            echo "Mode DEBUG active. Mise en place des traps." && set -x
            trap 'verbose "DEBUG: Ligne $LINENO"' DEBUG && trap 'verbose "ERREUR LIGNE: $LINENO" ' ERR
        fi
}

Cartouche() # Affichage du cartouche
{
        verbose "\n\t VERSION\n"
        verbose " # ~~~~ NOM DU PROGRAMME : kill_traces.sh\n"\
        "# ~~~~ BUT DU PROGRAMME : suppression de fichiers traces\n"\
        "# ~~~~**** Resume du lancement: ****\n"\
        "# ~~~~Arguments passes au script :\n"\
        "# ~~~~ ----+ $ARGSS +----\n"\
        "# ~~~~Fichiers temporaires: ...........\n"\
        "# ~~~~ ----+ Code retour : ....... $TMPRET\n"\
        "# ~~~~Fichier resultat a consulter: $LOGFILE\n"\
        "# ~~~~ _________________________________________________________________________\n"
}

Test() # Test des arguments du script
{
        [ -z "${REPERTOIRE}" ] && Usage "Aucun repertoire specifie (option -R). Arret du programme." && exit 2
        if [ -z "${RETENTION}" -a -z "${QUANTITE}" ]
        then Usage "Aucune retention specifiee (option -D) ni aucun nombre de VERSIONs a conserver (option -Q). Arret du programme." && exit 2
        fi
        if [ "${RETENTION}" -a "${QUANTITE}" ]
        then Usage "les options -D et -Q sont exclusives" && exit 2
        fi
        if [ -z "${EXPREG}" -a "${HISTO}" ]
        then Usage "L'historisation (option -H) implique l'option -E." && exit 2
        fi
        if [ "${DIRECTORY}" -a -z "${EXPREG}" ]
        then Usage "La purge d'objets de type repertoire implique l'option -E." && exit 2
        fi
        if [ "${DIRECTORY}" -a "${HISTO}" ]
        then Usage "La purge d'objets de type repertoire est incompatible avec l'historisation" && exit 2
        fi
        if [ "${DIRECTORY}" -a "${QUANTITE}" ]
        then Usage "La purge d'objets de type repertoire est incompatible avec un nombre de VERSION a garder" && exit 2
        fi
        if [ "${DIRECTORY}" -a "${COMPRESS}" ]
        then Usage "La purge d'objets de type repertoire est incompatible avec la compression" && exit 2
        fi
        if [ "${DIRECTORY}" -a "${NON_RECURSIVE}" ]
        then Usage "La purge d'objets de type repertoire est incompatible avec la non-recursivite" && exit 2
        fi
        if [ "${RECURSIVE}" -a "${NON_RECURSIVE}" ]
        then Usage "La rursivitest incompatible avec la non-recursivite" && exit 2
        fi
}

RecRep() # Recherche du nombre de repertoires racine a purger
{
        echo "${REPERTOIRE}">$TMPREP && IMAX=$(sed 's/,/ /g' $TMPREP|wc -w)
        CodeRetour $? "Nombre de repertoires racine passes en parametres: $IMAX"
}

RecExp() # Recherche du nombre d'expressions regulieres (si renseignees)
{
        if [ -n "${EXPREG}" ]
        then echo "${EXPREG}">$TMPEXP && JMAX=$(sed 's/,/ /g' $TMPEXP|wc -w)
             CodeRetour $? "Nombre d'expressions regulieres passees en parametres: $JMAX"
        else echo '*'>$TMPEXP && JMAX=1 && verbose "Aucune expression reguliere passee en parametre"
        fi
}

Principal() # Fonction principale
{
        while [ $IMAX -ge $i ] # Boucle pour chaque repertoire racine passe en parametre
        do
                NOMREP=$(cut -d, -f"${i}" $TMPREP)
                CodeRetour $? "Le repertoire ${NOMREP}, contenant les fichiers a purger, "
                if [ ! -d ${NOMREP} ]
                then CodeRetour 2 "n'existe pas."
                else CodeRetour 0 "existe."
                fi
                while [ $JMAX -ge $j ] # Boucle pour chaque expression reguliere passee en parametre
                do
                        NOMEXP=$(cut -d, -f"${j}" $TMPEXP)
                        CodeRetour $? "Initialisation du traitement de l'expression reguliere ${NOMEXP}"
                        if [ ${HISTO} ] # Historisation si parametre renseigne
                        then
                                verbose "Historisation des fichiers demandee"
                                find ${NOMREP} -type f -name "${NOMEXP}"|grep -v .old > $TMPFILE
                                if [ $? -gt 1 ]
                                then CodeRetour 3 "probleme lors de la recherche des fichiers historises"
                                else  CodeRetour 0 "Recherche des fichiers historises"
                                fi
                                if [ $NON_RECURSIVE ] # si -N est positionne, on ne laisse dans TMPFILE que les fichiers a la racine de NOMREP
                                then
                        touch $TMPFILE2
                        cat $TMPFILE|while read nom_absolu
                        do
                           if [ $NON_RECURSIVE ]; then
                                ########## On se dedouane des fichiers presents dans les sous-repertoires
                                if [ "$(dirname ${nom_absolu})" = "${NOMREP}" ]; then
                                        echo $nom_absolu >> $TMPFILE2
                                fi
                           else
                                echo $nom_absolu >> $TMPFILE2
                           fi
                        done
                        mv $TMPFILE2 $TMPFILE
                                fi
                                if [ -s $TMPFILE ]
                                then
                        cat $TMPFILE|while read ligne
                        do
                           cp -p ${ligne} ${ligne}.${IDDATE}.old
                           if [ $? -ne 0 ]
                           then CodeRetour 3 "Historisation du fichier ${ligne}"
                           else CodeRetour 0 "Historisation du fichier ${ligne}"
                           fi
                           if [ $COMPRESS ]
                           then verbose "compression demandee des fichiers a historiser"
                                if [ -s ${ligne}.${IDDATE}.old ]
                                then compress ${ligne}.${IDDATE}.old
                                     if [ $? -ne 0 ]
                                     then CodeRetour 1 "probleme de compression de ${ligne}.${IDDATE}.old"
                                     else verbose "compression reussie de ${ligne}.${IDDATE}.old"
                                     fi
                                else verbose "fichier vide: compression inutile"
                                fi
                           fi
                           >${ligne}
                           if [ $? -ne 0 ]
                           then CodeRetour 3 "Reinitialisation du fichier ${ligne}"
                           else CodeRetour 0 "Reinitialisation du fichier ${ligne}"
                           fi
                        done
                   else CodeRetour 0 "aucun fichier a historiser"
                   fi
                   if [ $COMPRESS ]
                   then NOMEXP=${NOMEXP}.*.old.Z
                   else NOMEXP=${NOMEXP}.*.old
                   fi
              fi
              # Suppression effective des objets

              if [ $DIRECTORY ] # Si condition -d
              then      OBJET="repertoire(s)" # On passe le mode en recursif pour des rertoires
                        TYPE=d && MODE=fR
              else      OBJET="fichier(s)" # Sinon fichier
                        TYPE=f && MODE=f
              fi

              if [ ${RETENTION} ] # Si condition -D
              then
              TauxOccupation
                  if [ $OCCUPATION ] && [ "$TOCCUP" -ge "$OCCUPATION" ]
                  then
                      CAR=60 && MODE=fR && nbobjetsup=0 && temoin2=1
                      MTIME="-mtime +${RETENTION}"
                      if [ ${RETENTION} -eq 0 ]
                      then MTIME="-mtime +$CAR" && temoin=1
                      fi
                      NOMSUP=/tmp/nomsrep_$$.tmp && MODE=fR && NBOBJETSFIC=0
                      while [ "$TOCCUP" -ge "$OCCUPATION" ] && [ "$temoin2" -ne "-1" ]
                      do
                        find $NOMREP -name "${NOMEXP}" $MTIME > $NOMSUP
                        nbobjetsup=$(wc -l $NOMSUP | awk '{print $1}')
                        let NBOBJETSFIC=NBOBJETSFIC+nbobjetsup
                        cat $NOMSUP|while read ligne # On lit le fichier temporaire
                        do
                          if [ $NON_RECURSIVE ]; then
                                ######### On se dedouane des fichiers presents dans les sous-repertoires
                                if [ "$(dirname ${ligne})" = "${NOMREP}" ]; then
                                        rm -$MODE $ligne &2>/dev/null # pour chaques lignes trouvs on supprime
                                fi
                          else
                                rm -$MODE $ligne &2>/dev/null # pour chaques lignes trouv^As on supprime
                          fi
                        done
                        if [ $temoin2 -eq "0" ]
                        then
                            MTIME="-mtime 0"
                            find $NOMREP -name "${NOMEXP}" $MTIME > $NOMSUP
                            cat $NOMSUP|while read ligne # On lit le fichier temporaire
                            do
                              if [ $NON_RECURSIVE ]; then
                                ######### On se dedouane des fichiers presents dans les sous-repertoires
                                if [ "$(dirname ${ligne})" = "${NOMREP}" ]; then
                                        rm -$MODE $ligne &2>/dev/null # pour chaques lignes trouv^As on supprime
                                fi
                              else
                                rm -$MODE $ligne &2>/dev/null # pour chaques lignes trouvs on supprime
                              fi
                            done
                        fi
                            TauxOccupation
                            if [ ${temoin} ]
                            then
                                let CAR=CAR-1
                                MTIME="-mtime +$CAR" # Compte a rebours pour le mtime
                                temoin2=$CAR
                            else
                                let RETENTION=RETENTION-1
                                MTIME="-mtime +$RETENTION" # Compte a rebours pour le mtime
                                temoin2=$RETENTION
                            fi
                      done
                      if [ ! -e "$NOMREP" ]
                      then
                          mkdir $NOMREP && chmod 777 $NOMREP
                      fi
                      if [ $RETENTION -eq "-1" ]
                      then RETENTION=0;
                      fi
                      if [ "${EXPREG}" ]
                      then verbose "Suppression du/des $OBJET $NOMEXP de plus de $RETENTION jours du repertoire racine ${NOMREP}"
                      else verbose "Suppression de tous les $OBJET de plus de $RETENTION jours du repertoire racine ${NOMREP}"
                      fi
                      CodeRetour $? "suppression de $NBOBJETSFIC fichier(s) et rertoire(s)"
                  else

                                if [ "$(echo $RETENTION | grep "^[ [:digit:] ]*$")" ] # Vifie si null ou non entier
                                then
                                        if [ ${RETENTION} -gt 0 ] # Si strictement supieur 0
                                        then MTIME="-mtime +${RETENTION}"
                                        fi
                                        if [ ${RETENTION} -eq 0 ] # Si ale 0
                                        then MTIME=""
                                        fi
                                        if [ "${EXPREG}" ]
                                        then verbose "Suppression du/des $OBJET $NOMEXP de plus de $RETENTION jours du repertoire racine ${NOMREP}"
                                        else verbose "Suppression de tous les $OBJET de plus de $RETENTION jours du repertoire racine ${NOMREP}"
                                        fi
                                else
                                        MTIME=""
                                        echo "!!Attention!! Erreur de saisie, aucun entier positif passen paramre, valeur 0 prise par daut"
                                        RETENTION=0 # On repasse zos pour ne pas avoir de rultat incohent
                                        if [ "${EXPREG}" ]
                                        then verbose "Suppression du/des $OBJET $NOMEXP de plus de $RETENTION jours du repertoire racine ${NOMREP}"
                                        else verbose "Suppression de tous les $OBJET de plus de $RETENTION jours du repertoire racine ${NOMREP}"
                                        fi
                                fi
                                if [ $RECURSIVE ] # Si condition -r
                                then
                                        NBOBJETSFIC=$(find ${NOMREP} -type f -name "${NOMEXP}" $MTIME|wc -l) # On cherche le nombre de fichiers
                                        NBOBJETSREP=$(find ${NOMREP} -type d -name "${NOMEXP}" $MTIME|wc -l) # On cherche le nombre de rertoires
                                        NOMSUP=/tmp/nomsrep_$$.tmp && MODE=fR # Mode rursif
                                        if [ $DIRECTORY ] # Si condition -d
                                        then find $NOMREP -name "${NOMEXP}" $MTIME > $NOMSUP && Suppression # On rcupe tout les noms de rertoires dans un fichier
                                        fi

                                        if [ ! $DIRECTORY ] # Sinon
                                        then find $NOMREP -type $TYPE -name "${NOMEXP}" $MTIME -exec rm -$MODE {} \; # On supprime tous les fichiers
                                                CALC=`expr $NBOBJETSREP - 1` # Calcul du nombre de rertoires sans le rertoire racine
                                                NBOBJETSREP=$CALC # On renseigne la variable NBOBJETSREP
                                                find $NOMREP -name "${NOMEXP}" $MTIME|tail -n $NBOBJETSREP > $NOMSUP
                                                ## On test si le fichier est vide
                                                if [ -s $NOMSUP ] # Si le fichier n'est pas vide
                                                then Suppression # On supprime
                                                fi
                                                if [ $NBOBJETSREP -le 0 ] # Si suppression de fichier alors NBOBJETSREP vaut moins de 0
                                                then NBOBJETSREP=0 # On attribue la valeur 0 pour un rultat cohent
                                                fi
                                        fi
                                        rm -f $NOMSUP # Suppression du fichier temporaire
                                else
                                        NBOBJETSREP=0 ; NBOBJETSFIC=0
                                        # find $NOMREP -type $TYPE -name "${NOMEXP}" $MTIME -exec rm -$MODE {} \; # On supprime tous les fichiers !!! et que fait-on de -N ?!!!!!
                                        find $NOMREP -type $TYPE -name "${NOMEXP}" $MTIME > $TMPFILE
                                        cat $TMPFILE |while read nom_absolu
                                        do
                                                if [ $NON_RECURSIVE ]; then
                                                        ######### On se dedouane des fichiers presents dans les sous-repertoires
                                                        if [ "$(dirname ${nom_absolu})" = "${NOMREP}" ]; then
                                                                rm -$MODE $nom_absolu
                                                                let NBOBJETSFIC=$NBOBJETSFIC+1
                                                        fi
                                                else
                                                        rm -$MODE $nom_absolu
                                                        let NBOBJETSFIC=$NBOBJETSFIC+1
                                                fi
                                        done
                                fi
                                CodeRetour $? "suppression de "$NBOBJETSFIC "fichier(s) et "$NBOBJETSREP "rpertoire(s)"
                        fi
                        else if [ "${EXPREG}" ] # forcement on est dans le cas ou l'option -Q a ete positionnee
                                then verbose "Conservation au maximum des $QUANTITE dernieres VERSIONs des $OBJET $NOMEXP du repertoire racine ${NOMREP}"
                                else verbose "Conservation au maximum des $QUANTITE dernieres VERSIONs de tous les $OBJET du repertoire racine ${NOMREP}"
                                fi
                                NBOBJETS=$(find ${NOMREP} -type $TYPE -name "${NOMEXP}"|wc -l) && HEAD=`expr $NBOBJETS - $QUANTITE`
                                if [ ${HEAD} -gt 0 ]
                                then find ${NOMREP} -type $TYPE -name "${NOMEXP}" |xargs ls -rt|head -$HEAD|xargs rm -$MODE
                        CodeRetour $? "suppression de "$HEAD "$OBJET"
                                else verbose "le nombre de VERSIONs a conserver est superieur au nombre de fichiers existants: rien a faire"
                                fi
                        fi
                        let j=j+1
                done
                j=1 && let i=i+1
        done
}

AfficheErreur() # Affiche les erreurs
{
        RETCODE=$(cat ${TMPRET} |sort -n -u |tail -1)
        verbose " $(grep -c '[^0]' $TMPRET) Erreur(s) , code retour le plus haut : ${RETCODE}\n"\
        "# ~~~~ ----+ verifiez le resultat du script dans: $LOGFILE\n"\
        "# ~~~~ -=-=-=-=-=-= Fin du script $SHLLNAME. Code retour: $RETCODE =-=-=--=-=-="
}

SortieCodeRetour() # Sortie avec code retour final egal au code retour le plus haut identifie
{
        if [ -f $TMPRET ]
        then rm $TMPRET
        fi
        if [ -f $TMPFILE ]
        then rm $TMPFILE
        fi
        if [ -f $TMPREP ]
        then rm $TMPREP
        fi
        if [ -f $TMPEXP ]
        then rm $TMPEXP
        fi
        exit $RETCODE
}
############################################Affectation des arguments####################################################
        ARGSS="$*"
        while getopts R:D:Q:E:P:HCdNVr OPT
        do
                case ${OPT} in
                        R) REPERTOIRE="${OPTARG}" ;;
                        D) RETENTION="${OPTARG}" ;;
                        Q) QUANTITE="${OPTARG}" ;;
                        E) EXPREG="${OPTARG}" ;;
                        P) OCCUPATION=${OPTARG} ;;
                        H) HISTO="true" ;;
                        C) COMPRESS="true" ;;
                        d) DIRECTORY="true" ;;
                        N) NON_RECURSIVE="true" ;;
                        r) RECURSIVE="true" ;;
                        V) SAYVER="true"
                        verbose "VERSION"
                        exit 0 ;;
                        ?) echo "Option non valide: -$OPTARG"
                        Usage
                        exit 3 ;;
                esac
        done
################################################PROGRAMME################################################################
        testvariable                                                                                                    #
        Debug                                                                                                           #
        Cartouche                                                                                                       #
        Test                                                                                                            #
        RecRep                                                                                                          #
        RecExp                                                                                                          #
        Principal                                                                                                       #
        AfficheErreur                                                                                                   #
        SortieCodeRetour                                                                                                #
#########################################################################################################################
