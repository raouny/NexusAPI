#!/bin/bash

#################################################################################
# Description : Copie de fichiers via ssh					#
#										#
# Version 1.0 du 16/10/2008 - Sebastien Morey					#
#										#
# Le script prend en parametre							#
# -e: option qui indique de supprimer les fichiers sur le repertoire distant	#
# hostname : indique le nom du serveur distant					#
# fichier : indique les fichiers a rapatrier, mettre des "" si on utilise les	#
#		caracteres jokers comme *					#
# local : indique le repertoire local de telechargement des fichiers		#
# utilisateur : option pour indiquer l utilisateur de la machine distante.	#
#	si non precise, c est le meme nom que l'utilisateur courant local qui	#
#	est utilise.								#
#										# 
#     !!!!! ATTENTION !!!!							#
# Le script utilise une authentification par jeu de cle publique/privee		#
# Le pre-requis est de verifier le fonctionnement de la connexion par cle	#
# comme indique dans le document copiesecurisee.doc				#
#################################################################################

## Gestion des arguments

if [[ $# -le 0 ]]
then
	echo "Utilisation du script"
	echo "copiesecurisee.sh [-e] <hostname> <fichier> <local> [utilisateur]"
	exit 3
fi

Efface=0
User=`id -un`

if [[ $1 = "-e" ]]
then
# Si -e est specifie, il doit y avoir en tout 4 ou 5 argument
	if [[ $# -lt 4 ]]
	then
	echo "Le nombre de parametre est inferieur 4..."
	exit 3
	fi
	Efface=1
	HostDest=$2
	FicDest=$3
	RepLocal=$4
	if [[ $# -eq 5 ]]
	then
		User=$5
	fi
else
	if [[ $# -lt 3 ]]
	then
	echo "Le nombre de parametre est inferieur a 3..."
	exit 3
	fi
	Efface=0
	HostDest=$1
	FicDest=$2
	RepLocal=$3
	if [[ $# -eq 4 ]]
	then
		User=$4
	fi
fi


echo "Lancement de la commande : scp $User@$HostDest:$FicDest $RepLocal"
scp $User@$HostDest:$FicDest $RepLocal
if [[ $? -ne 0 ]]
then
	echo "Probleme avec la copie."
	exit 3
fi

if [[ $Efface -eq 1 ]]
then
	ssh $HostDest "rm -f $FicDest"
	if [[ $? -ne 0 ]]
	then
		echo "Probleme avec la suppression sur la machine distante."
		exit 3
	fi
fi
