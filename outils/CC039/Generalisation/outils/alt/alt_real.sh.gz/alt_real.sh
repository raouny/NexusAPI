#!/bin/sh
# ------------------------------------------------------------------------------
# Description
#
#	Méta-Script d'encapsulation des scripts Alteon. Permet de lancer un seul
#	script, indifféremment de la plateforme d'utilisation.
#
#	./alt_real.sh [arg1] ... [argN]
#
#	    - Si HP-UX :
#		. vérification présence sous-script [alt_real.ksh] (+droits exec),
#		. vérification présence binaire [ksh],
#		. exécution : binaire + sous-script + arguments (arg1 ... argN).
#	    - Si Linux :
#		. vérification présence sous-script [alt_real.exp] (+droits exec),
#		. vérification présence binaire [expect],
#		. exécution : binaire + sous-script + arguments (arg1 ... argN).
#
# Code Retour
#	En cas d'erreur avant exécution du sous-script, code retour 3
#	Sinon, code retour = celui du sous-script exécuté.
#
# ------------------------------------------------------------------------------
#
# 2014-06-26 [FV] 1.2 Adaptation pour Script Alteon 3.2
# 2014-05-26 [FV] 1.1 Adaptation pour Script Alteon 3.1
# 2014-05-15 [FV] 1.0 Encapsulation Scripts Alteon en un seul méta-script.
#
# ------------------------------------------------------------------------------


# --- Script params ------------------------------------------------------------

sALTMSCRIPT_VERSION="1.2"
sALTMSCRIPT_VERDATE="2014-06-26"


# --- Sémantique ---------------------------------------------------------------
# Terme + Signification :  ALTMSCRIPT = Méta-Script Alteon
# Constantes ou booléens en MAJUSCULES / Variable en minuscules
# Variables prefix lettre : s STRING / b BOOLEAN / r RETURN_CODE / w WORK-SCRIPT


# --- System params ------------------------------------------------------------

# Si path absolu : bien pris en compte.
# Le Méta-Script peut se trouver à un autre emplacement que les scripts.
ALTMSCRIPT_KSH_PATH="alt_real.ksh"
ALTMSCRIPT_EXP_PATH="alt_real.exp"

# Binaires d'exécution
ALTMSCRIPT_KSH_EXE="/usr/bin/ksh"
ALTMSCRIPT_EXP_EXE="/usr/bin/expect"


# --- Codes Retour ('r') -------------------------------------------------------

rALTMSCRIPT_OK=0
rALTMSCRIPT_NOK=3

rALTMSCRIPT_OS_NOSUPPORT=$rALTMSCRIPT_NOK
rALTMSCRIPT_KSH_BINARY_NOFOUND=$rALTMSCRIPT_NOK
rALTMSCRIPT_KSH_SCRIPT_NOEXIST=$rALTMSCRIPT_NOK
rALTMSCRIPT_KSH_SCRIPT_NOEXEC=$rALTMSCRIPT_NOK
rALTMSCRIPT_EXP_BINARY_NOFOUND=$rALTMSCRIPT_NOK
rALTMSCRIPT_EXP_SCRIPT_NOEXIST=$rALTMSCRIPT_NOK
rALTMSCRIPT_EXP_SCRIPT_NOEXEC=$rALTMSCRIPT_NOK
rALTMSCRIPT_UNEXPD=$rALTMSCRIPT_NOK


# --- Work params --------------------------------------------------------------

wUname=`uname -s`
wDir=`dirname $0`


# --- Output params ------------------------------------------------------------
sLogDomain="[AltReal] "
sOK="[OK]"
sNOK="[NOK]"

sALTMSCRIPT_OS_NOSUPPORT="Scripts Alteon non supportés sur OS [$wUname]."
sALTMSCRIPT_KSH_BINARY_NOFOUND="Utilitaire [$ALTMSCRIPT_KSH_EXE] non installé ou inaccessible."
sALTMSCRIPT_KSH_SCRIPT_NOEXIST="Script [$ALTMSCRIPT_KSH_PATH] inexistant."
sALTMSCRIPT_KSH_SCRIPT_NOEXEC="Script [$ALTMSCRIPT_KSH_PATH] non exécutable."
sALTMSCRIPT_EXP_BINARY_NOFOUND="Utilitaire [$ALTMSCRIPT_EXP_EXE] non installé ou inaccessible."
sALTMSCRIPT_EXP_SCRIPT_NOEXIST="Script [$ALTMSCRIPT_EXP_PATH] inexistant."
sALTMSCRIPT_EXP_SCRIPT_NOEXEC="Script [$ALTMSCRIPT_EXP_PATH] non exécutable."
sALTMSCRIPT_UNEXPD="Erreur inattendue."


# --- Function Check Validité Code Retour Shell (entier >=0 et <=255) ----------

checkReturnCode () {
	rCode=$1
	[ -n $rCode ] && [ $rCode -ge 0 ] && [ $rCode -le 255 ] && return 0 || return 1;
}


# --- Function Affichage (avec domaine + catégorie) ----------------------------
# @mode : catégorie du message (error, info, warning)
# @str : message à afficher
# [@rCode] : code retour (optionnel) si la fonction doit faire quitter le script.
#   (Si pas de code présicé, ne quitte pas le script)
altSend ()
{
	[ $# -le 2 ] && return
	mode=$1
	str=$2

	case $mode in 
		ERR) sTypeError="ERROR";;
		WARN) sTypeError="WARNING";;
		INFO) sTypeError="INFO";;
		*) sTypeError="UNKNOWN";;
	esac

	echo "$sLogDomain$sTypeError $str"

	if [ $# -ge 3 ] ; then
		rCode=$3
		[ -n $rCode ] && checkReturnCode $rCode && exit $rCode
	fi
}


# --- Raccourcis ---
altErr ()  { altSend ERR "$@" ; }
altWarn () { altSend WARN "$@" ; }
altInfo () { altSend INFO "$@" ; }


# --- Main ---------------------------------------------------------------------

case "$wUname" in
	"HP-UX")
		type "$ALTMSCRIPT_KSH_EXE" >/dev/null 2>&1
		[ $? -ne 0 ] && altErr "$sNOK $sALTMSCRIPT_KSH_BINARY_NOFOUND" $rALTMSCRIPT_KSH_BINARY_NOFOUND

		cd $wDir
		[ -f "$ALTMSCRIPT_KSH_PATH" ] || \
			altErr "$sNOK $sALTMSCRIPT_KSH_SCRIPT_NOEXIST" $rALTMSCRIPT_KSH_SCRIPT_NOEXIST
		[ -x "$ALTMSCRIPT_KSH_PATH" ] || \
			altErr "$sNOK $sALTMSCRIPT_KSH_SCRIPT_NOEXEC" $rALTMSCRIPT_KSH_SCRIPT_NOEXEC
		$ALTMSCRIPT_KSH_EXE "$ALTMSCRIPT_KSH_PATH" "$@"
		exit $?
		;;

	"Linux")
		type "$ALTMSCRIPT_EXP_EXE" >/dev/null 2>&1
		[ $? -ne 0 ] && altErr "$sNOK $sALTMSCRIPT_EXP_BINARY_NOFOUND" $rALTMSCRIPT_EXP_BINARY_NOFOUND

		cd $wDir
		[ -f "$ALTMSCRIPT_EXP_PATH" ] || \
			altErr "$sNOK $sALTMSCRIPT_EXP_SCRIPT_NOEXIST" $rALTMSCRIPT_EXP_SCRIPT_NOEXIST
		[ -x "$ALTMSCRIPT_EXP_PATH" ] || \
			altErr "$sNOK $sALTMSCRIPT_EXP_SCRIPT_NOEXEC" $rALTMSCRIPT_EXP_SCRIPT_NOEXEC
		$ALTMSCRIPT_EXP_EXE "$ALTMSCRIPT_EXP_PATH" "$@"
		exit $?
		;;

	*)
		altErr "$sNOK $sALTMSCRIPT_OS_NOSUPPORT" $rALTMSCRIPT_OS_NOSUPPORT
		;;
esac

altErr "$sNOK $sALTMSCRIPT_UNEXPD" $rALTMSCRIPT_UNEXPD
