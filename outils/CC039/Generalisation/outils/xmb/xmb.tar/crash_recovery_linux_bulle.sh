#!/bin/ksh

# Fonctions a appeler

# Entete du Script
Entete()
{
echo " ******************************************************************************************"
echo " Sauvegarde systeme via Mondoarchive des disques internes (vg00)"
echo " crash_recovery_linux_bulle.sh"
echo " Cible : UBUNTU 8.04 LTS en Bulle Internet"
echo " "
echo " Parametre : "
echo " -d sous-repertoire de destination de la sauvegarde cree en local sous un FS temporaire "
echo " -e environnement de destination de la sauvegarde sur le MSBI "
echo " avec environnement = "
echo " PPROD : sauvegarde de l'image systeme a destination du MSBI de Pre-Production "
echo " PROD  : sauvegarde de l'image systeme a destination du MSBI de Production "
echo " "
echo " Exemple de commande :"
echo " \$XMBOUTIL/crash_recovery_linux_bulle.sh -d sauvegarde_complete -e PPROD "
echo " "
echo " Version 1.2 du 03/05/12 JF"
echo " *****************************************************************************************"
echo " "
}


# Usage du script
Usage()
{
  echo " "
  echo "Utilisation du script :"
  echo "-----------------------"
  echo "--> Login : Ce sript doit etre lance avec le compte root"
  echo "--> Usage : $0 -d sous-repertoire_destination_sauvegarde -e environnement_destination_sauvegarde "
  echo "--> Exemple : $0 -d sauvegarde_complete -e PPROD " 
  echo "-----------------------"
  echo " "
}

# *************************************************************
# Fonction verif de l'espace disque restant sur un volume group 
# *************************************************************

verif_espace_restant_VG() {

 REMAINING_SPACE=$(vgs --units G | grep -i $1 | sed '$s/.$//' |awk ' { print $7 } ')

  if [ $REMAINING_SPACE -lt 12 ]
  then
        echo " espace disque inferieur a 12 Go sur $1"
        echo " la generation de l'image va etre arretee "
	exit 3
  else
        echo -e " espace disque sur $1 superieur a 12 Go \n l'operation continue "
  fi

} # END verif_espace_restant_VG


# ***************************************
# Fonction verif de l'espace disque
# ***************************************

verif_espace_disque() {

FREESPACE=$(df -k $1 | tail -1|awk ' { print $3 } ')

if [ $FREESPACE -lt 10000000 ]
then
	echo " espace disque inferieur a 10 Go"
	echo " la generation de l'image va etre arretee "
	cd /
	quit_KO
else
	echo -e " espace disque pour la sauvegarde superieur a 10 Go \n l'operation continue "
fi

} # END verif_espace_disque


# ***************************************
# Fonction creation de repertoire
# ***************************************
creat_directory() {

if [ ! -d $1 ] ; then
        mkdir -p $1
        if [ $? -ne 0 ] ; then
                echo "Probleme lors de la creation du repertoire : " $1
		quit_KO
        fi

        chmod 700 $1
        if [ $? -ne 0 ] ; then
                echo "Probleme lors de l'affectation des droits du repertoire : " $1
		quit_KO
        fi
fi

} # END creat directory

# ***************************************
# Fonction suppression de LV
# ***************************************
delete_lv() {

test_lv=""
CodeR=""
echo ""
echo "Test de presence du volume logique $1 :"
lvdisplay $1
test_lv=$?
if [ $test_lv -ne 0 ]
then
	echo "PROBLEME : Le volume logique $1 n'existe pas, impossible de le supprimer"
	echo "Sortie du script en CR 3"
	exit 3
else
	echo ""
	echo "Le volume logique $1 existe"
	echo "Suppression du volume logique $1"
	lvremove -f $1
	CodeR=$?
	if [ $CodeR -ne 0 ]
	then
		echo "PROBLEME : Erreur lors de la suppression du volume logique $1"
		echo "Sortie du script en CR 3"
		exit 3	
	else
		echo "SUCCES lors de la suppression du volume logique $1"
	fi
fi

} # END delete_lv

# ***************************************
# Fonction creation du FS Temporaire 
# ***************************************
creat_fs_tempo() {

df | grep "$1" > /dev/null 2>&1
if [ $? -ne 0 ] ; then
        
	lvcreate -L 12G -n $lv_name $VG
	if [ $? -ne 0 ] ; then 
		echo "Probleme lors de la creation du lv temporaire pour Mondo"
		exit 3
	else
		echo "LV $lv_name cree avec succes"	
	fi
		mkfs -t ext3 -m 0 /dev/$VG/$lv_name	
		if [ $? -ne 0 ] ; then
			echo "Probleme lors de la creation du FS temporaire pour Mondo"
			exit 3
		else
			echo "FS $1 cree avec succes"	
		fi
		
		creat_directory $1

        	mount /dev/$VG/$lv_name $1
        	
		if [ $? -ne 0 ] ; then
        	        echo "Probleme lors du montage du filesystem : " $1
        	        quit_KO
       		else
			echo "FS $1 correctement monte" 
		fi
else
	echo "Le filesystem $1 existe deja \n l'operation continue ..."
fi

} # END creat_fs_tempo

# ***************************************
# Fonctions sorties
# ***************************************
quit_OK() {

if [ -d $FS_Tempo ] ; then
 /bin/umount $FS_Tempo
 /bin/rm -R $FS_Tempo
fi

delete_lv $lv_tempo

/usr/bin/apt-get autoremove -y mondo mindi mindi-busybox
                if [ $? -ne 0 ]
                 then
                        echo "Impossible de supprimer les binaires de Mondo sur le serveur" | tee -a $fic_log
                        quit_KO | tee -a $fic_log
                else
                        echo "Binaires de Mondo correctement supprimes du serveur" | tee -a $fic_log
                fi

echo " " 
echo "SUCCES : Fin de la creation de l'image le `date +%m%b%Y%Hh%M` sans erreur" 
echo "Consultation du fichier de log possible sous $fic_log"
echo "Sortie du script en CR 0" 
exit 0

} # END quit_OK


quit_KO() {

if [ -d $FS_Tempo ] ; then
 /bin/umount $FS_Tempo
 /bin/rm -R $FS_Tempo
fi

delete_lv $lv_tempo

/usr/bin/apt-get autoremove -y mondo mindi mindi-busybox
                if [ $? -ne 0 ]
                 then
                        echo "Impossible de supprimer les binaires de Mondo sur le serveur" | tee -a $fic_log
                        quit_KO | tee -a $fic_log
                else
                        echo "Binaires de Mondo correctement supprimes du serveur" | tee -a $fic_log
                fi

echo " " 
echo "PROBLEME : Erreurs lors de la creation de l'image Mondo le `date +%m%b%Y%Hh%M`" 
echo "Consultation du fichier de log possible sous $fic_log"
echo "Sortie du script en CR 3" 
exit 3

} # END quit_KO


# ***************************************
# MAIN
# ***************************************



# initialisation des variables		
# ***************************************

# Nom du client a sauvegarder
hostbkp=`uname -n`
# Nom du VG a utiliser pour la sauvegarde
VG="vg00"
# Nom du FS temporaire a creer en local pour la sauvegarde Mondo
FS_Tempo="/sauvegarde_mondo"
# Nom du LV temporaire a creer en local pour la sauvegarde
lv_name="lv_mondo"
# Chemin complet du LV temporaire
lv_tempo="/dev/$VG/$lv_name"
# Variable pour test presence du LV avant suppression
test_lv=""
# Log du script de sauvegarde
fic_log=/var/log/crash_recovery_linux.log

Entete | tee -a $fic_log

# Test variable disque
# -------------------
if [ "$DISK_SYS" = "" ]
then
        partition=`/sbin/pvs | grep vg00 | awk ' {print $1}'|awk ' { nomdisque=$1;gsub("/dev/","",nomdisque);print nomdisque}'`
        major=`grep $partition /proc/partitions| awk ' { print $1}' `
        minor=`grep $partition /proc/partitions| awk ' { print $2}' `
        minormondisque=0
        i=0
        while [ $i -lt $minor ]
        do
        {
        minormondisque=$i
        i=`expr $i + 16`
        }
        done
        DISK_SYS=`cat /proc/partitions | awk -v major=$major -v minor=$minormondisque '{ if (major==$1) {if ($2==minor) print "/dev/"$4}}'`
		export DISK_SYS
fi

EXCLUDE_LIST=`/bin/mount|grep ^/dev|grep vg00|grep -E "svdb|depot|w9q|websphere|wasdata|dump|itdssave|itds"|awk '{ print $3 }'`
export EXCLUDE_LIST

# Verification si utilisateur root qui execute le script

user=`whoami`
uid=`id -u`
if [ $uid -ne 0 ]
 then
 	echo "Vous devez etre root pour executer le script" | tee -a $fic_log
 	echo "Sortie du script en CR 3" | tee -a $fic_log
 	exit 3
else

	# Verification existance de la variable d'environnement utilisateur XM_OUTIL

	if [ "$XM_OUTIL" = "" ]
	 then
		echo "La variable XM_OUTIL n'est pas positionnee dans le .profile de l'utilisateur $user" | tee -a $fic_log
		echo "La sauvegarde de l'image systeme sur le MSBI ne sera pas possible, arret de la prise d'image" | tee -a $fic_log
		echo "Sortie du script en CR 3" | tee -a $fic_log
		exit 3
	else
		echo "Execution de la commande : $0 $*" | tee -a $fic_log
		echo " " | tee -a $fic_log
		echo "Resultat :" | tee -a $fic_log
		echo " " | tee -a $fic_log
	fi

	# Installation des binaires pour Mondorescue
	
	echo "Installation des binaires pour Mondorescue:" | tee -a $fic_log
	echo " " | tee -a $fic_log
	/usr/bin/apt-get -y --allow-unauthenticated install mondo mindi mindi-busybox | tee -a $fic_log
	if [ $? -ne 0 ]
	 then
		echo "Erreur a l'installation des binaires pour Mondorescue" | tee -a $fic_log
		echo "La sauvegarde systeme ne pourra pas etre realisee" | tee -a $fic_log
		echo "Sortie du script en CR 3" | tee -a $fic_log
		exit 3
	else
		echo "Binaires pour Mondorescue correctement installes" | tee -a $fic_log
		echo " " | tee -a $fic_log
	fi
	
# Affectation des arguments
# -------------------------
ARGSS="$*"
while getopts "d:e:" OPT
 do
 case ${OPT} in
	d) DESTINATION="${OPTARG}" ;;
	e) ENVIRONNEMENT="${OPTARG}" ;;
	*) echo "Erreur : Option non valide " | tee -a $fic_log
            Usage | tee -a $fic_log
            echo "Sortie du script en CR 3" | tee -a $fic_log
            exit 3 ;;
 esac
done


# Test des arguments
# -------------------
if [ "$DESTINATION" = "" ]
then
 echo "Erreur : L'option -d n'a pas ete specifiee " | tee -a $fic_log
 echo "Le sous-repertoire de destination de la sauvegarde est obligatoire " | tee -a $fic_log
 Usage | tee -a $fic_log
 echo "Sortie du script en CR 3" | tee -a $fic_log
 exit 3
fi

if [ "$ENVIRONNEMENT" = "" ]
then
 echo "Erreur : L'option -e n'a pas ete specifiee " | tee -a $fic_log
 echo "L'environnement de destination pour la sauvegarde MSBI est obligatoire " | tee -a $fic_log
 Usage | tee -a $fic_log
 echo "Sortie du script en CR 3" | tee -a $fic_log
 exit 3
else
 if [ "$ENVIRONNEMENT" != "PPROD" -a "$ENVIRONNEMENT" != "PROD" ]
  then
   echo "Erreur : L'option -e ne peut prendre comme valeur que PPROD ou PROD" | tee -a $fic_log
   Usage | tee -a $fic_log
   echo "Sortie du script en CR 3" | tee -a $fic_log
   exit 3
 fi
fi
  

# *****************************************************************
# Verification de l'espace disque restant sur le volume group  
# *****************************************************************

verif_espace_restant_VG $VG | tee -a $fic_log

# *****************************************************************
# Creation FS Temporaire pour Sauvegarde Mondo
# *****************************************************************

creat_fs_tempo ${FS_Tempo} | tee -a $fic_log 

# *****************************************************************
# Verification de l'espace disque disponible
# *****************************************************************

verif_espace_disque $FS_Tempo | tee -a $fic_log

# ****************************************************************************************************************
# Verification/Creation du repertoire de destination + repertoires temporaires pour la sauvegarde sur FS_Tempo
# ****************************************************************************************************************
# Creation du repertoire de destination de la sauvegarde en local sur le serveur
creat_directory ${FS_Tempo}/${hostbkp}/${DESTINATION} | tee -a $fic_log
# Creation du repertoire temporaire de construction de l'image iso avant son archivage dans le r�pertoire de destination
creat_directory ${FS_Tempo}/${hostbkp}/scratch | tee -a $fic_log
# Creation du repertoire temporaire de stockage des fichiers temporaires crees pendant le backup de mondoarchive
creat_directory ${FS_Tempo}/${hostbkp}/temp | tee -a $fic_log

# *****************************************************************
# Execution de la prise d'image Mondo
# *****************************************************************
       
echo " Execution du backup" | tee -a $fic_log
 
echo " Debut de la sauvegarde le `date +%m%b%Y%Hh%M`" | tee -a $fic_log
echo /usr/sbin/mondoarchive -Oi -l GRUB -I \"$DISK_SYS\" -E \"$EXCLUDE_LIST /var/lib/ntp/proc\" -N -d $FS_Tempo/$hostbkp/$DESTINATION -s 650M -p `hostname`-`date +%Y-%m-%d` -S ${FS_Tempo}/${hostbkp}/scratch -T ${FS_Tempo}/${hostbkp}/temp | tee -a $fic_log | bash
	CodeR=$?
       	if [ "$CodeR" = "0" ]
       	 then
   		/bin/rm -R ${FS_Tempo}/${hostbkp}/scratch ${FS_Tempo}/${hostbkp}/temp
   		echo "" | tee -a $fic_log
   		chmod -R 400 ${FS_Tempo}  
   		if [ $? -ne 0 ]
   	 	 then
			echo "Impossible de modifier les droits sur l'image Mondo" | tee -a $fic_log
			quit_KO | tee -a $fic_log	
   		else
			echo "Droits sur l'image Mondo correctement positionnes" | tee -a $fic_log
   		fi

		chown -R root:root ${FS_Tempo}
		if [ $? -ne 0 ]
	 	 then
			echo "Impossible de modifier les proprietaires de l'image Mondo" | tee -a $fic_log
			quit_KO | tee -a $fic_log
	 	else
			echo "Proprietaires de l'image Mondo correctement modifies" | tee -a $fic_log
		fi
		
			echo "" | tee -a $fic_log
			echo "Execution de la sauvegarde MSBI de l'image systeme Mondo:" | tee -a $fic_log
			$XM_OUTIL/sauvegarde.sh -p sauvegarde_en_ligne -r inf -f ${FS_Tempo} -a mondo -m mondo -e $ENVIRONNEMENT 	
			CodeR=$?
			if [ "$CodeR" = "0" ]	
			 then
				echo "" | tee -a $fic_log
				echo "Sauvegarde MSBI de l'image systeme OK" | tee -a $fic_log
   				quit_OK | tee -a $fic_log
			else
				echo "" | tee -a $fic_log
				echo "Sauvegarde MSBI de l'image systeme en echec" | tee -a $fic_log
				echo "La sauvegarde systeme va etre supprimee du serveur" | tee -a $fic_log
				quit_KO | tee -a $fic_log
	
			fi
  	else
   		quit_KO | tee -a $fic_log
  	fi
fi
