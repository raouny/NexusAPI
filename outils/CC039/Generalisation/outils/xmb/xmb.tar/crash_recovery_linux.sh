#!/bin/ksh

# Fonctions a appeler

# Entete du Script
Entete()
{
echo " ******************************************************************************************"
echo " Sauvegarde systeme via l'utilitaire dump des disques internes (vg00)"
echo " crash_recovery_linux remplace mondo rescue depuis la version 02_00_07 de xmb"
echo " Cible : tous socles  Linux SLES "
echo " "
echo " Parametres : "
echo " -d sous-repertoire de destination de la sauvegarde cree sur le partage NFS "
echo " -s site de reference pour le partage NFS "
echo " -r retention (nombre d'images a conserver sur le partage NFS : de 1 a 4) "
echo " avec site = "
echo " st-ouen : Partage NAS Pre-Productuion 221.129.20.211:/fs_mondo "
echo " trelaze : Partage NAS Production 221.1.63.12:/fs_mondo "
echo " equi-dev : Partage NAS equinox dev 10.116.36.232:/fs_mondo "
echo " equi-pp : Partage NAS equinox pre-prod 10.116.36.233:/fs_mondo "
echo " equi-prod : Partage NAS equinox prod 10.116.36.234:/fs_mondo "
echo " srd-pp : Partage NAS SRD pre-prod 10.172.1.251:/fs_mondo_srd "
echo " srd-prod : Partage NAS SRD prod 10.212.1.249:/fs_mondo_srd "
echo " dmz : sauvegarde en local des masters netbackup de DMZ sur /xm_recovery"
echo " "
echo " Exemple de commande :"
echo " \$XMBOUTIL/crash_recovery_linux.sh -d sauvegarde_complete -s st-ouen -r 2"
echo " "
echo " Version 1.8 du 15/12/2015 JMT"
echo " *****************************************************************************************"
echo " "
}


# Usage du script
Usage()
{
  echo " "
  echo "Utilisation du script :"
  echo "-----------------------"
  echo "--> Login : Ce sript doit etre lance avec le compte root"
  echo "--> Usage : $0 -d destination_sauvegarde -s site -r retention"
  echo "--> Exemple : $0 -d sauvegarde_complete -s st-ouen -r 2 "
  echo "-----------------------"
  echo " "
}

# ***************************************
# Fonction verif de l'espace disque
# ***************************************

verif_espace_disque() {

FREESPACE=$(df -k $1 | tail -1|awk ' { print $4 } ')

if [ $FREESPACE -lt 5000000 ]
then
        echo " espace disque inferieur a 5 Go"
        echo " la generation de l'image va etre arretee "
		# Demontage du partage NFS
        if [ "$NFS_SHARE" = "/mnt/arch_pra" ]
        then
             # suppression du lien symbolique #
             cd /mnt
			 /usr/bin/unlink arch_pra
        else
             /bin/umount $MNT_POINT
        fi		
		return 3        
else
        echo -e " espace disque pour la sauvegarde superieur a 5 Go \n l'operation continue "
fi

} # END verif_espace_disque

# ***************************************
# Fonction creation de repertoire
# ***************************************
creat_directory() {

if [ ! -d $1 ] ; then
        mkdir -p $1
        if [ $? -ne 0 ] ; then
                echo "Probleme lors de la creation du repertoire : " $1
                exit 3
        fi

        chmod 755 $1
        if [ $? -ne 0 ] ; then
                echo "Probleme lors de l'affectation des droits du repertoire : " $1
                exit 3
        fi
fi

} # END creat directory

# ***************************************
# Fonction purge d'images
# ***************************************
purge_images() {

cat $imagetodelete |while read line #Lecture du fichier temporaire contenant les images �upprimer
do
        echo "L'image $line du serveur ${hostbkp} va etre supprimee"
        rm -rf ${MNT_POINT}/${hostbkp}/$line
        if [ $? -ne 0 ] ; then
                echo "Probleme lors de la suppression de l'image : " $line
        else
                echo "L'image $line a ete correctement supprimee"
        fi
done

} # END purge images


# ***************************************
# MAIN
# ***************************************


# ***************************************
# initialisation des variables
# ***************************************

# Nom du client a sauvegarder
hostbkp=`uname -n`
# Point de montage du repertoire NFS en local
MNT_POINT="/mnt/arch_pra"
NFS_SHARE=""
# Log du script de sauvegarde
fic_log=/var/log/dump_linux.log

Entete | tee -a $fic_log

# Verification si utilisateur root qui execute le script

uid=`id -u`
if [ $uid -ne 0 ]
 then
        echo "Vous devez etre root pour executer le script" | tee -a $fic_log
        echo "Sortie du script en CR 3" | tee -a $fic_log
        exit 3
else
    echo "Execution de la commande : $0 $*" | tee -a $fic_log
    echo " " | tee -a $fic_log
    echo "Resultat :" | tee -a $fic_log
    echo " " | tee -a $fic_log
fi

# Affectation des arguments
# -------------------------
ARGSS="$*"
while getopts "d:s:r:" OPT
 do
 case ${OPT} in
        d) DESTINATION=`date +%F`_"${OPTARG}" ;;
        s) SITE="${OPTARG}" ;;
                r) RETENTION="${OPTARG}" ;;
        *) echo "Erreur : Option non valide " | tee -a $fic_log
            Usage | tee -a $fic_log
            echo "Sortie du script en CR 3" | tee -a $fic_log
            exit 3 ;;
 esac
done


# Test des arguments
# -------------------
if [ "$DESTINATION" = "" ]
then
 echo "Erreur : L'option -d n'a pas ete specifiee " | tee -a $fic_log
 echo "Le sous-repertoire de destination de la sauvegarde est obligatoire " | tee -a $fic_log
 Usage | tee -a $fic_log
 echo "Sortie du script en CR 3" | tee -a $fic_log
 exit 3
fi

if [ "$SITE" = "" ]
then
 echo "Erreur : L'option -s n'a pas ete specifiee " | tee -a $fic_log
 echo "Le site de reference pour le montage NFS est obligatoire " | tee -a $fic_log
 Usage | tee -a $fic_log
 echo "Sortie du script en CR 3" | tee -a $fic_log
 exit 3
else
 if [ "$SITE" != "st-ouen" -a "$SITE" != "trelaze" -a "$SITE" != "equi-dev" -a "$SITE" != "equi-pp" -a "$SITE" != "equi-prod" -a "$SITE" != "srd-pp" -a "$SITE" != "srd-prod" -a "$SITE" != "dmz" ]
 then
  echo "Erreur : L'option -s ne peut prendre comme valeur que st-ouen, trelaze, equi-dev, equi-pp, equi-prod, srd-pp, srd-prod ou dmz" | tee -a $fic_log
  Usage | tee -a $fic_log
  echo "Sortie du script en CR 3" | tee -a $fic_log
  exit 3
 fi
fi
if [ "$RETENTION" = "" ]
then
 echo "Erreur : L'option -r n'a pas ete specifiee " | tee -a $fic_log
 echo "La retention sur les images est obligatoire " | tee -a $fic_log
 Usage | tee -a $fic_log
 echo "Sortie du script en CR 3" | tee -a $fic_log
 exit 3
else
         if [ "$RETENTION" != "" ] ; then
          if [ $RETENTION -lt 1 -o $RETENTION -gt 4 ] ; then

  echo "Erreur : L'option -r ne peut prendre comme valeur qu'un chiffre de 1 a 4" | tee -a $fic_log
  Usage | tee -a $fic_log
  echo "Sortie du script en CR 3" | tee -a $fic_log
  exit 3
          fi
         fi
fi

# Verification  presence dump/restore

VERSION=`rpm -qa dump`
export VERSION
if [ "$VERSION" = "" ]
 then
        echo "Installation de dump/restore" | tee -a $fic_log
        yast -i dump
fi

# Verification presence outils PRA
if [ ! -f /opt/cclinux/pra/scripts/before.sh ]
then
        echo "Installation des outils de PRA"
        yast -i PRA_outils
fi

# *****************************************************************
# Verification/Creation du repertoire en local pour le montage NFS
# *****************************************************************

creat_directory ${MNT_POINT} | tee -a $fic_log

# *****************************************************************
# Montage du repertoire d'archivage
# *****************************************************************

case $SITE in
  st-ouen)

        NFS_SHARE=221.129.20.211:/fs_mondo
        /bin/mount 221.129.20.211:/fs_mondo $MNT_POINT
        if [ $? -ne 0 ]
        then
                echo " Erreur de montage du partage NFS " | tee -a $fic_log
                echo " Arret du traitement " | tee -a $fic_log
                exit 3
        fi
;;
 trelaze)

        NFS_SHARE=221.1.63.12:/fs_mondo
        /bin/mount 221.1.63.12:/fs_mondo $MNT_POINT
        if [ $? -ne 0 ]
        then
                echo " Erreur de montage du partage NFS " | tee -a $fic_log
                echo " Arret du traitement " | tee -a $fic_log
                exit 3
        fi
;;
 equi-dev)

        NFS_SHARE=10.116.36.232:/fs_mondo
        /bin/mount 10.116.36.232:/fs_mondo $MNT_POINT
        if [ $? -ne 0 ]
        then
                echo " Erreur de montage du partage NFS " | tee -a $fic_log
                echo " Arret du traitement " | tee -a $fic_log
                exit 3
        fi
;;
 equi-pp)

        NFS_SHARE=10.116.36.233:/fs_mondo
        /bin/mount 10.116.36.233:/fs_mondo $MNT_POINT
        if [ $? -ne 0 ]
        then
                echo " Erreur de montage du partage NFS " | tee -a $fic_log
                echo " Arret du traitement " | tee -a $fic_log
                exit 3
        fi
;;
 equi-prod)

        NFS_SHARE=10.116.36.234:/fs_mondo
        /bin/mount 10.116.36.234:/fs_mondo $MNT_POINT
        if [ $? -ne 0 ]
        then
                echo " Erreur de montage du partage NFS " | tee -a $fic_log
                echo " Arret du traitement " | tee -a $fic_log
                exit 3
        fi
;;
 srd-pp)

        NFS_SHARE=10.172.1.251:/fs_mondo_srd
        /bin/mount 10.172.1.251:/fs_mondo_srd $MNT_POINT
        if [ $? -ne 0 ]
        then
                echo " Erreur de montage du partage NFS " | tee -a $fic_log
                echo " Arret du traitement " | tee -a $fic_log
                exit 3
        fi
;;
 srd-prod)

        NFS_SHARE=10.212.1.249:/fs_mondo_srd
        /bin/mount 10.212.1.249:/fs_mondo_srd $MNT_POINT
        if [ $? -ne 0 ]
        then
                echo " Erreur de montage du partage NFS " | tee -a $fic_log
                echo " Arret du traitement " | tee -a $fic_log
                exit 3
        fi
;;
dmz)
        NFS_SHARE=/xm_recovery
        /bin/mount -o bind /xm_recovery $MNT_POINT
        if [ $? -ne 0 ]
        then
                echo " Erreur de montage en local " | tee -a $fic_log
                echo " Arret du traitement " | tee -a $fic_log
                exit 3
        fi
;;

esac

# *****************************************************************
# Verification de l'espace disque disponible
# *****************************************************************

verif_espace_disque $MNT_POINT
CodeR=$?
if [ "$CodeR" != "0" ]
then
	exit 3
fi


# ****************************************************************************************************************
# Verification/Creation du repertoire d'archivage sur le partage NFS
# ****************************************************************************************************************
# Creation du repertoire de destination de la sauvegarde sur le partage NFS
creat_directory ${MNT_POINT}/${hostbkp}/${DESTINATION} | tee -a $fic_log

# *******************

**********************************************
# Execution de la prise d'image
# *****************************************************************

echo " Execution du backup" | tee -a $fic_log

        echo " Debut de la sauvegarde le `date +%m%b%Y%Hh%M`" | tee -a $fic_log
        echo " Execution de la commande : " | tee -a $fic_log
        echo "" | tee -a $fic_log
        echo /opt/cclinux/pra/scripts/before.sh $NFS_SHARE $DESTINATION | tee -a $fic_log | bash
        CodeR=$?
          if [ "$CodeR" = "0" ]
          then
           echo " Suppression des plus anciennes images " | tee -a $fic_log
           imagetodelete="${MNT_POINT}/${hostbkp}/imagetodelete.txt"    # On definit le fichier contenant les images a supprimer
           compteur=$(ls ${MNT_POINT}/${hostbkp} | wc -l)       # On compte le nombre d'images disponibles pour le serveur
           test=`expr $compteur - $RETENTION`   # On realise la difference entre le nbre d'images dispo et la retention choisie
           if [ $test -ge 0 ]
           then
           ls -1rt ${MNT_POINT}/${hostbkp} | head -$test > $imagetodelete # On recupere la liste des images a supprimer par ordre chronologique
           fi
           if [ -s $imagetodelete ]     # Si le fichier resultat n'est pas vide
                then purge_images | tee -a $fic_log     # On execute la purge des anciennes images suivant la retention choisie
           else
                echo " Il n'y a aucune image a supprimer " | tee -a $fic_log
           fi

           /bin/rm -f $imagetodelete
           /bin/umount $MNT_POINT           
           echo " " | tee -a $fic_log
           echo "SUCCES : Fin de la creation de l'image le `date +%m%b%Y%Hh%M` sans erreur" | tee -a $fic_log
           echo "Consultation du fichier de log possible sous $fic_log" | tee -a $fic_log
           echo "Sortie du script en CR 0" | tee -a $fic_log
           exit 0
		   
          else
           echo "" | tee -a $fic_log
           echo "PROBLEME : Erreurs lors de la creation de l'image " | tee -a $fic_log
           echo "Consultation du fichier de log possible sous $fic_log" | tee -a $fic_log
           echo "Sortie du script en CR 3" | tee -a $fic_log
           echo "" | tee -a $fic_log
           echo umount $MNT_POINT | tee -a $fic_log
           # Demontage du partage NFS
           /bin/umount $MNT_POINT
                fi
        exit 3
          fi
        fi
