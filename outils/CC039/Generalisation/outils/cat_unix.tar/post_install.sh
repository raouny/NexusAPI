echo "Post installation generique"

[ -z "${OUTILEXP}" ] && OUTILEXP=/procedure/outils/exploitation

if [ -d ${OUTILEXP} ]; then
        cd ${OUTILEXP}
        chmod -R 755 .
else
        echo "Variable OUTILEXP indefinie - droits non settes - veuillez verifier l installation / deploiement des CC"
        exit 3
fi
