#set -xv
#!/bin/ksh
#########################################################################
#                                                                       #
#       Script de deploiement des outils LINUX                          #
#                                                                       #
#       Nom             : cat_unix.sh                                   #
#       Environnement   : SLES10                                        #
#       Version         : 1.1                                           #
#       Auteur          : Ivan GOUIN                                    #
#       Date creation   : 27/09/07                                      #
#       Historique      : 27/09/07 : IG : adapatation pour linux        #
#                       : 03/10/13 : YH : Prise en compte format gz     #
#########################################################################
# Parametres : N/A                                                      #
#########################################################################
########################################################################

#
### Recherche de tous les binaires UNIX / Linux necessaires
#

# recherche de find et de date

which date > /tmp/rech.tmp

if [ $? -ne 0 ]
then echo -e "probleme lors de la recherche du binaire date: consulter /tmp/rech.tmp"
     exit 3
else if [ -s /tmp/rech.tmp ]
     then echo -e "l'utilitaire date existe bien sur ce serveur"
     else echo -e "l'utilitaire date n'existe pas sur ce serveur"
          exit 3
     fi
fi

# recherche de basename

which basename > /tmp/rech.tmp

if [ $? -ne 0 ]
then echo -e "probleme lors de la recherche du binaire basename: consulter /tmp/rech.tmp"
     exit 3
else if [ -s /tmp/rech.tmp ]
     then echo -e "l'utilitaire basename  existe bien sur ce serveur"
     else echo -e "l'utilitaire basename n'existe pas sur ce serveur"
          exit 3
     fi
fi

# recherche de dirname

which dirname > /tmp/rech.tmp

if [ $? -ne 0 ]
then echo -e "probleme lors de la recherche du binaire dirname: consulter /tmp/rech.tmp"
     exit 3
else if [ -s /tmp/rech.tmp ]
     then echo -e "l'utilitaire dirname  existe bien sur ce serveur"
     else echo -e "l'utilitaire dirname n'existe pas sur ce serveur"
          exit 3
     fi
fi

# recherche de uname

which uname > /tmp/rech.tmp

if [ $? -ne 0 ]
then echo -e "probleme lors de la recherche du binaire uname: consulter /tmp/rech.tmp"
     exit 3
else if [ -s /tmp/rech.tmp ]
     then echo -e "l'utilitaire uname  existe bien sur ce serveur"
     else echo -e "l'utilitaire uname n'existe pas sur ce serveur"
          exit 3
     fi
fi

# recherche de bash (Ubuntu WT10)

which bash > /tmp/rech.tmp

if [ $? -ne 0 ]
then echo -e "probleme lors de la recherche du binaire bash: consulter /tmp/rech.tmp"
     exit 3
else if [ -s /tmp/rech.tmp ]
     then echo -e "l'utilitaire bash   existe bien sur ce serveur"
          BASH=$(which bash)
     else echo -e "l'utilitaire bash  n'existe pas sur ce serveur"
     fi
fi

# recherche de ksh

which ksh > /tmp/rech.tmp

if [ $? -ne 0 ]
then SHELL=${BASH}
else if [ -s /tmp/rech.tmp ]
     then echo -e "l'utilitaire ksh    existe bien sur ce serveur"
          SHELL=$(which ksh)
     else echo -e "l'utilitaire ksh   n'existe pas sur ce serveur"
          SHELL=${BASH}
     fi
fi

#
### Declaration de variables
#
IDDATE=`date '+%y%m%d%H%M%S'`
SHLLNAME=`basename $0`
OUTILEXP=/procedure/outils/exploitation
LOGFILE=/tmp/${IDDATE}.${SHLLNAME}.log
TARFILE=/tmp/${SHLLNAME}_$$_tar.tmp
TMPFILE=/tmp/${SHLLNAME}_$$.tmp
TMPSQL=/tmp/${SHLLNAME}_$$.sql

echo -e "tous les binaires utilises dans ce script existent bien: on peut continuer"|tee -a $LOGFILE
echo -e " "|tee -a $LOGFILE

#
### Positionnement des droits sur tout ce qui a ete depose
#

chmod -R 755 ${OUTILEXP}/*

#
### Recherche de tous les fichiers tar deposes
#
find $OUTILEXP -name "*.tar" -type f > $TARFILE

#
### Decompression de tous les fichiers tar identifies
#
if [ -s $TARFILE ]
then
     cat $TARFILE|while read ligne
     do
        CHEMIN=`dirname ${ligne}`
        FICHIER=`basename ${ligne}`
        cd $CHEMIN
        PWD=`pwd`
        echo -e "on se trouve sous $PWD"|tee -a $LOGFILE
        tar xvf $FICHIER
        if [ $? -eq 0 ]
        then echo -e "SUCCES : decompression reussie du fichier $FICHIER"|tee -a $LOGFILE
             echo -e " "|tee -a $LOGFILE
             rm $FICHIER
        else echo -e "ERREUR : probleme de decompression du fichier $FICHIER"|tee -a $LOGFILE
             mv $FICHIER $FICHIER.bad
             echo -e "         le fichier $FICHIER a ete renomme en $FICHIER.bad"|tee -a $LOGFILE
             echo -e " "|tee -a $LOGFILE
        fi
     done

#
### Suppression du fichier listant les fichiers tar
#
#     rm $TARFILE

#
### Decompression de tous les fichiers
#

     find $OUTILEXP -name "*.Z" -type f -exec uncompress -f {} \;

fi

### Prise en compte des composants communs livres au format gz 
#

     find $OUTILEXP -name "*.gz" -type f -exec gunzip -f {} \;





find $OUTILEXP -name .post_install.sh -type f -print | sort -n | xargs -i ${SHELL} -c "echo -e launching {}; sh {}"
