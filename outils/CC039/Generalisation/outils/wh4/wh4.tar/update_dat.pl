#!/usr/bin/perl -w
################################################################################
# Nom du script	 	  : update_dat.pl
# Auteur		  : Thomas Becavin, Ilann Valet ARUMTEC www.arumtec.net
# Date de creation	  : 12/02/2008
# Version		  : 1.0.0
# utilisation             : update_dat.pl -h
# Support                 : stephane.grignon@laposte.fr; eric.bigourie@laposte.fr 
# Remarques	        :
# - Ce script fonctionne sur les serveurs SLES version 10.x
# - Il faut etre "root" pour lancer ce script.
# Utilisation       :
# Ce script s'utilise dans le cadre des mises a jour de signatures de VirusScan for Unix .
################################################################################


## Modules Perl a utiliser
use Class::Struct;
use Net::FTP;
use strict;
use Getopt::Std;
use File::Copy;

## Definition de la structure contenant les infos des signatures 
struct dats     =>
{
        dest_dir	=>  '$',    ## Repertoire de depot 
};

## Hash contenant les options et leurs parametres
my %GLopts;

## Structure contenant les params du script
my $GLDat_struct = dats->new();
my $cmd;
my $DatVersion;


## Recuperation des parametres du script
getopts("D:h", \%GLopts) or printusage();

## Recuperation du repertoire de depot des signatures
$GLDat_struct->dest_dir($GLopts{"D"} || "/uvscan/dat-updates");

## Affichage de l'aide
if (defined $GLopts{"h"}) {
        printusage();
}

my $ladatestamp=`date +%d%m%y`;
chop($ladatestamp);

open (FICLOG_DATE, "> /uvscan/logs/update-dat_$ladatestamp.log");
open (FICLOG_DEFAUT, "> /uvscan/logs/update-dat.log");

sub wlog {
my($mess)=@_;
print FICLOG_DATE "$mess" ;
print FICLOG_DEFAUT "$mess" ;
}

wlog("\n Execution de la mise a jour des  signatures de Viruscan for Unix \n");

wlog("\n 1. Test du repertoire de depot ".$GLDat_struct->dest_dir."");
if (! -d $GLDat_struct->dest_dir){
        wlog("\n ### Erreur : le repertoire ".$GLDat_struct->dest_dir." n existe pas \n");
        exit(3);
}

wlog("\n 2. Recherche de la version de signature du client");
$cmd=`/uvscan/uvscan --version | /bin/grep "Virus data file"`;
if (length($cmd) == 0){
        wlog("\n ### Impossible de determiner la version de signatures");
        $DatVersion="0000";
}else{
        $DatVersion=substr($cmd,17,4);
        wlog("\n La version est : $DatVersion");
}

opendir REP, $GLDat_struct->dest_dir;
my @fichiers = readdir REP;
my $download="0";
my $current_version = $DatVersion;
wlog("\n 3. Recherche des fichiers de signatures disponibles sous ".$GLDat_struct->dest_dir ." ");
foreach my $entree (@fichiers){
	if ($entree =~ /^dat-[0-9]{4}\.tar$/){
		wlog("\n\t ".$entree."");
		my $version_to_download = substr($entree,4,4);
		if ($current_version < $version_to_download){
			$current_version = $version_to_download;
			$download="1";
		}
	}
}

if ($download eq "0"){
        wlog("\n Aucun fichier de signatures disponible actuellement \n\n");
        exit(0);
}

my $file_to_copy="dat-".$current_version.".tar";

wlog("\n 4. Decompression du fichier sous /uvscan \n");
system("tar -xvf ".$GLDat_struct->dest_dir."/".$file_to_copy." -C /uvscan/");


wlog("\n 5. Verification de la mise a jour");

$cmd=`/uvscan/uvscan --version | /bin/grep "Virus data file"`;
if (length($cmd) == 0){
        wlog("\n ### Impossible de determiner la version de signatures");
        $DatVersion="0000";
}else{
        $DatVersion=substr($cmd,17,4);
        wlog("\n La version est : $DatVersion");
}
if ($current_version eq $DatVersion){
	wlog("\n Succes de la mise a jour des signatures\n");
	exit(0); 
}else{
	wlog("\n Echec de la mise a jour des signatures\n");
	exit(3);
}



#__________________________
sub printusage{

        print "Usage : update_dat.pl [OPTIONS]
        -h Affichage de l'aide
        -D [DIR_DEPOT] Repertoire permanent local de depot des fichiers signatures (par defaut,/uvscan/dat-updates)\n\n";
        exit(3);
}
