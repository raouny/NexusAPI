#!/usr/bin/perl -w

################################################################################
# Nom du script		: download_dat .pl
# Auteur		: Stephane GRIGNON, Eric BIGOURIE - La Poste DOIC/Date/PASI/PST-SE
# Date de creation	: 12/02/2008
# Version		: 1.0.0
# utilisation		: download_dat.pl -h
# Support		: stephane.grignon@laposte.fr; eric.bigourie@laposte.fr
# Remarques	        :
# - Ce script fonctionne sur les serveurs SLES version 10.x
# - Il faut etre "root" pour lancer ce script.
# Utilisation       :
# Ce script s'utilise dans le cadre dela mise a jour des signatures de VirusScan for Unix.
################################################################################


## Modules Perl a utiliser
use Class::Struct;
use Net::FTP;
use strict;
use Getopt::Std;

## Definition de la structure contenant les infos de telechargement
struct download     =>
{
	ftp_host	=>  '$',    ## Serveur FTP
	ftp_port	=>  '$',    ## Port du serveur FTP
	ftp_user	=>  '$',    ## Nom de l'utilisateur FTP
	ftp_password	=>  '$',    ## Password associe
	ftp_dir		=>  '$',    ## Repertoire de stockage des signatures sur serveur FTP
	dest_dir	=>  '$',    ## Repertoire de depot des fichiers de signatures
};

## Hash contenant les options et leurs parametres
my %GLopts;

## Liste des fichiers DAT disponibles sur le serveur de depot
my @GLDatAvail_list;
my $cmd;
my $DatVersion="0000";

## Structure contenant les params du script
my $GLdownload_struct = download->new();

## Recuperation des parametres du script
getopts("H:C:U:P:D:F:h", \%GLopts) or print_usage();

## Recuperation du serveur FTP
$GLdownload_struct->ftp_host($GLopts{"H"} || "ftp.antivirus.courrier.intra.laposte.fr");
## Recuperation du port serveur FTP
$GLdownload_struct->ftp_port($GLopts{"C"} || "21");
## Recuperation du user FTP
$GLdownload_struct->ftp_user($GLopts{"U"} || "anonymous");
## Recuperation du user FTP
$GLdownload_struct->ftp_password($GLopts{"P"} || "anonymous");
## Recuperation du repertoire FTP
$GLdownload_struct->ftp_dir($GLopts{"D"} || "uvscan5200");
## Recuperation du repertoire de depot des signatures
$GLdownload_struct->dest_dir($GLopts{"F"} || "/uvscan/dat-updates");
 
## Affichage de l'aide
if (defined $GLopts{"h"}) {
	print_usage();
}

my $ladatestamp=`date +%d%m%y`;
chop($ladatestamp);

open (FICLOG_DATE, "> /uvscan/logs/download-dat_$ladatestamp.log");
open (FICLOG_DEFAUT, "> /uvscan/logs/download-dat.log");

sub wlog {
my($mess)=@_;
print FICLOG_DATE "$mess" ; 
print FICLOG_DEFAUT "$mess" ; 
}

wlog("\n Execution du telechargement des fichiers de signatures de Viruscan for Unix \n"); 

wlog("\n 1. Test du repertoire de depot ".$GLdownload_struct->dest_dir."");
if (! -d $GLdownload_struct->dest_dir){
	wLog("\n ### Erreur : le repertoire ".$GLdownload_struct->dest_dir." n existe pas \n");
	exit(3);
}else{
	wlog("\n 2. Deplacement vers le repertoire de telechargement ".$GLdownload_struct->dest_dir."");
	if (! chdir($GLdownload_struct->dest_dir)){
		wlog("\n ### Deplacement impossible vers ".$GLdownload_struct->dest_dir." \n");
		exit(3);
	}
}

wlog("\n 3. Recherche de la version de signature du client ");
$cmd=`/uvscan/uvscan --version | /bin/grep "Virus data file"`;
if (length($cmd) == 0){
	wlog("\n ### Impossible de determiner la version de signatures ");
        $DatVersion="0000";
}else{
	$DatVersion=substr($cmd,17,4);
	wlog("\n La version est : $DatVersion");
}

my $file_to_download;

wlog("\n 4. Connexion au serveur FTP ".$GLdownload_struct->ftp_host." : ");
my $ftp = Net::FTP->new($GLdownload_struct->ftp_host, Port => $GLdownload_struct->ftp_port, Debug => 0);
if (defined($ftp)) {
	wlog("OK");
} else {
	wlog("KO $@");
	ftp->quit;
	exit(3);
}
	
wlog("\n 5. Connexion en tant que ".$GLdownload_struct->ftp_user." : ");
if ($ftp->login($GLdownload_struct->ftp_user, $GLdownload_struct->ftp_password)) {
	wlog("OK");
} else {
	wlog("KO ".$ftp->message. "");
	ftp->quit;
	exit(3);
}
  
wlog("\n 5. Deplacement vers ".$GLdownload_struct->ftp_dir." : ");
if ($ftp->cwd($GLdownload_struct->ftp_dir)) {
	wlog("OK");
} else {
	wlog("KO ".$ftp->message. "");
	ftp->quit;
	exit(3);
}

wlog("\n 6. Positionnement en mode binaire :");
if ($ftp->binary){
        wlog("OK");
} else {
	wlog("KO ".$ftp->message. "");
	ftp->quit;
	exit(3) ;
}
	
wlog("\n 7. Liste des signatures disponibles");
my $download="0"; 
my $current_version = $DatVersion;
@GLDatAvail_list=$ftp->ls("dat-*.tar");

foreach my $current_dat (@GLDatAvail_list){

	wlog("\n\t-".$current_dat." ");
	my $new_version=substr($current_dat,4,4);
	if ($current_version < $new_version){
		$current_version = $new_version;
		$download="1";
	}else{		
		# ne rien faire 
	}	
}

if ($download eq "0"){
	wlog("\n Aucun fichier de signatures disponible actuellement \n\n");
	$ftp->quit;
	exit(0);	
}else{
	wlog("\n 8. Suppression des anciens fichiers de signatures sous ".$GLdownload_struct->dest_dir." : ");
	$cmd="/bin/rm -f ".$GLdownload_struct->dest_dir."/*";
	`$cmd`;
	if ($cmd){
		wlog("OK\n\n");
	} else {
		wlog("KO\n\n");
		exit(3);
	}
	$file_to_download="dat-".$current_version.".tar";	
	wlog("\n 9. Telechargement du fichier ".$file_to_download." sur ".$GLdownload_struct->dest_dir." : ");
	if ($ftp->get($file_to_download)){
		wlog("OK\n\n");
		$ftp->quit;
		exit(0);
	} else {
		wlog("KO ".$ftp->message."\n\n");
		$ftp->quit;
		exit(3);
	}
}

sub print_usage{

	print "Usage : download_dat.pl [OPTIONS]
        -h Affichage de l'aide
        -C [FTP_PORT] Port de connexion du serveur FTP (par defaut, 21)
        -H [FTP_SERVER] Nom du serveur FTP (par defaut, ftp.antivirus.courrier.intra.laposte.fr)
        -U [FTP_USERNAME] Nom du compte de connexion au serveur FTP (par defaut, anonymous)
        -P [FTP_PASSWORD] Mot de passe du compte (par defaut, anonymous)
        -D [FTP_DIR] Repertoire de stockage des signatures sur le serveur FTP (par defaut, uvscan5200) 
        -F [DESTDIR] Repertoire de destination de depot des signatures\n\n";
	exit(3);
}

