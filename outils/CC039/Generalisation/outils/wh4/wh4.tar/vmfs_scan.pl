#!/usr/bin/perl -w
################################################################################
# Nom du script	 	  : vmfs_scan.pl
# Auteur		  : Eric BIGOURIE
# Date de creation	  : 21/04/2008
# Version		  : 1.0.0
# utilisation             : vmfs_scan.pl -h
# Support                 : eric.bigourie@laposte.fr 
# Remarques	        :
# - Ce script fonctionne sur les serveurs SLES version 10.x
# - Il faut etre "root" pour lancer ce script.
# Utilisation       :
# Ce script s'utilise dans le cadre des scans quotidiens de VirusScan for Unix .
################################################################################


## Modules Perl a utiliser
use Class::Struct;
use strict;
use Getopt::Std;

## Definition de la structure contenant les parametres du scan 

struct parametres     =>
{
         param_dir	=>  '$',    ## Repertoire des parametres 
};

## Hash contenant les options et leurs parametres
my %GLopts;

## Structure contenant les params du script
my $GLDat_struct = parametres->new();
my $cmd;
my $cmd1;
my $EngineVersion;
my $cmd2;
my $DatVersion;
my $hostname;
my $cmd3;
my $ProductVersion;
my $hour;

## Recuperation des parametres du script
getopts("D:h", \%GLopts) or printusage();

## Recuperation du repertoire contenant les composants communs UVSCAN 
$GLDat_struct->param_dir($GLopts{"D"} || "/procedure/outils/exploitation/wh4/02_00_00");

## Affichage de l'aide
if (defined $GLopts{"h"}) {
        printusage();
}

my $ladatestamp=`date +%d%m%y`;
chop($ladatestamp);

open (FICLOG_DATE, "> /uvscan/logs/vmfs-scan_$ladatestamp.log");
open (FICLOG_DEFAUT, "> /uvscan/logs/vmfs-scan.log");

sub wlog {
my($mess)=@_;
print FICLOG_DATE "$mess" ;
print FICLOG_DEFAUT "$mess" ;
}

wlog("\n Execution de l'analyse complete des volumes vmfs \n");

wlog("\n 1. Test du repertoire de parametres ".$GLDat_struct->param_dir."");
if (! -d $GLDat_struct->param_dir){
        wlog("\n ### Erreur : le repertoire ".$GLDat_struct->param_dir." n existe pas \n");
        exit(3);
}

wlog("\n 2. Execution du scan quotidien : ");
$cmd="/uvscan/uvscan --load ".$GLDat_struct->param_dir."/vmfs_scan.txt --file ".$GLDat_struct->param_dir."/vmfs_files.txt";
my(@res_cmd)=`$cmd`;
if (@res_cmd){
	 wlog("Scan termine \n\n");
	 wlog("Resultat du Scan : @res_cmd \n\n"); 
	 }
	 if ($? !=0) {

		$hour=`/bin/date +%T`;
                $cmd1=`/uvscan/uvscan --version | /bin/grep "Scan engine"`;
                $EngineVersion=substr($cmd1,13,6);
                $cmd2=`/uvscan/uvscan --version | /bin/grep "Virus data file"`;
                $DatVersion=substr($cmd2,17,4);
                $hostname=`/bin/hostname`;
                $cmd3=`/uvscan/uvscan --version | /bin/grep "Virus Scan"`;
                $ProductVersion=substr ($cmd3,0,28);
 
		wlog("\n L'analyse a detecte des fichiers infectes a $hour. Version du moteur d'analyse: $EngineVersion. Version des fichiers DAT: $DatVersion. (ordinateur source $hostname, execution de $ProductVersion) \n");
	    	
		exit(3);
	 }else {
	    	wlog("\n Aucune infection detectee \n");
 	    	exit(0);
 }

#__________________________
sub printusage{

     print "Usage : local_scan.pl [OPTIONS]
     -h Affichage de l'aide
     -D [DIR_DEPOT] Repertoire permanent local de depot des composants communs UVSCAN (par defaut,/procedure/outils/exploitation/wh4/02_00_00)\n\n";
     exit(3);
}
