#!/usr/bin/python
# -*- coding: iso-8859-15 -*-

#****************************    Fiche signaletique shell  encodage: iso-8859-15    ****************************************    #
# Nom du programme : update_CC.py    But du programme : mettre a jour les omposatns communs     Version minimum de l'interpreteur python : 2.4
#***********************************************    Syntaxe    **************************************************************   #
#                       update_CC.py -d --debug | param2
#**********************************************    Historique    *************************************************************  #
# Version       Date            AUTEUR          ENTREPRISE      Commentaires
# 1.0           26/07/2013      Y.HERVE        La Poste        version initale
# 1.1			08/10/2013		Y.HERVE		   La Poste		   Corrections bugs mineurs
#**********************************************    Codes retour    ***********************************************************  #
# code 0: Normal - Code retour normal : L enchainement est poursuivi
# code 1: Warning - Detection d une anomalie : L enchainement peut etre poursuivi
# code 2: Erreur - Erreur Non bloquante : possibilite de lancer une procedure de reprise
# code 3: Critique - Erreur Critique
# code 3: Exemple d erreur - Erreur parametres incorrects
# code > 3 : Traitement en erreur avec un code retour particulier
#*****************************************************************************************************************************  #

# Import des modules python



import os
import sys
import getopt
import socket
import glob
import shutil
import time
from string import ascii_uppercase





# Import des modules clients ou fonctions globales
#variable de repertoire
vg_WSRC = "\Composants_Communs\CC019\Generalisation\Outils"
vg_WDST = "D:\outils\exploitation"

vg_USRC = "/DSL2/Composants_Communs/CC021/Generalisation/outils"
vg_UDST = "/procedure/outils/exploitation"

vg_LSRC = "/DSL2/Composants_Communs/CC039/Generalisation/outils"
vg_LDST = "/procedure/outils/exploitation"

vg_LDMZ = "/Composants_Communs/CC039/Generalisation/outils"

#variable du comparaison des mises � jours
vg_CC_A_JOUR = True

#Variables pour les parametres
vg_Verbeux = False
vg_Mode_MAJ = False
vg_Mode_INFO = False
vg_Mode_AUTO = False
vg_Mode_FORCE = False
vg_DMZ = False
vg_adrValid = False
vg_adrIP = ""
vg_PasswordValid = False
vg_Password = ""
vg_UserValid = False
vg_User = ""

#variables du montage reseau
vg_DossierMont = "/mnt/DSL_CC"
vg_ParaWind= "/USER:"
vg_LecteurLibre = ""
vg_WReseaux = "\\DSL2"
vg_OReseaux = "/DSL2"
vg_Reseaux = "DSL2"
Code_Retour_Cmd = -1

#variable pour RPM
vg_RPM_LGY = "/DSL2/Composants_Communs/CC039/Generalisation/RPM/"
vg_RPM_DMZ = "/Composants_Communs/CC039/Generalisation/RPM/"

#variables pour cat_unix.tar
vg_Fichier_CatUnixTar = "cat_unix.tar"
vg_Fichier_CatUnixSh = "cat_unix.sh"

#variables pour les registres
vg_Arbo_Registry = "/opt/moe/signature"
vg_REGISTRY = "/opt/moe/signature/MOE-SE-REGISTRY"
vg_Cle_Registre = "SOFTWARE\\LAPOSTE\\SERVICES_EXPLOITATION\\COMPOSANTS_COMMUNS"
version_CC_Registre_LOCAL = "0"


#Variables globale code retour VTOM
vg_bl = 3
vg_wg = 1

#variable de temps
vg_Date = time.strftime('%d/%m/%y %H:%M', time.localtime())

# Definition des variables systeme
__SYSTEM = sys.platform
__PYTHON_VERSION = sys.version

# Version du CC a completer
version = "update_CC.py v1.1 - python "+__PYTHON_VERSION+" - "+__SYSTEM


#*****************************************************************************************************************************  #
# Definitions des fonctions et procedures
#*****************************************************************************************************************************  #

def p_Printusage(err): # aide

    print r"""
   Script permettant la mise a jour automatique des composants communs dans la
   version disponible au RT
   Utilisable en mode informel ou update
   Dans les 2 cas, il compare la version des composants communs signee en local
   a celle disponible sur le DSL

   Les parametres suivants sont � passer :


        parametre obligatoire :

            -i / --info   : Retourne si le serveur est a jour de la derniere
            version des composants communs disponible au DSL
            --------------------------------------------------------------------
            -m / --maj    : Effectue la mise a jour des composants communs si
                            une version plus recente est disponible
                            Maj en mode sequencee copie + droits + signature
                OU

             -a/--auto     : Mise a jour du serveur par un binaire
                             d'installation (Depot, RPM ou MSI selon OS)
                             Utilisable uniquement sur Linux dans cette version

            --------------------------------------------------------------------
            -s / --IP "Adresse IP DSL" : Adresse IP du serveur source (DSL) au
                                         format xxx.xxx.xxx.xxx
            --------------------------------------------------------------------
            -u / --user "login"    : Utilisateur de connexion en lecture au
                                     serveur source (DSL)
            --------------------------------------------------------------------
            -p / --pwd "password"  : Mot de passe de l'utilisateur de connexion
                                     en lecture au serveur source (DSL)


        parametre facultatif :

            -z / --DMZ    : Indique au script que le syst�me est un DMZ pour
                            effectuer un montage de ressource differement
                            (exclusivement pour linux )
            --------------------------------------------------------------------
            -f / --force  : Force la mise a jour du serveur quel que soit la
                            version deja installee
                            =>(a utiliser avec l'option -m/--maj ou -a/--auto)
            --------------------------------------------------------------------
            --debugg    : affiche a l'ecran toutes les etapes du deroulement
                          du script


        *** EXEMPLE ***

             update_cc.py --info --IP 221.128.10.250 --user invite --pwd ******

    """

    sys.exit(err)



def p_Validation_Arguments() : # fonction de recuperation des argument et test des it�ration
        global vg_Mode_MAJ
        global vg_Mode_INFO
        global vg_Verbeux
        global vg_Mode_AUTO
        global vg_adrIP
        global vg_adrValid
        global vg_User
        global vg_UserValid
        global vg_Password
        global vg_PasswordValid
        global vg_Mode_FORCE
        global vg_DMZ

        compteur_param = {} # recupere le nombre d'iteration de chaque parametre pour verifier qu'il n'y est qu'une seule fois dans la ligne de commande
        compteur_param["info"]=0
        compteur_param["maj"]=0
        compteur_param["force"]=0
        compteur_param["auto"]=0
        compteur_param["IP"]=0
        compteur_param["pwd"]=0
        compteur_param["user"]=0
        compteur_param["debug"]=0
        compteur_param["help"]=0
        compteur_param["DMZ"]=0

        if len(sys.argv) == 1 :
                    print("au moins 1 argument est manquant")
                    p_Printusage(3)


        try:
            opts, args = getopt.getopt(sys.argv[1:], "himafzs:p:u:", ["help", "info","maj","auto","force","DMZ","IP=","pwd=","user=","debugg"])

        except getopt.GetoptError, err:
            print str(err)
            p_Printusage(2)

        for o, a in opts:

            if o in ("-h", "--help"):
                p_Printusage(2)

            elif o in ("--debugg"):
                vg_Verbeux = True
                compteur_param["debug"]+=1

            elif o in ("-i","--info") :
                vg_Mode_INFO = True
                compteur_param["info"]+=1

            elif o in ("-m","--maj") :
                vg_Mode_MAJ = True
                compteur_param["maj"]+=1

            elif o in ("-a", "--auto") :
                vg_Mode_AUTO = True
                compteur_param["auto"]+=1

            elif o in ("-f", "--force") :
                vg_Mode_FORCE = True
                compteur_param["force"]+=1

            elif o in ("-z", "--DMZ") :
                vg_DMZ = True
                compteur_param["DMZ"]+=1

            elif o in ("-s","--IP") :
                vg_adrIP = a
                vg_adrValid = True
                compteur_param["IP"]+=1

            elif o in ("-p","--pwd") :
                vg_Password = a
                vg_PasswordValid = True
                compteur_param["pwd"]+=1

            elif o in ("-u","--user") :
                vg_User = a
                vg_UserValid = True
                compteur_param["user"]+=1

            else :
                assert False, "option invalide"

        # affiche un message d erreur en cas de parametres incorrectes
        p_Test_Options(compteur_param, vg_Mode_INFO, vg_Mode_MAJ, vg_Mode_AUTO, vg_adrValid, vg_adrIP ,vg_UserValid, vg_PasswordValid, vg_Mode_FORCE, vg_DMZ)


def p_Test_Options(compteur_param, info, maj, auto, IP, AdrIP, User, Code, force, DMZ): # fonction qui test les conditions de chaque parametre selon les os
        " Tests des arguments du script "

        for cle, valeur in compteur_param.items() :
            if valeur > 1 :
                print "le parametre %s est renseigne %s fois - un seul est necessaire" % (cle, valeur)
                p_Printusage(2)


        if info == True or maj == True or auto == True or force == True :

            if IP == True :

                if f_IP_Validation(AdrIP) == True :

                    if __SYSTEM == "win32" :

                        if force == True :

                             if maj == False and auto == False :
                                  print("Le parametre force doit etre associ� au parametre -m / --maj")
                                  p_Printusage(2)

                        if auto == True :
                             print("la fonction mise a jour automatique n'est pas prise en compte sur ce systeme")
                             p_Printusage(2)

                        if User == True :

                            if Code == True :
                                p_Debug("option obligatoire presente")

                            else :
                                print("mot de passe du DSL non reference ")
                                p_Printusage(2)

                        else :
                            print("nom d'utilisateur du DSL non reference")
                            p_Printusage(2)

                    elif __SYSTEM == "linux2" :

                        if force == True :

                             if maj == False and auto == False :
                                  print("Le parametre force doit etre associ� au parametre -m / --maj ou -a / --auto")
                                  p_Printusage(2)

                        if DMZ == True :

                            if User == True :

                                if Code == True :
                                    p_Debug("option obligatoire presente")

                                else :
                                    print("mot de passe du DSL non reference ")
                                    p_Printusage(2)

                            else :
                                print("nom d'utilisateur du DSL non reference")
                                p_Printusage(2)

                        else :
                            p_Debug("option obligatoire presente")


                    elif __SYSTEM == "hp-ux11" :

                        if force == True :

                             if maj == False and auto == False :
                                  print("Le parametre force doit etre associ� au parametre -m / --maj")

                             if auto == True :
                                  print("Le parametre force associ� a -a / --auto n'est pas valide car la fonction auto n'est pas encore pris en compte dans cette version")

                        if auto == True :
                             p_Debug("la fonction mise a jour automatique n'est pas prise en compte sur ce systeme")
                             p_Printusage(2)

                        else :
                            p_Debug("option obligatoire presente")

                else :
                    print("Adresse IP renseignee non joignable ou format non valide")
                    p_Printusage(2)

            else :

                if IP == False :
                    print("adresse du DSL manquante ou invalide")
                    p_Printusage(2)

        else :
                print("option manquante")
                p_Printusage(2)

        if info and maj or info and auto or maj and auto or info and force :
                print("les deux options ne peuvent pas etre activees en meme temps")
                p_Printusage(2)



def f_IP_Validation(Adresse_Ip): # fonction qui verifie si l'adresse ip donn� en parametre a bien un format valide et joignable( trois points et quatre nombres)

    try:
        socket.inet_pton(socket.AF_INET, Adresse_Ip)

    except AttributeError:  # famille d'adresse non valide

        try:
            socket.inet_aton(Adresse_Ip)

        except socket.error:
            return False

        return Adresse_Ip.count('.') == 3

    except socket.error:  # format d'adresse non valide
        return False

    return True




def f_Montage_Ressource_DSL(IP,USER,PWD,OS_System): # fonction qui monte la ressouce reseau selon l'os

    if OS_System == "windows" : # monte le DSL sur avec une lettre qui n'est pas utilis� et renvoie le Arbo_Absolue_CC_DSL d'acces au composants communs
         global vg_LecteurLibre
         p_Debug("\nFonction de montage de ressource")
         vg_Lecteur = list(ascii_uppercase) # rempli un tableau avec l'alphabet en majuscule
         vg_Lecteur.reverse() # commence le tableau par la dernier case pour commencer par le Z
         p_Debug(vg_Lecteur)

         for indice, lect in enumerate(vg_Lecteur) :
              p_Debug("test des lecteurs pour monter le DSL sur un emplacement libre")
              connexion = "net use"+" "+vg_Lecteur[indice]+": "+"\\\\"+IP+vg_WReseaux+" "+PWD+" "+vg_ParaWind+USER+" 2> Nul" + " > Nul"
              p_Debug(connexion)
              Code_Retour_Cmd = os.system(connexion)

              if Code_Retour_Cmd == 0 :
                   break

         if Code_Retour_Cmd == 0 : # boucle qui recupere la lettre libre pour une utilisation ulterieur
            p_Debug("recuperation du lecteur libre : ")
            vg_LecteurLibre = vg_Lecteur[indice]+":"
            p_Debug("Lecteur libre =  "+vg_LecteurLibre)
            Arbo_Absolue_CC_DSL = vg_LecteurLibre+vg_WSRC
            p_Debug("Arbo_Absolue_CC_DSL du DSL : "+Arbo_Absolue_CC_DSL)
            return Arbo_Absolue_CC_DSL

         else :
            print("Lecteur libre non defini, probleme de montage reseau. verifiez si vous avez donne les bonnes donnees de connection\n")
            sys.exit(vg_bl)

    elif OS_System == "linux" : # creer un dossier de montage et monte le DSL dedans et renvoie le Arbo_Absolue_CC_DSL d'acces au composants communs

        if os.path.isdir(vg_DossierMont) == False :
            cmd = " mkdir -p"+" "+vg_DossierMont+" > /dev/null" +" 2> /dev/null"
            p_Debug("commande passee pour la creation du dossier de montage du DSL : "+cmd)
            Code_Retour_Cmd = os.system(cmd)

            if Code_Retour_Cmd == 0 :
                p_Debug("Dossier de Montage du DSL cree")

            else :
                print("Dossier de Montage du DSL non cree")
                sys.exit(vg_bl)

        else :
            p_Debug("Dossier de montage deja present, poursuite du programme")

        if vg_DMZ == False :
            cmd = " mount"+" "+vg_adrIP+":"+vg_OReseaux+" "+vg_DossierMont+" > /dev/null" +" 2> /dev/null"

        if vg_DMZ == True :
            p_Debug("montage pour serveur en DMZ")
            cmd = "mount -t cifs -o"+" "+"username="+vg_User+","+"password="+vg_Password+" "+vg_adrIP+":"+vg_Reseaux+" "+vg_DossierMont+" > /dev/null" +" 2> /dev/null"

        p_Debug("commmande passee pour le montagedu DSL : "+cmd)
        Code_Retour_Cmd = os.system(cmd)

        if Code_Retour_Cmd == 0 :
            p_Debug("Lecteur reseau DSL monte")
            if vg_DMZ == False : Arbo_Absolue_CC_DSL = vg_DossierMont+vg_LSRC

            if vg_DMZ == True : Arbo_Absolue_CC_DSL = vg_DossierMont+vg_LDMZ
            p_Debug("Arbo_Absolue_CC_DSL du DSL : "+Arbo_Absolue_CC_DSL)
            return Arbo_Absolue_CC_DSL

        else :

            print("une erreur s'est produite dans le montage du DSL, verifiez qu'il n'est pas deja monte\n")
            cmd = " rmdir"+" "+vg_DossierMont+" > /dev/null" +" 2> /dev/null"
            p_Debug("commande passee pour la suppression du dossier de montage : "+cmd)
            Code_Retour_Cmd = os.system(cmd)

            if Code_Retour_Cmd == 0 :
                p_Debug("dossier de montage supprime")
                sys.exit(vg_bl)

            else :
                p_Debug("le dossier de montage DSL n'a pas �t� supprime correctement")
                sys.exit(vg_bl)



    elif OS_System == "hpux" : # creer un dossier de montage et monte le DSL dedans et renvoie le Arbo_Absolue_CC_DSL d'acces au composants communs

        if os.path.isdir(vg_DossierMont) == False :
            cmd = "mkdir -p"+" "+vg_DossierMont+" > /dev/null" +" 2> /dev/null"
            p_Debug("commande passee pour la creation du dossier de montage du DSL : "+cmd)
            Code_Retour_Cmd = os.system(cmd)

            if Code_Retour_Cmd == 0 :
                p_Debug("Dossier de Montage du DSL cree")

            else :
                print("Dossier de Montage du DSL non cree")
                sys.exit(vg_bl)

        else :
            p_Debug("Dossier de montage deja present, poursuite du programme")

        cmd = "mount -F nfs"+" "+vg_adrIP+":"+vg_OReseaux+" "+vg_DossierMont+" > /dev/null" +" 2> /dev/null"
        p_Debug("commmande passee pour le montage du DSL : "+cmd)
        Code_Retour_Cmd = os.system(cmd)

        if Code_Retour_Cmd == 0 :
            p_Debug("Lecteur reseau DSL monte")
            Arbo_Absolue_CC_DSL = vg_DossierMont+vg_USRC
            p_Debug("Arbo_Absolue_CC_DSL du DSL : "+Arbo_Absolue_CC_DSL)
            return Arbo_Absolue_CC_DSL

        else :
            print("une erreur s'est produite dans le montage du DSL, verifiez qu'il n'est pas deja monte\n")
            cmd = "rmdir"+" "+vg_DossierMont+" > /dev/null" +" 2> /dev/null"
            p_Debug("commande passer pour la suppression du dossier de montage : "+cmd)
            Code_Retour_Cmd = os.system(cmd)

            if Code_Retour_Cmd == 0 :
                p_Debug("dossier de montage supprime")
                sys.exit(vg_bl)

            else :
                p_Debug("le dossier de montage DSL n'a pas �t� supprime correctement")
                sys.exit(vg_bl)
    else :
        print "systeme non pris en charge"
        p_Demontage_Ressource_DSL(OS_System)
        sys.exit(vg_bl)


def f_Recup_Fichier_Signature(Arbo_CC, OS_System): # Le Arbo_CC correspond soit au Arbo_Absolue_CC_DSL des composants communs renvoy� au montage du DSL soit celui du serveur a mettre a jour

    if os.path.isdir(Arbo_CC) == False :
          print("le repertoire : "+Arbo_CC+" n'existe pas")
          p_Demontage_Ressource_DSL(OS_System)
          sys.exit(vg_bl)

    Fichiers_Signature = Arbo_CC+"/sigcc*"
    p_Debug("\nFonction de recuperation des fichiers signature")
    Liste_Fichiers_Signature = glob.glob(Fichiers_Signature)

    if Liste_Fichiers_Signature == [] :
        p_Debug("Fichier signature ABSENT dans le repertoire : "+Arbo_CC)
        signature = "0"
        return signature

    else :
        signature = Liste_Fichiers_Signature[0]

        if OS_System == "windows" : fichier_signature = signature.split('\\')[-1]

        elif OS_System == "linux" or OS_System == "hpux" : fichier_signature = signature.split('/')[-1]

        p_Debug("Valeur retournee par la fonction de recup du fichier signature : "+fichier_signature)
        return fichier_signature

def f_Recup_Version_Registre(Arbo_registre_CC, OS_System): # fonction qui recupere la version inscrite dans le registre windows ou dans le fichier signature registre des syteme linux ou unix

    p_Debug("\nfonction de recuperaption de la version dans le registre ")
    global version_CC_Registre_LOCAL
    CC = "composants communs CC039"

    if OS_System == "windows" :
        #import pour inscription dans base de registre
        import _winreg
        cmd = "REG QUERY"+" "+"HKEY_LOCAL_MACHINE\\"+Arbo_registre_CC+" 2> Nul" + " > Nul"
        p_Debug("\nLancement de la commande suivante pour maj du registre : "+cmd)
        cle = os.system(cmd)

        if cle == 0 :
             key = _winreg.OpenKey( _winreg.HKEY_LOCAL_MACHINE, Arbo_registre_CC ,0, _winreg.KEY_READ)
             (version_CC_Registre_LOCAL,typevaleur) = _winreg.QueryValueEx(key,'Version')
             _winreg.CloseKey(key)
             p_Debug("version presente dans le registre :"+version_CC_Registre_LOCAL)

             if version_CC_Registre_LOCAL == "" : version_CC_Registre_LOCAL = "0"

             return version_CC_Registre_LOCAL

        else :
             p_Debug("aucune cl� de registre ne correspond au Arbo_Absolue_CC_DSL : "+"HKEY_LOCAL_MACHINE"+"\\"+Arbo_registre_CC)
             version_CC_Registre_LOCAL = "0"
             return version_CC_Registre_LOCAL


    elif OS_System == "linux" :

        if os.path.isfile(Arbo_registre_CC) == True :
            fichier_reg = open(Arbo_registre_CC, 'r')
            ligne_signature = fichier_reg.readlines()
            ligne_signature.reverse()

            for indice,chaine in enumerate(ligne_signature) :

                #p_Debug(ligne_signature[indice][-42:-24])
                if CC in ligne_signature[indice] :
                    version_CC_Registre_LOCAL = ligne_signature[indice][-9:-1]
                    p_Debug("version inscrite dans le fichier de registre : "+version_CC_Registre_LOCAL)
                    break

            return version_CC_Registre_LOCAL

        else :
            p_Debug("Pas de signature des Composants communs dans le fichier : "+Arbo_registre_CC)
            version_CC_Registre_LOCAL = "0"
            return version_CC_Registre_LOCAL

    elif OS_System == "hpux" :

        if os.path.isfile(Arbo_registre_CC) == True :
            fichier_reg = open(Arbo_registre_CC, 'r')
            ligne_signature = fichier_reg.readlines()
            ligne_signature.reverse()

            for indice,chaine in enumerate(ligne_signature) :
                p_Debug(ligne_signature[indice][-41:-23])

                if CC in ligne_signature[indice] :
                    version_CC_Registre_LOCAL = ligne_signature[indice][-9:-1]
                    p_Debug("version inscrite dans le fichier de registre : "+version_CC_Registre_LOCAL)
                    break

            return version_CC_Registre_LOCAL

        else :
            p_Debug("Pas de signature des Composants communs dans le fichier : "+Arbo_registre_CC)
            version_CC_Registre_LOCAL = "0"
            return version_CC_Registre_LOCAL

def f_Comparaison_Version(version1, version2) : # compare les version des fichiers signature pour verifier si le serveur est a jour par rapport au DSL

    p_Debug("\nFonction de comparaison des fichiers signature")

    if int(version1) < int(version2) :
         vg_CC_A_JOUR = False
         return vg_CC_A_JOUR,version2

    elif int(version1) > int(version2) :
        vg_CC_A_JOUR = False
        return vg_CC_A_JOUR,version1

    elif int(version1) == int(version2) :
         vg_CC_A_JOUR = True
         return vg_CC_A_JOUR,version1

def p_Affichage_Etat(etat, versionDSL, versionSERVEUR): # fonction qui affiche clairement l'etat du serveur s'il est a jour ou non

    if etat == True :
        print "\n#########################################\n##### Les CC du serveur sont a jour #####\n#########################################"
        print "### Version du serveur :     "+versionSERVEUR+" ###"
        print "### Version du DSL     :     "+versionDSL+" ###"
        print "#########################################\n"



    if etat == False :
        print "\n################################################\n##### Les CC du serveur ne sont pas a jour #####\n################################################"
        print "### Version du serveur : "+versionSERVEUR+"            ###"
        print "### Version du DSL     : "+versionDSL+"            ###"
        print "################################################\n"

def p_Installation_AUTO(Nom_Relatif_Binaire_Install,OS_System): # fonction propre a linux, il lance un RPM present dans les composants communs qui les mettra a jour de fa�on automatique

    if OS_System == "linux" :
        Arbo_Absolue_CC_DSL = vg_DossierMont+Nom_Relatif_Binaire_Install+"CC*"
        p_Debug("Arbo_Absolue_CC_DSL du RPM : "+Arbo_Absolue_CC_DSL)
        LRPM = glob.glob(Arbo_Absolue_CC_DSL)
        LRPM.reverse()
        p_Debug(LRPM[0])
        Arbo_Absolue_CC_DSL, RPM = os.path.split(LRPM[0])
        p_Debug(RPM)

        if vg_Mode_FORCE == True :
             cmd = "rpm -Uvh --force"+" "+vg_DossierMont+Nom_Relatif_Binaire_Install+RPM
             p_Debug("commande passee pour installation via RPM :"+cmd)
             Code_Retour_Cmd = os.system(cmd)

             if Code_Retour_Cmd == 0 :
                p_Debug("Installation via RPM reussie")

             else :
                print("Installation via RPM en ERREUR")
                p_Demontage_Ressource_DSL(OS_System)
                sys.exit(vg_bl)

        else :

             if os.system(" rpm -qa | grep"+" "+RPM) == 0 :
                 cmd = "rpm -Uvh"+" "+vg_DossierMont+Nom_Relatif_Binaire_Install+RPM
                 p_Debug("commande passee pour installation via RPM :"+cmd)
                 Code_Retour_Cmd == os.system(cmd)

                 if Code_Retour_Cmd == 0 :
                     p_Debug("Installation via RPM reussie")

                 else :
                     print("Installation via RPM en ERREUR")
                     p_Demontage_Ressource_DSL(OS_System)
                     sys.exit(vg_bl)

             else :

                if os.system(" rpm -qa | grep CC ") == 0 :
                    print("Le paquet RPM est d�ja install�, mise a jour non effectuee")
                    p_Demontage_Ressource_DSL(OS_System)
                    sys.exit(vg_bl)

                else :
                    print("Les Composants communs n'ont pas �t� install�s par RPM, pour une premiere installation utiliser l'option -f ou --force.")
                    p_Demontage_Ressource_DSL(OS_System)
                    sys.exit(vg_bl)

    elif OS_System == "hpux" :
        print "Installation via un fichier de depot a instruire"

    elif OS_System == "windows" :
        print "Installation via un fichier MSI a instruire"



def p_Installation_Manuelle_CC(Arbo_CC_DSL,OS_System): # copie le contenue du DSL vers le serveur par des commandes syst�me
    p_Debug("\nFonction copie de fichier")

    if OS_System == "windows" :
        copy = "xcopy /E /Y /R " + Arbo_CC_DSL + " " + vg_WDST
        p_Debug("Commande executee pour la copie "+copy)

        if os.system(copy) == 0 :
            p_Debug("La copie s'est terminee correctement")

        else :
            p_Debug("ERREUR lors de la copie")
            p_Demontage_Ressource_DSL(OS_System)
            sys.exit(vg_bl)

    elif OS_System == "linux" :
        print("copie en cours...")
        copy = " cp -R"+" "+Arbo_CC_DSL+"/*"+" "+vg_LDST
        p_Debug("Commande executee pour la copie "+copy)

        if os.system(copy) == 0 :
            p_Debug("La copie s'est terminee correctement")

        else :
            p_Debug("ERREUR lors de la copie")
            p_Demontage_Ressource_DSL(OS_System)
            sys.exit(vg_bl)

    elif OS_System == "hpux" :
        print("copie en cours...")
        copy = " cp -R"+" "+Arbo_CC_DSL+"/*"+" "+vg_UDST
        p_Debug("Commande execut� pour la copie "+copy)

        if os.system(copy) == 0 :
            p_Debug("La copie s'est terminee correctement")

        else :

            p_Debug("ERREUR lors de la copie")
            p_Demontage_Ressource_DSL(OS_System)
            sys.exit(vg_bl)


def p_Post_Actions(OS_System): # fonction propre a linux et unix, il decompresse tous les dossier .tar des composants communs et gere les droits

    if OS_System == "linux" or OS_System == "hpux" :
        os.chdir(vg_LDST)
        cmd = " tar xvf"+" "+vg_LDST+"/"+vg_Fichier_CatUnixTar
        p_Debug("commande passee pour l'extraction du cat unix :"+cmd)
        Code_Retour_Cmd = os.system(cmd)

        if Code_Retour_Cmd == 0 :
            p_Debug("extraction du dossier cat_unix.tar effectuee")

        else :
            print("l'extraction du dossier cat_unix.tar n'a pas ete effectuee")
            p_Demontage_Ressource_DSL(OS_System)
            sys.exit(vg_wg)

        cmd = ""+" "+vg_LDST+"/"+"./"+vg_Fichier_CatUnixSh
        p_Debug("commande passee pour lancer le fichier cat_unix.sh :"+cmd)
        Code_Retour_Cmd = os.system(cmd)

        if Code_Retour_Cmd == 0 :
            p_Debug("execution du fichier cat_unix.sh effectuee")

        else :
            print("l'execution du fichier cat_unix.sh n'a pas ete effectuee")
            p_Demontage_Ressource_DSL(OS_System)
            sys.exit(vg_wg)

    elif OS_System == "windows" :
        p_Debug("Pas d'execution de scripts post actions implementee sous windows")


def p_Signature_Version(version, Arbo_CC, OS_System): # fonction qui creer des cl� et signe dans la base de registre la version du server de windows et ecrit dans un fichier texte sur unix et linux la version du serveur

     if OS_System == "windows" :

          #import pour inscription dans base de registre
        import _winreg

        try :
          key = _winreg.CreateKey(_winreg.HKEY_LOCAL_MACHINE, Arbo_CC)
          _winreg.SetValueEx(key, 'Nom', 0, _winreg.REG_SZ, 'CC019')
          _winreg.SetValueEx(key, 'Date', 0, _winreg.REG_SZ, vg_Date)
          _winreg.SetValueEx(key, 'Version', 0, _winreg.REG_SZ, version)
          _winreg.CloseKey(key)

          print("signature en base de registre effectuee")
        except WindowsError :
            print "Erreur d ecriture dans la base de registre"
            print "On force le demontage !!!"
            p_Demontage_Ressource_DSL(OS_System)
#            time.sleep(20)
            print "Sortie en code retour  : "  + str(vg_bl)
            sys.exit(vg_bl)
        except :
            print "Erreur inatendue lors de l acces a la base de registre"
            print "On force le demontage !!!"
            p_Demontage_Ressource_DSL(OS_System)
#            time.sleep(20)
            print "Sortie en code retour  : "  + str(vg_bl)
            sys.exit(vg_bl)

     elif OS_System == "linux" :

         if os.path.isdir(vg_Arbo_Registry) == False :
            cmd = "mkdir -p"+" "+vg_Arbo_Registry+" > /dev/null" +" 2> /dev/null"
            p_Debug("commande passee pour creation de l'arborescence du fichier signature :"+cmd)
            Code_Retour_Cmd = os.system(cmd)

            if Code_Retour_Cmd == 0 :
                p_Debug("creation du dossier effectuee")

            else :
                print("Erreur lors de la creation du dossier")
                p_Demontage_Ressource_DSL(OS_System)
                sys.exit(vg_wg)

         try :
            fichier_reg = open(Arbo_CC, 'a')

         except :
             print("Ouverture du fichier "+fichier_reg+" en ERREUR")
             p_Demontage_Ressource_DSL(OS_System)
             sys.exit(vg_bl)

         try :
             fichier_reg.write(vg_Date+" "+"- Repertoire N/A : installation des composants communs CC039 version"+" "+version+"\n")

         except :
             print("Ecriture dans le fichier "+fichier_reg+" en ERREUR")
             p_Demontage_Ressource_DSL(OS_System)
             sys.exit(vg_bl)

         try :
             fichier_reg.close()

         except :
             print("Fermeture du fichier "+fichier_reg+" en ERREUR")
             p_Demontage_Ressource_DSL(OS_System)
             sys.exit(vg_bl)

     elif OS_System == "hpux" :

         if os.path.isdir(vg_Arbo_Registry) == False :
            cmd = "mkdir -p"+" "+vg_Arbo_Registry+" > /dev/null" +" 2> /dev/null"
            p_Debug("commande passee pour creation de l'arborescence du fichier signature :"+cmd)
            Code_Retour_Cmd = os.system(cmd)

            if Code_Retour_Cmd == 0 :
                p_Debug("creation du dossier effectuee")

            else :
                print("Erreur lors de la creation du dossier")
                p_Demontage_Ressource_DSL(OS_System)
                sys.exit(vg_wg)

         try :
            fichier_reg = open(Arbo_CC, 'a')

         except :
             print("Ouverture du fichier "+fichier_reg+" en ERREUR")
             p_Demontage_Ressource_DSL(OS_System)
             sys.exit(vg_bl)

         try :
             fichier_reg.write(vg_Date+" "+"- Repertoire N/A : installation des composants communs CC021 version"+" "+version+"\n")

         except :
             print("Ecriture dans le fichier "+fichier_reg+" en ERREUR")
             p_Demontage_Ressource_DSL(OS_System)
             sys.exit(vg_bl)

         try :
             fichier_reg.close()

         except :
             print("Fermeture du fichier "+fichier_reg+" en ERREUR")
             p_Demontage_Ressource_DSL(OS_System)
             sys.exit(vg_bl)

     print("Mis a jour termin�e")

def p_Suppression_Fic_Signature(versionnonajour, present, OS_System): # fonction qui prend en parametre le non du fichier signature obsolete et va le chercher pour le supprimer

        p_Debug("\nFonction de suppression de l'ancien fichier signature")

        if OS_System == "windows" :

            if present == True :
                 supp = "del"+" "+vg_WDST+"\\"+versionnonajour+" 2> Nul" + " > Nul"
                 p_Debug("suppression du fichier signature errone, commande execute : "+supp)
                 p_Debug("fichier a supprimer : "+versionnonajour)

                 if os.system(supp) == 0 :
                      p_Debug("Suppression du fichier signature errone effectuee")

                 else :
                      p_Demontage_Ressource_DSL(OS_System)
                      sys.exit(vg_bl)

            else :
                 p_Debug("suppression du fichier signature obsolete non effectuee car il n'y en avait pas au depart")

        elif OS_System == "linux" :

            if present == True :
                cmd = " rm"+" "+vg_LDST+"/"+versionnonajour
                p_Debug("suppression du fichier signature erron�, commande executee : "+cmd)
                p_Debug("fichier a supprim� : "+versionnonajour)

                if os.system(cmd) == 0 :
                      p_Debug("Suppression du fichier signature errone effectuee")

                else :
                      p_Demontage_Ressource_DSL(OS_System)
                      sys.exit(vg_bl)

            else :
                p_Debug("Fichier signature absent - pas de suppression")

        elif OS_System == "hpux" :

            if present == True :
                cmd = " rm"+" "+vg_UDST+"/"+versionnonajour
                p_Debug("suppression du fichier signature errone, commande executee : "+cmd)
                p_Debug("fichier a supprimer : "+versionnonajour)

                if os.system(cmd) == 0 :
                      p_Debug("Suppression du fichier signature errone effectuee")

                else :
                      p_Demontage_Ressource_DSL(OS_System)
                      sys.exit(vg_bl)

            else :
                p_Debug("Fichier signature absent - pas de suppression")

        p_Debug("Copie des fichiers terminee")


def p_Demontage_Ressource_DSL(OS_System): # fonction qui demonte de DSL et supprime les dossiers de montage pour les syst�me linux et unix

        p_Debug("\nFonction de demontage des ressources reseaux")

        if OS_System == "windows" :
            time.sleep(20)
            global vg_LecteurLibre
            cmd = "net use" + " " +vg_LecteurLibre+" "+"/DELETE"+" 2> Nul" + " > Nul"
            p_Debug("demontage du DSL : " + cmd)
            Code_Retour_Cmd = os.system(cmd)

            if Code_Retour_Cmd == 0 :
                p_Debug("Demontage du DSL reussi")

            else :
                print("ERREUR lors du demontage du DSL")


        elif OS_System == "linux" or OS_System == "hpux":

            cmd = " umount"+" "+vg_DossierMont+" > /dev/null" +" 2> /dev/null"
            p_Debug("commande passee pour demontage du DSL : "+cmd)
            Code_Retour_Cmd = os.system(cmd)

            if Code_Retour_Cmd == 0 :
                p_Debug("Demontage du DSL reussi")
                cmd = " rmdir"+" "+vg_DossierMont+" > /dev/null" +" 2> /dev/null"
                p_Debug("commande passer pour la suppression du dossier de montage : "+cmd)
                Code_Retour_Cmd = os.system(cmd)

                if Code_Retour_Cmd == 0 :
                    p_Debug("Suppression du dossier de montage reussie")

                else :
                    print("ERREUR lors de la suppression du dossier de montage")

            else :
                print("ERREUR lors du demontage du DSL")
                sys.exit(vg_wg)

def p_Debug(message): # fonction pour le devellopement

    if vg_Verbeux : print str(message)


#Variable globale de code_retour pour les differentes fonctions
#Elle est posiionnee avec un code retour different de 0 afin que la fonction modifie sa valeur
code_retour_fonction = 128


def lancement_Multi_OS(OS_System):

    #########################################
    # fonction montage du lecteur du serveur
    #########################################
    if OS_System == "linux" :

        if vg_DMZ == False :

            DSL_Arbo_CC = f_Montage_Ressource_DSL(vg_adrIP,None,None,OS_System)
            Arbo_CC_Install = vg_LDST
            Arbo_Registry_sign = vg_REGISTRY
            Binaire_RPM = vg_RPM_LGY

        else :

            DSL_Arbo_CC = f_Montage_Ressource_DSL(vg_adrIP,vg_User,vg_Password,OS_System)
            Arbo_CC_Install = vg_LDST
            Arbo_Registry_sign = vg_REGISTRY
            Binaire_RPM = vg_RPM_DMZ

    elif OS_System == "hpux" :
        DSL_Arbo_CC = f_Montage_Ressource_DSL(vg_adrIP,None,None, OS_System)
        Arbo_CC_Install = vg_UDST
        Arbo_Registry_sign = vg_REGISTRY

    elif OS_System == "windows" :
        DSL_Arbo_CC = f_Montage_Ressource_DSL(vg_adrIP,vg_User,vg_Password, OS_System)
        Arbo_CC_Install = vg_WDST
        Arbo_Registry_sign = vg_Cle_Registre

    elif OS_System == "sun" :
        print("Systeme pas pris en compte. arret du script")
        sys.exit(vg_bl)

    #################################################
    #recuperation de la version des CC du serveur DSL
    #################################################

    version_CC_LOCAL = "0"
    Nom_fic_Signature_DSL = f_Recup_Fichier_Signature(DSL_Arbo_CC, OS_System)
    p_Debug("fichier signature du DSL : "+Nom_fic_Signature_DSL)
    version_CC_DSL = Nom_fic_Signature_DSL[9:17]

    ###################################################
    #recuperation de la version des CC du serveur local
    ###################################################

    # recuperation de la version inscrite dans le fichier
    Nom_fic_Signature_LOCAL = f_Recup_Fichier_Signature(Arbo_CC_Install, OS_System)
    p_Debug("fichier signature du serveur : "+Nom_fic_Signature_LOCAL)

    if Nom_fic_Signature_LOCAL != "0" :
        vg_PRESENT = True
        version_CC_Fichier_LOCAL = Nom_fic_Signature_LOCAL[9:17]

    else:
        version_CC_Fichier_LOCAL = Nom_fic_Signature_LOCAL
    # recuperation de la version inscrite dans le registre

    version_CC_Registre_LOCAL = f_Recup_Version_Registre(Arbo_Registry_sign, OS_System)
    p_Debug("version inscrite en base de registre : "+version_CC_Registre_LOCAL)

    # Comparaison des signatures

    if version_CC_Fichier_LOCAL == "0" and version_CC_Registre_LOCAL == "0" and vg_Mode_FORCE == False:
        print("Signature fichier et base de registre ABSENT - Utiliser l'option force pour effectuer une mise a jour")
        p_Demontage_Ressource_DSL(OS_System)
        sys.exit(vg_bl)

    else:

        if version_CC_Fichier_LOCAL != "0" and version_CC_Registre_LOCAL != "0" :
            p_Debug("\ncomparaison entre fichier signature du serveur et le registre")
            p_Debug("\nVersion CC fichier a comparer :"+version_CC_Fichier_LOCAL)
            p_Debug("\nVersion CC registre a comparer :"+version_CC_Registre_LOCAL)
            vg_CC_A_JOUR, version_CC_LOCAL = f_Comparaison_Version( version_CC_Fichier_LOCAL, version_CC_Registre_LOCAL)

            if vg_CC_A_JOUR == True :
                p_Debug("*** les versions du fichier signature et du registre sont IDENTIQUES ***")

            else :
                p_Debug("*** les versions du fichier signature et du registre sont DIFFERENTES ***")

        else :
            p_Debug("\ncomparaison entre le registre et le serveur non effectu� car l'un des deux est manquant, l'unique version r�cup�r� sera assign� a celle du serveur")

            if version_CC_Fichier_LOCAL != "0" : version_CC_LOCAL = version_CC_Fichier_LOCAL

            elif version_CC_Registre_LOCAL !="0" : version_CC_LOCAL = version_CC_Registre_LOCAL


    ###################################################
    #Verification si les CC sont a jour
    ###################################################

    p_Debug("\ncomparaison entre signature du serveur et du DSL")
    p_Debug("\nVersion CC DSL a comparer :"+version_CC_DSL)
    p_Debug("\nVersion CC DSL a comparer :"+version_CC_LOCAL)
    vg_CC_A_JOUR, version_plus_recente = f_Comparaison_Version(version_CC_DSL,version_CC_LOCAL)
    p_Affichage_Etat(vg_CC_A_JOUR,version_CC_DSL,version_CC_LOCAL)

    if vg_Mode_MAJ == True or vg_Mode_AUTO == True :

        if vg_Mode_FORCE == True or vg_CC_A_JOUR == False :

            if vg_Mode_AUTO == True :
                p_Installation_AUTO(Binaire_RPM, OS_System)

            else:
                p_Installation_Manuelle_CC(DSL_Arbo_CC, OS_System)
                p_Post_Actions(OS_System)
                p_Debug("Nom du fichier signature present sur le serveur :"+Nom_fic_Signature_LOCAL)
                p_Debug("Nom du fichier signature present sur le DSL :"+Nom_fic_Signature_DSL)
                #Ne supprime le fichier signature que si celui-ci est obsolete

                if Nom_fic_Signature_LOCAL != Nom_fic_Signature_DSL and Nom_fic_Signature_LOCAL != "0":
                    p_Suppression_Fic_Signature(Nom_fic_Signature_LOCAL, vg_PRESENT, OS_System)

                p_Signature_Version(version_CC_DSL, Arbo_Registry_sign, OS_System)

                if vg_Mode_FORCE == True : print ("fin de la mis a jour en mode force")

        else :
            print("Les Composants Communs sont deja a jour, utiliser l'option -f ou --force pour forcer l'installation de la derniere version")

    ####################################
    # demontage du lecteur reseaux
    ####################################
    p_Demontage_Ressource_DSL(OS_System)


    # retourne le code retour de l execution de la commande
    code_retour_fonction = 0
    return code_retour_fonction


#*****************************************************************************************************************************  #
# Main
#*****************************************************************************************************************************  #

# Variables du programme principal
if __name__ == "__main__" :


#Variable code_retour
#Ele est posiionnee avec un code retour different de 0 afin que la fonction modifie sa valeur
    code_retour_fonction = 56

    # Affiche la version
    print version + "\n"


    # Gestion des arguments en parametre
    # ++++++++++++++++++++++++++++++++++
    p_Validation_Arguments()

    # ++++++++++++++++++++++++++++++++++

    #*****************************************************************************************************************************  #
    # Lancement de la commande selon la plateforme utilisee
    #*****************************************************************************************************************************  #
    if __SYSTEM == "win32":
            code_retour = lancement_Multi_OS("windows")

    elif __SYSTEM == "hp-ux11":
            code_retour = lancement_Multi_OS("hpux")

    elif __SYSTEM == "linux2":
            code_retour = lancement_Multi_OS("linux")

    elif __SYSTEM == "solaris":
            code_retour = lancement_Multi_OS("sun")

    else:
        print "Plateforme systeme inconnue - sortie en CR 3"
        sys.exit(vg_bl)

    #######################################
    # Verification du code retour         #
    #######################################

    if code_retour not in (0, None):
            print "ping: Erreur inattendue - sortie en CR 3"
            sys.exit(vg_bl)

    #######################################
    # Fin du Programme avec code_retour   #
    #######################################
    print "Fin du programme - code retour = " + str(code_retour)
    sys.exit(code_retour)
