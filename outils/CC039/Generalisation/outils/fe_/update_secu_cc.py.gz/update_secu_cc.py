#!/usr/bin/python
# -*- coding: iso-8859-15 -*-

#****************************    Fiche signaletique shell  encodage: iso-8859-15    ****************************************    #
# Nom du programme : update_secu_cc.py    But du programme : Securiser CC     Version minimum de l'interpreteur python : 2.4
#***********************************************    Syntaxe    **************************************************************   #
#                       update_secu_cc.py -d param1 | param2
#**********************************************    Historique    *************************************************************  #
# Version       Date            AUTEUR          	ENTREPRISE      Commentaires
# 1.0           14/02/2011      R.SAVIGNY/C.CHAPUT      La Poste        Creation
#**********************************************    Codes retour    ***********************************************************  #
# code 0: Normal - Code retour normal : L enchainement est poursuivi
# code 1: Warning - Detection d une anomalie : L enchainement peut etre poursuivi
# code 3: Critique - Erreur Critique
# code 3: Exemple d erreur - Erreur parametres incorrects
# code > 3 : Traitement en erreur avec un code retour particulier
#*****************************************************************************************************************************  #

# bonnes pratiques :
# ------------------

# Cas des constantes :
#    Tout en majuscule
#    Separer les mots par des underscore
#    Donner des noms simples et descriptifs
#    N'utiliser que des lettres [A-Z] et [0-9]

# Cas des variables :
#    Premiere lettre en minuscule
#    Melange de minuscule, majuscule avec la premiere lettre de chaque mot en majuscule
#    Donner des noms simples et descriptifs
#    Variable d'une seule lettre a eviter au maximum sauf dans des cas precis et locaux (tour de boucle)
#    N'utiliser que des lettres [a-z][A-Z] et [0-9]

#    pour debuter une variable :
#    vg_ Variable Globale
#    vl_ Variable Locale

# Cas des fonctions et procedures :

#    Premiere lettre en majuscule
#    Melange de minuscule, majuscule avec la premiere lettre de chaque mot en majuscule
#    Donner des noms simples et descriptifs
#    Eviter les acronymes hormis les communs (Xml, Url, Html)
#    N'utiliser que des lettres [a-z][A-Z] et [0-9]
#    Mettre un commentaire en dessous por decrire la fonction / procedure

#    pour debuter une fonction prefixer par :
#    f_ pour les fonctions
#    p_ pour les procedures

# Syntaxe des parametres transmis au script

#  -x     option oligatoire passee en argument
# [-x]    option optionnelle passe en argument
# <x>     champ obligatoire
# |       separe des options correspond a un ou
# (text)  message de description


# ____________________________


# Constantes : nom et version du script
__NOM_SCRIPT="update_secu_cc.py"
__VERSION_SCRIPT="1.0"


# Import des modules python
import os
import sys
import subprocess
import platform
import getopt
import re
import os.path
import glob
import string

# Import des modules clients ou fonctions globales

# Mode Bouchon mis en place pour les besoins du CCO: False ou True
vg_Bouchon_CCO = False
vg_Code_Retour_Bouchon_CCO = 5 # Code retour dans le cas de l'utilisation du mode bouchon
# Fin du parametrage du mode bouchon

# Definition des constantes systemes
__SYSTEM = sys.platform
__PYTHON_VERSION = sys.version

# Definition des constantes code retour VTOM
CR_WG = 1 # code retour warning
CR_BL = 3 # code retour bloquant
CR_OK = 0 # code retour bonne execution

# Definitions des variables globales :
vg_Debug = False

# Variables specifiques
vg_Group_Name = "dibox"
vg_Group_ID = "4444"
vg_Permissions = "750"
vg_Users_List = []

# Variable de repertoire
vg_W_Target = "D:\\outils\\exploitation"
#vg_W_Target = "D:\\outils\\_secu_CC"
vg_U_Target = "/procedure/outils/exploitation"
#vg_U_Target = "/root/_secu_CC"
vg_L_Target = "/procedure/outils/exploitation"
#vg_L_Target = "/root/_secu_CC"

# Version du CC a completer
__VERSION = __NOM_SCRIPT + "  v" + __VERSION_SCRIPT + " - python "+__PYTHON_VERSION+" - "+__SYSTEM

#*****************************************************************************************************************************  #
# Definitions des fonctions et procedures
#*****************************************************************************************************************************  #
def p_Debug(chaine):
    # affiche la chaine lorsque l option debug est positionnee a True
    if vg_Debug : print str(chaine)

def p_Test_Options_Script(arguments):
    # tests les arguments passes en parametres au script
        print "Tests des arguments du script"

        if (arguments == []) or (arguments is None) or ("-h" not in str(arguments) and "--help" not in str(arguments)
		and "-U" not in str(arguments) and "--Users" not in str(arguments)) :
                print "*** un argument est manquant ***"
                p_Print_Usage(CR_BL)

        p_Debug("Fin de p_Test_Options")

def p_Print_Usage(err):
#   Affiche le message d utilisation du script
#   quitte le programme avec le code retour passe en argument
    print r"""

    Usage de la commande :
    update_secu_cc.py [--debug] --Users=<User1,User2,...>

    [-h | --help]     : produit l'aide suivante
    [-d | --debug]    : mode verbose - permet de debugger
    [-U | --Users=<User1,User2,...>] : Liste des utilisateurs executants des CC

    Exemple :
    python update_secu_cc.py --debug --Users=wwwaa001,hudson

    """
    sys.exit(err)

def f_Valorisation_Variable_System(chaine): # permet de valoriser des $ sous unix ou % sous windows
    vl_Resultat = os.path.expandvars(chaine)
    p_Debug("Resultat de la valorisation " + str(vl_Resultat))
    return vl_Resultat

def p_Print_Error(mesg, num):
    # retourne le message d erreur et sort en code retour
    print mesg
    print "Sortie en code retour " + str(num)
    sys.exit(num)

def p_Param_Lg_Commande(params):
    # Gestion des arguments passes en parametre de la ligne de commandes
    global vg_Users
    global vg_Debug
    try:
        opts, args = getopt.getopt(params, "hdU:", ["help", "debug", "Users="])

    except getopt.GetoptError, err:
        # print help information and exit:
        print str(err) # will print something like "option -a not recognized"
        p_Print_Usage(CR_BL)

    for o, a in opts:
        if o in ("-h", "--help"):
            p_Print_Usage(CR_BL)
        elif o in ("-d", "--debug"):
            vg_Debug = True
            p_Debug("Mode DEBUG Actif")
        elif o in ("-U", "--Users"):
            vg_Users = a
        else:
            assert False, "option invalide"
    
    # affiche un message d erreur en cas de params incorrects
    p_Test_Options_Script(params)

def f_Users_List(params):
    global vg_Users_List
    for user in params.split(","):
        vg_Users_List.append(user)

def f_Os_System(cmd):
    return subprocess.call((cmd), stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)

def f_Group_Add_Windows(group):
    cmd = " net localgroup "+group+" /add"
    p_Debug("\nCommande execute pour la creation du groupe "+group+" : "+cmd)
    Code_Retour_Cmd = f_Os_System(cmd)

    if Code_Retour_Cmd == 0:
        p_Debug("Creation du groupe "+group+" effectuee")
    else:
        syscmd = subprocess.Popen(['net','localgroup',group,'/ADD'], stdin = subprocess.PIPE,
            stdout=subprocess.PIPE, stderr = subprocess.STDOUT)
        sortie = syscmd.stdout.readline()
        p_Debug("Sortie : "+sortie)
        if '1379' not in sortie :
            print("La creation du groupe "+group+" n'a pas ete effectuee")
            syscmd.stdin.close()
            syscmd.stdout.close()
            sys.exit(CR_WG)
        p_Debug("Le groupe "+group+" existe deja, on continue")
        syscmd.stdin.close()
        syscmd.stdout.close()

def f_Group_Att_Windows(group, users_list):
    for user in users_list:
        cmd = " net localgroup "+group+" "+user+" /add"
        p_Debug("\nCommande execute pour l'attribution du groupe : "+cmd)
        Code_Retour_Cmd = f_Os_System(cmd)

    if Code_Retour_Cmd == 0:
        p_Debug("Attribution du groupe "+group+" effectuee")
    else:
        syscmd = subprocess.Popen(['net','localgroup',group,user,'/ADD'], stdin = subprocess.PIPE,
            stdout=subprocess.PIPE, stderr = subprocess.STDOUT)
        sortie = syscmd.stdout.readline()
        p_Debug("Sortie : "+sortie)
        if '1378' not in sortie :
            print("L'attribution du groupe "+group+" a l'utilistateur "+user+" n'a pas ete effectuee")
            syscmd.stdin.close()
            syscmd.stdout.close()
            sys.exit(CR_WG)
        p_Debug("L'utilistateur "+user+" fait deja partie du groupe "+group+", on continue")
        syscmd.stdin.close()
        syscmd.stdout.close()

def f_Update_ACL_Windows(group, target):
    cmd = " icacls "+target+" /grant "+group+":RX /T"
    p_Debug("\nCommande execute pour la mise a jour des ACL : "+cmd)
    Code_Retour_Cmd = f_Os_System(cmd)

    if Code_Retour_Cmd == 0:
        p_Debug("Mise a jour des ACL sur "+target+" pour "+group+" effectuee")
    else:
        print("La mise a jour des ACL sur "+target+" pour "+group+" n'a pas ete effectuee")
        sys.exit(CR_WG)

    cmd = " icacls "+target+" /inheritance:d /T"
    p_Debug("\nCommande execute pour la suppression de l'heritage des ACL : "+cmd)
    Code_Retour_Cmd = f_Os_System(cmd)

    if Code_Retour_Cmd == 0:
        p_Debug("Suppression de l'heritage sur "+target+" effectuee")
    else:
        print("La suppression de l'heritage sur "+target+" n'a pas ete effectuee")
        sys.exit(CR_WG)

    cmd = " icacls "+target+" /remove utilisateurs /T"
    p_Debug("\nCommande execute pour la suppression des ACL sur "+target+" pour utilisateurs : "+cmd)
    Code_Retour_Cmd = f_Os_System(cmd)

    if Code_Retour_Cmd == 0:
        p_Debug("Suppression des ACL sur "+target+" pour utilisateurs effectuee")
    else:
        print("Suppression des ACL sur "+target+" pour utilisateurs n'a pas ete effectuee")
        sys.exit(CR_WG)

    cmd = " icacls "+target+" /remove \"utilisateurs authentifi�s\" /T"
    p_Debug("\nCommande execute pour la suppression des ACL sur "+target+" pour utilisateurs authentifi�s : "+cmd)
    Code_Retour_Cmd = f_Os_System(cmd)

    if Code_Retour_Cmd == 0:
        p_Debug("Suppression des ACL sur "+target+" pour utilisateurs authentifi�s effectuee")
    else:
        print("Suppression des ACL sur "+target+" pour utilisateurs authentifi�s n'a pas ete effectuee")
        sys.exit(CR_WG)

def f_Group_Add_Linux(group,GID):
    cmd = " groupadd -g "+GID+" "+group
    p_Debug("\nCommande execute pour la creation du groupe : "+cmd)
    Code_Retour_Cmd = f_Os_System(cmd)

    if Code_Retour_Cmd == 0:
        p_Debug("Creation du groupe "+group+" effectuee")
    else:
        syscmd = subprocess.Popen(['groupadd','-g',GID,group], stdin = subprocess.PIPE,
            stdout=subprocess.PIPE, stderr = subprocess.STDOUT)
        sortie = syscmd.stdout.readline()
        if ('not unique' not in sortie and 'pas unique' not in sortie) :
            print("La creation du groupe "+group+" n'a pas ete effectuee")
            syscmd.stdin.close()
            syscmd.stdout.close()
            sys.exit(CR_WG)
        p_Debug("Le groupe "+group+" existe deja, on continue")
        syscmd.stdin.close()
        syscmd.stdout.close()

def f_Group_Att_Linux(group, users_list):
    for user in users_list:
        cmd = " groupmod -A "+user+" "+group
        p_Debug("\nCommande execute pour l'attribution du groupe : "+cmd)
        Code_Retour_Cmd = f_Os_System(cmd)

        if Code_Retour_Cmd == 0:
            p_Debug("Attribution du groupe "+group+" a l'utilistateur "+user+" effectuee")
        else:
            print("L'attribution du groupe "+group+" a l'utilistateur "+user+" n'a pas ete effectuee")
            sys.exit(CR_WG)

def f_Update_ACL_Linux(group, target):
    cmd = " chown -R root:"+group+" "+target
    p_Debug("\nCommande execute pour la mise a jour des ACL : "+cmd)
    Code_Retour_Cmd = f_Os_System(cmd)

    if Code_Retour_Cmd == 0:
        p_Debug("Mise a jour des ACL sur "+target+" effectuee")
    else:
        print("La mise a jour des ACL sur "+target+" n'a pas ete effectuee")
        sys.exit(CR_WG)

    cmd = " chmod -R "+vg_Permissions+" "+target
    p_Debug("\nCommande execute pour la mise a jour des ACL : "+cmd)
    Code_Retour_Cmd = f_Os_System(cmd)

    if Code_Retour_Cmd == 0:
        p_Debug("Mise a jour des ACL sur "+target+" effectuee")
    else:
        print("La mise a jour des ACL sur "+target+" n'a pas ete effectuee")
        sys.exit(CR_WG)

def f_Group_Add_Hpux(group, GID):
    f_Group_Add_Linux(group, GID)

def f_Group_Att_Hpux(group, users_list):
    for user in users_list:
        cmd = " groupmod -a -l "+user+" "+group
        p_Debug("\nCommande execute pour l'attribution du groupe : "+cmd)
        Code_Retour_Cmd = f_Os_System(cmd)

        if Code_Retour_Cmd == 0:
            p_Debug("Attribution du groupe "+group+" a l'utilistateur "+user+" effectuee")
        else:
            print("L'attribution du groupe "+group+" a l'utilistateur "+user+" n'a pas ete effectuee")
            sys.exit(CR_WG)

def f_Update_ACL_Hpux(group, target):
    f_Update_ACL_Linux(group, target)

#*****************************************************************************************************************************  #
# definition des fonctions par system d exploitation
#*****************************************************************************************************************************  #

def f_Lancement_Windows():
    # global code_retour_fonction si pas modifie ...
    vl_Code_Retour = 256

    # Creation du group local
    f_Group_Add_Windows(vg_Group_Name)
    
    # Attribution du group local aux utilisateurs executant des CC
    f_Group_Att_Windows(vg_Group_Name, vg_Users_List)
    
    # Mise a jour des ACL des CC
    f_Update_ACL_Windows(vg_Group_Name, vg_W_Target)
    
def f_Lancement_Linux():
    # Creation du group local
    f_Group_Add_Linux(vg_Group_Name, vg_Group_ID)
    
    # Attribution du group local aux utilisateurs executant des CC
    f_Group_Att_Linux(vg_Group_Name, vg_Users_List)
    
    # Mise a jour des ACL des CC
    f_Update_ACL_Linux(vg_Group_Name, vg_L_Target)

def f_Lancement_Hpux():
    # Creation du group local
    f_Group_Add_Hpux(vg_Group_Name, vg_Group_ID)
    
    # Attribution du group local aux utilisateurs executant des CC
    f_Group_Att_Hpux(vg_Group_Name, vg_Users_List)
    
    # Mise a jour des ACL des CC
    f_Update_ACL_Hpux(vg_Group_Name, vg_U_Target)

def f_Lancement_Solaris():
    p_Print_Error("OS non supporte", CR_BL)

#*****************************************************************************************************************************  #
# Main
#*****************************************************************************************************************************  #
if __name__ == "__main__":
    # Variables du programme principal

    # Affiche la version
    print __VERSION + "\n"

    # Affiche la commande lancee
    print "Execution de la commande : " + str(sys.argv)

    p_Param_Lg_Commande(sys.argv[1:])
    f_Users_List(vg_Users)

    #*****************************************************************************************************************************  #
    # Lancement de la commande selon la plateforme utilisee
    #*****************************************************************************************************************************  #

    if __SYSTEM == "win32":
            vl_Code_Retour = f_Lancement_Windows()
    elif __SYSTEM == "hp-ux11":
            vl_Code_Retour = f_Lancement_Hpux()
    elif __SYSTEM == "linux2":
            vl_Code_Retour = f_Lancement_Linux()
    elif __SYSTEM == "solaris":
            vl_Code_Retour = f_Lancement_Solaris()
    else:
            p_Print_Error("Plateforme inconnue",CR_BL)


    #######################################
    # Verification du code retour         #
    #######################################
    if vl_Code_Retour not in (0, None):
        p_Print_Error("Erreur inattendue", CR_BL)
    else :
        vl_Code_Retour = CR_OK
    #######################################
    # Fin du Programme avec code_retour   #
    #######################################
    p_Print_Error("Fin du programme. " ,vl_Code_Retour)

