#!/bin/ksh

# Fonctions a appeler

# Entete du Script
Entete()
{
echo " ********************************************************************************"
echo " Arret/Redemarrage d'un serveur d'application WAS "
echo " Start_Stop_Server.sh"
echo " Cible : WAS 6"
echo " "
echo " Parametres :  -s serveur -a action"
echo " avec action ="
echo " start : demarrage du serveur"
echo " stop : arret  du serveur"
echo " "
echo " Exemple de commande :"
echo " $YI_OUTIL/Start_Stop_Server.sh -s server1 -a stop"
echo " "
echo " Version 1.1 du 21/10/09 IP"
echo " Modifs : Prise en compte des scripts de type lp_ de la version 6.1.0.19"
echo " ********************************************************************************"
echo " "
}


# Usage du script
Usage()
{
  echo " "
  echo "Utilisation du script :"
  echo "-----------------------"
  echo "--> Login : Ce sript doit etre lance avec le login Was suivant la topologie"
  echo "--> Usage : $YI_OUTIL/Start_Stop_Server.sh -s server -a start/stop"
  echo "-----------------------"
  echo " "
}

# ***************************************
# MAIN
# ***************************************

Entete

echo "Execution de la commande : $0 $*"
echo " "
echo "Resultat :"
echo " "

# Affectation des arguments
# -------------------------
ARGSS="$*"
while getopts "s:a:" OPT
 do
 case ${OPT} in
        s) SERVEUR="${OPTARG}" ;;
        a) ACTION="${OPTARG}" ;;
        *) echo "Erreur : Option non valide "
            Usage
            echo "Sortie du script en CR 3"
            exit 3 ;;
 esac
done


# Test des arguments
# -------------------
if [ "$SERVEUR" = "" ]
then
 echo "Erreur : L'option -s n'a pas ete specifiee "
 echo "Le nom du serveur est obligatoire "
 Usage
 echo "Sortie du script en CR 3"
 exit 3
fi

if [ "$ACTION" = "" ]
then
 echo "Erreur : L'option -a n'a pas ete specifiee "
 echo "L'action start ou stop est obligatoire "
 Usage
 echo "Sortie du script en CR 3"
 exit 3
else
 if [ "$ACTION" != "start" -a "$ACTION" != "stop" ]
 then
  echo "Erreur : L'option -a ne peut prendre comme valeur que start ou stop"
  Usage
  echo "Sortie du script en CR 3"
  exit 3
 fi
fi

# Execution du script
# -------------------
case $ACTION in
  start)
        if [ "$PROFILE_APP" = "" ]
        then
         echo "Erreur : La variable PROFILE_APP n'est pas difinie dans le .profile"
         echo "Le script doit etre lance avec un login relatif au WAS"
         echo "Sortie du script en CR 3"
         exit 3
        fi
	if [ -f $PROFILE_APP/bin/lp_startServer.sh ]
	then
	 $PROFILE_APP/bin/lp_startServer.sh $SERVEUR
	else
        $PROFILE_APP/bin/startServer.sh $SERVEUR
	fi
        CodeR=$?
        if [ "$CodeR" = "0" ]
        then
         echo " "
         echo "SUCCES : Sortie du script en CR 0"
         exit 0
        else
         echo " "
         echo "PROBLEME : Sortie du script en CR 3"
         exit 3
        fi
;;
  stop)
        if [ "$PROFILE_APP" = "" ]
        then
         echo "Erreur : La variable PROFILE_APP n'est pas difinie dans le .profile"
         echo "Le script doit etre lance avec un login relatif au WAS"
         echo "Sortie du script en CR 3"
         exit 3
        fi
	if [ -f $PROFILE_APP/bin/lp_stopServer.sh ]
        then
	 $PROFILE_APP/bin/lp_stopServer.sh $SERVEUR
	else
         $PROFILE_APP/bin/stopServer.sh $SERVEUR
	fi
        CodeR=$?
        if [ "$CodeR" = "0" ]
        then
         echo " "
         echo "SUCCES : Sortie du script en CR 0"
         exit 0
        else
         echo " "
         echo "PROBLEME : Sortie du script en CR 3"
         exit 3
        fi
;;
esac

