# Fonction a appeler

import time

def entete():
 print "*****************************************************************************"
 print "Arret/Demarrage d'une application"
 print "Start_Stop_App.py"
 print "Cible : WAS 6"
 print " "
 print "Parametres :  nom_appli, nom_serveur, action"
 print "avec action ="
 print "start : demarrage de l'application"
 print "stop : arret de l'application"
 print " "
 print "Exemple de commande :"
 print "wsadmin.sh -lang jython -f <chemin>Start_Stop_App.py appli server01 stop"
 print " "
 print "Version 3.0 du 30/04/13 CB"
 print "*****************************************************************************"
 print " "

def start_stop_app(appName, serverName, action ):
 print "--> Lancement de Start_Stop_App.py pour l'application "+appName+" sur le serveur "+serverName+", action = "+action+"."
 # on recupere le bean de l'application
 appManager = AdminControl.queryNames('cell='+myCell+',type=ApplicationManager,process='+serverName+',*')

 #on recupere le status de l'application
 # appStatus = AdminControl.completeObjectName('type=Application,name='+appName+',*')
 appStatus = AdminControl.completeObjectName('process='+serverName+',type=Application,name='+appName+',*')
 if (( action == 'stop' )):
        print "--> Tentative d'arret de l'application "+appName+""
        print "--> ......."
        # gestion des exceptions :
        #si application deja arretee on sort en code retour 1
        if (( appStatus == "" )):
                print "--> L'apllication "+appName+" est deja arretee sur le serveur "+serverName+""
                print "--> Exception declenchee Sortie du script en CR 1"
                sys.exit(1)
        else:
                #si probleme alors on sort en code retour 3
                try:
                	AdminControl.invoke(appManager, 'stopApplication', appName)
                except:
                	print "--> Impossible d'arreter l'application "+appName+""
                	print "--> Exception declenchee Sortie du script en CR 3"
                	print "--> Description de l'exception :"
               		print sys.exc_info()
              		sys.exit(3)
                else:
			# On teste le status de l'application
			# Si au bout de 5 min l'application n'est pas arretee on sort en CR 3
			time.sleep(20)	
			appStatus = AdminControl.completeObjectName('process='+serverName+',type=Application,name='+appName+',*')
			if (( appStatus != "" )):
				time.sleep(40)
				appStatus = AdminControl.completeObjectName('process='+serverName+',type=Application,name='+appName+',*')
				if (( appStatus != "" )):
					print "L'application n'a pas fini de s'arreter au bout d'1min : Nouveau test dans 2 min ..."
					time.sleep(120)
					appStatus = AdminControl.completeObjectName('process='+serverName+',type=Application,name='+appName+',*')
					if (( appStatus != "" )):
						print "L'application n'a pas fini de s'arreter au bout de 3min : Nouveau test dans 2 min ..."
						time.sleep(120)
						appStatus = AdminControl.completeObjectName('process='+serverName+',type=Application,name='+appName+',*')
						if (( appStatus != "" )):
							print "Erreur : L'application n'a pas fini de s'arreter au bout de 5min"
							print "Sortie du script en Code Retour 3"
							sys.exit(3)
			print "--> L'application "+appName+" est arretee sur le serveur "+serverName+""
			print "--> Sortie du script en Code Retour 0"
			sys.exit(0)

				
				
 if (( action == 'start' )):
        print "--> Tentative de demarrage de l'application "+appName+""
        print "--> ......."
        # gestion des exceptions :
                #si application deja demarree on sort en code retour 1
        if (( appStatus != "")):
                print "--> L'apllication "+appName+" est deja demarree sur le serveur "+serverName+""
                print "--> Exception declenchee Sortie du script en CR 1"
                sys.exit(1)
        else:
                #si probleme alors on sort en code retour 3
                try:
                	AdminControl.invoke(appManager, 'startApplication', appName)
                except:
                	print "--> Impossible de demarrer l'application "+appName+""
                	print "--> Exception declenchee Sortie du script en CR 3"
                	print "--> Description de l'exception :"
               		print sys.exc_info()
                	sys.exit(3)
                else:
				# On teste le status de l'application
				# Si au bout de 5 min l'application n'est pas demarree on sort en CR 3
				time.sleep(20)
				appStatus = AdminControl.completeObjectName('process='+serverName+',type=Application,name='+appName+',*')
				if (( appStatus == "" )):
					time.sleep(40)
					appStatus = AdminControl.completeObjectName('process='+serverName+',type=Application,name='+appName+',*')
					if (( appStatus == "" )):
						print "L'application n'a pas fini de demarrer au bout d'1min : Nouveau test dans 2 min ..."
						time.sleep(120)
						appStatus = AdminControl.completeObjectName('process='+serverName+',type=Application,name='+appName+',*')
						if (( appStatus == "" )):
							print "L'application n'a pas fini de dérrer au bout de 3min : Nouveau test dans 2 min ..."
							time.sleep(120)
							appStatus = AdminControl.completeObjectName('process='+serverName+',type=Application,name='+appName+',*')
							if (( appStatus == "" )):
								print "Erreur : L'application n'a pas fini de demarrer au bout de 5min"
								print "Sortie du script en Code Retour 3"
								sys.exit(3)
				print "--> L'application "+appName+" est demarree sur le serveur "+serverName+""
				print "--> Sortie du script en Code Retour 0"
				sys.exit(0)
				
				

# ***************************************
# Main
# ***************************************

entete()

if (( len(sys.argv) != 3 ) ):
   print "--> Erreur nombre d'arguments incorrect: Le script Start_Stop_App.py necessite 3 arguments"
   print "--> Usage : Start_Stop_App.py nom_appli nom_serveur start/stop"
   sys.exit(3)
else:
   action = sys.argv[2]
   if (( action != "start" )) and (( action != "stop" )):
        print "--> 3eme parametre incorrect : "+action+""
        print "--> Le 3eme parametre ne peut etre que stop ou start"
        sys.exit(3)
   else:
        myCell = AdminControl.getCell( )
        appName = sys.argv[0]
        serverName = sys.argv[1]
        action = sys.argv[2]
        start_stop_app(appName, serverName, action )

