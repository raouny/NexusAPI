#!/bin/ksh

# Fonctions a appeler

# Entete du Script
Entete()
{
echo " ********************************************************************************"
echo " Sauvegarde de la configuration du profile de type AppSrv"
echo " WAS_backupapp.sh"
echo " Cible : WAS 6.x"
echo " "
echo " Parametres : aucun"
echo " "
echo " Exemple de commande :"
echo " $YI_OUTIL/WAS_backupapp.sh"
echo " "
echo " Version 1.0 du 01/09/08 IP"
echo " ********************************************************************************"
echo " "
}


# Usage du script
Usage()
{
  echo " "
  echo "Utilisation du script :"
  echo "-----------------------"
  echo "--> Login : Ce sript doit etre lance avec le login executant les process WAS"
  echo "--> Usage : $YI_OUTIL/WAS_backupapp.sh"
  echo "-----------------------"
  echo " "
}


# ***************************************
# MAIN
# ***************************************

Entete

echo "Execution de la commande : $0 $*"
echo " "
echo "Resultat :"
echo " "

# Test des arguments
# -------------------
if [ $# != 0 ]
then
	echo "Erreur : Le script ne necessite aucun argument"
        Usage
	echo "Sortie du script en CR 3" 
        exit 3
fi


if [ "$PROFILE_APP" = "" ]
then
         echo "Erreur : La variable PROFILE_APP n'est pas definie dans le .profile"
         echo "Le script doit etre lance avec le login qui execute les process WAS"
         echo "Sortie du script en CR 3"
         exit 3
fi

if [ "$IBM_HEAPDUMPDIR" = "" ]
then  
	echo "Erreur : La variable IBM_HEAPDUMPDIR n'est pas definie dans le .profile"
	echo "Le script doit etre lance avec le login qui execute les process WAS"
	echo "Sortie du script en CR 3"
	exit 3
fi

# Execution du script
# -------------------
	$PROFILE_APP/bin/backupConfig.sh $IBM_HEAPDUMPDIR/WebSphereConfig_APP_`date +%d%m%y-%Hh%M`.zip -nostop
	CodeR=$?
	if [ "$CodeR" = "0" ]
	then
	 echo " "
	 echo "Sauvegarde de la config du profile de type AppSrv realisee avec succes"
	else
	 echo " "
	 echo "PROBLEME lors de la sauvegarde de la config du profile de type AppSrv : Sortie du script en CR 3"
	 exit 3
	fi
