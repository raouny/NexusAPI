#!/bin/ksh

# Fonctions a appeler

# Entete du Script
Entete()
{
echo " ********************************************************************************"
echo " Serveur : " `hostname`
echo " Arret/Redemarrage du DMGR WAS (serveur ND) "
echo " Start_Stop_Dmgr.sh"
echo " Cible : WAS 6.x"
echo " "
echo " Parametres : action"
echo " avec action ="
echo " start : demarrage du dmgr" 
echo " stop : arret du dmgr"
echo " "
echo " Exemple de commande :"
echo " $YI_OUTIL/Start_Stop_DMGR.sh stop"
echo " "
echo " Version 1.1 du 21/10/09 IP"
echo " Modifs : Prise en compte des scripts de type lp_ de la version 6.1.0.19"
echo " ********************************************************************************"
echo " "
}


# Usage du script
Usage()
{
  echo " "
  echo "Utilisation du script :"
  echo "-----------------------"
  echo "--> Login : Ce sript doit etre lance avec le login executant les process WAS"
  echo "            WAS 6.0 : login ws360_nd"
  echo "	    WAS 6.1 : login wasnd61"
  echo "--> Usage : $YI_OUTIL/Start_Stop_Dmgr.sh start/stop"
  echo "-----------------------"
  echo " "
}


# ***************************************
# MAIN
# ***************************************

Entete

echo "Execution de la commande : $0 $*"
echo " "
echo "Resultat :"
echo " "

# Test des arguments
# -------------------
if [ $# != 1 ]
then
	echo "Erreur : Le script necessite un seul argument en parametre"
        Usage
	echo "Sortie du script en CR 3" 
        exit 3
fi


if [ $1 != "start" -a $1 != "stop" ]
then
	echo "Erreur : le parametre ne peut prendre comme valeur que start ou stop"
	Usage
	echo "Sortie du script en CR 3"
	exit 3
fi

if [ "$PROFILE_DMGR" = "" ]
then
         echo "Erreur : La variable PROFILE_DMGR n'est pas definie dans le .profile"
         echo "Le script doit etre lance avec le login executant les process WAS (normalement ws360_nd)"
         echo "Sortie du script en CR 3"
         exit 3
fi

# Execution du script
# -------------------
case $1 in
  start)
	echo "--> Statut actuel du dmgr avant demarrage :"
	$PROFILE_DMGR/bin/serverStatus.sh dmgr | grep -i STARTED 
	CodeR=$?
	if [ "$CodeR" = "0" ]
	then
	  echo "Le process dmgr est deja demarre"
	  echo "Sortie du script en CR 1"
	  exit 1
	else
	  echo "Le process dmgr est actuellement arrete"
	fi
	if [ -f $PROFILE_DMGR/bin/lp_startManager.sh ]
	then
	 $PROFILE_DMGR/bin/lp_startManager.sh
	else
	 $PROFILE_DMGR/bin/startManager.sh 
	fi
	CodeR=$?
	if [ "$CodeR" = "0" ]
	then
	 echo " "
	 echo "SUCCES du demarrage du process dmgr"
	 echo "Sortie du script en CR 0"
	 exit 0
	else
	 echo " "
	 echo "PROBLEME au demarrage du dmgr : Sortie du script en CR 3"
	 exit 3
	fi
 ;;
 stop)
        echo "--> Statut actuel du dmgr avant arret :"
        $PROFILE_DMGR/bin/serverStatus.sh dmgr | grep -i STARTED 
        CodeR=$?
        if [ "$CodeR" = "1" ]
        then
          echo "Le process dmgr est deja arrete"
          echo "Sortie du script en CR 1"
          exit 1
        else
          echo "Le process dmgr est actuellement demarre"
        fi
	if [ -f $PROFILE_DMGR/bin/lp_stopManager.sh ]
	then
	 $PROFILE_DMGR/bin/lp_stopManager.sh
	else
         $PROFILE_DMGR/bin/stopManager.sh 
	fi
        CodeR=$?
        if [ "$CodeR" = "0" ]
        then
         echo " "
         echo "SUCCES de l'arret du process dmgr"
	 echo "Sortie du script en CR 0"
	 exit 0
        else
         echo " "
         echo "PROBLEME a l'arret du process dmgr : Sortie du script en CR 3"
         exit 3
        fi
 ;;
 esac
