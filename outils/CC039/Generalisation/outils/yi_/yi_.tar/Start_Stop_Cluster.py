# Fonction a appeler

def entete():
 print "***************************************"
 print " Arret/Redemarrage d'un cluster WAS"
 print " Start_Stop_Cluster.py"
 print " Cible : WAS 6"
 print " "
 print " Parametres :  cluster, action"
 print " avec action ="
 print " - start : demarrage du cluster"
 print " - stop : arret  du cluster"
 print " "
 print " Exemple de commande :"
 print " wsadmin.sh -lang jython -f <chemin>Start_Stop_Cluster.py cluster01 stop"
 print " "
 print " Version 1.1 du 20/11/2014 IP"
 print " Modification du temps de pause pour les 5 dernieres minutes (300 au lieu de  60)"
 print "***************************************"
 print " "

def start_stop_cluster(myCell, clusterName, action ):
 cluster = AdminControl.completeObjectName('cell='+myCell+',type=Cluster,name='+clusterName+',*')
 if (( cluster == '' )):
        print "--> Erreur : Le Cluster "+clusterName+" n'existe pas"
        print "--> Sortie du script en CR 3"
        sys.exit(3)

 status = AdminControl.getAttribute(cluster, 'state')
 print "--> Lancement de Start_Stop_Cluster.py pour le cluster "+clusterName+", action = "+action+"."

 if (( action == 'stop' )):
        if (( status == 'websphere.cluster.stopped' )):
                print "--> Arret impossible : Le cluster "+clusterName+" est deja arrete"
                print "--> Sortie du script en CR 1"
                sys.exit(1)
        else:
                print "--> Tentative d'arret du cluster "+clusterName+" "
                try:
                  AdminControl.invoke(cluster, 'stop')
                except:
                  print "--> Impossible d'arreter le Cluster"
                  print "--> Exception declenchee Sortie du Script en CR 3"
                  print "--> Descript de l'exception :"
                  print sys.exc_info()
                  sys.exit(3)
                else:
                  # On teste le status du Cluster
                  # Si au bout de 7min le Cluster n'est pas arrete en sort en CR 3
                  time.sleep(20)
                  status = AdminControl.getAttribute(cluster, 'state')
                  if (( status != 'websphere.cluster.stopped' )):
                        time.sleep(40)
                        status = AdminControl.getAttribute(cluster, 'state')
                        if (( status != 'websphere.cluster.stopped' )):
                          print "Le Cluster n'a pas fini de s'arreter au bout d'1min : Nouveau test dans 1 min ..."
                          time.sleep(60)
                          status = AdminControl.getAttribute(cluster, 'state')
                          if (( status != 'websphere.cluster.stopped' )):
                            print "Le Cluster n'a pas fini de s'arreter au bout de 2min : Nouveau test dans 5 min ..."
                            time.sleep(300)
                            status = AdminControl.getAttribute(cluster, 'state')
                            if (( status != 'websphere.cluster.stopped' )):
                              print "Erreur : Le Cluster n'a pas fini de s'arreter au bout de 7min"
                              print "Sortie du script en Code Retour 3"
                              sys.exit(3)
                  print "--> Le Cluster "+clusterName+" est arrete"
                  print "--> Sortie du script en Code Retour 0"
                  sys.exit(0)

 if (( action == 'start' )):
        if (( status == 'websphere.cluster.running' )):
                print "--> Le cluster "+clusterName+" est deja demarre"
                print "--> Sortie du script en CR 1"
                sys.exit(1)
        else:
                print "--> Tentative de demarrage du cluster "+clusterName+" "
                try:
                  AdminControl.invoke(cluster, 'start')
                except:
                  print "--> Impossible de demarrer le Cluster"
                  print "--> Exception declenchee Sortie du script en CR 3"
                  print "--> Description de l'exception :"
                  print sys.exec_info()
                  sys.exit(3)
                else:
                  # On teste le status du Cluster
                  # Si au bout de 7min le Cluster n'est pas demarre en sort en CR 3
                  time.sleep(20)
                  status = AdminControl.getAttribute(cluster, 'state')
                  if (( status != 'websphere.cluster.running' )):
                        time.sleep(40)
                        status = AdminControl.getAttribute(cluster, 'state')
                        if (( status != 'websphere.cluster.running' )):
                          print "Le Cluster n'a pas fini de demarrer au bout d'1min : Nouveau test dans 1 min ..."
                          time.sleep(60)
                          status = AdminControl.getAttribute(cluster, 'state')
                          if (( status != 'websphere.cluster.running' )):
                            print "Le Cluster n'a pas fini de demarrer au bout de 2min : Nouveau test dans 5 min ..."
                            time.sleep(300)
                            status = AdminControl.getAttribute(cluster, 'state')
                            if (( status != 'websphere.cluster.running' )):
                              print "Erreur : Le Cluster n'a pas fini de demarrer au bout de 7min"
                              print "Code Retour 3"
                              sys.exit(3)
                  print "--> Le Cluster "+clusterName+" est demarre"
                  print "--> Code Retour 0"


# ***************************
# Main
# ***************************


import time

entete()

if (( len(sys.argv) != 2 )):
        print "--> Erreur nombre d'arguments incorrect: Le script Start_Stop_Cluster.py necessite 2 arguments"
        print "--> usage is : Start_Stop_Cluster cluster start/stop"
        print "--> Sortie du script en CR 3"
        sys.exit(3)
else:
        action = sys.argv[1]
        if (( action != "start" )) and (( action != "stop" )):
          print "--> 2eme parametre incorrect : "+action+""
          print "--> Le 2eme parametre ne peut etre que stop ou start"
          print "--> Sortie du script en CR 3"
          sys.exit(3)
        else:
          myCell = AdminControl.getCell( )
          clusterName = sys.argv[0]
          start_stop_cluster(myCell, clusterName, action )


