#!/bin/ksh

# Fonctions a appeler

# Entete du Script
Entete()
{
echo " ********************************************************************************"
echo " Serveur : " `hostname`
echo " Arret/Redemarrage de l'IHS WAS "
echo " Start_Stop_IHS.sh"
echo " Cible : WAS 6.x"
echo " "
echo " Parametres : action"
echo " avec action ="
echo " start : demarrage de l'ihs" 
echo " stop : arret de l'ihs"
echo " "
echo " Exemple de commande :"
echo " $YI_OUTIL/Start_Stop_IHS.sh stop"
echo " "
echo " Version 1.1 du 21/10/09 IP"
echo " Modifs : Prise en compte des scripts de type lp_ de la version 6.1.0.19"
echo " Modifs : Prise en compte du fait que la version 5.1 ne comporte pas de adminctl"
echo " Modifs : Pris en compte des process http uniquement websphere"
echo " ********************************************************************************"
echo " "
}


# Usage du script
Usage()
{
  echo " "
  echo "Utilisation du script :"
  echo "-----------------------"
  echo "--> Login :" 
  echo "      WAS 6.0 : Ce script doit etre lance avec le login root"
  echo "      WAS 6.1 : Ce script doit etre lance avec le login ihs661"
  echo "--> Usage : $YI_OUTIL/Start_Stop_IHS.sh start/stop"
  echo "-----------------------"
  echo " "
}


# ***************************************
# MAIN
# ***************************************

Entete

echo "Execution de la commande : $0 $*"
echo " "
echo "Resultat :"
echo " "

# Test des arguments
# -------------------
if [ $# != 1 ]
then
	echo "Erreur : Le script ne necessite qu'un seul argument en parametre"
        Usage
	echo "Sortie du script en CR 3" 
        exit 3
fi


if [ $1 != "start" -a $1 != "stop" ]
then
	echo "Erreur : le parametre ne peut prendre comme valeur que start ou stop"
	Usage
	echo "Sortie du script en CR 3"
	exit 3
fi

if [ "$IHS_HOME" = "" ]
then
         echo "Erreur : La variable IHS_HOME n'est pas definie dans le .profile"
         echo "Le script doit etre lance avec le login root"
         echo "Sortie du script en CR 3"
         exit 3
fi

# Execution du script
# -------------------
case $1 in
  start)
	echo "--> Statut actuel de l'ihs avant demarrage :"
	ps -ef | grep httpd | grep websphere | grep -v grep
	CodeR=$?
        if [ "$CodeR" = "0" ]
        then
	 echo "** L'ihs est deja demarree **"
	 echo "Sortie du script en CR 1"
	 exit 1
	else
	 echo "** L'ihs est actuellement arretee **" 
	fi
	echo " "
	if [ -f $IHS_HOME/bin/lp_apachectl ]
	then 
	 echo "--> Execution de la commande $IHS_HOME/bin/lp_apachectl start "
	 $IHS_HOME/bin/lp_apachectl start
	else
	 echo "--> Execution de la commande $IHS_HOME/bin/apachectl start "
	 $IHS_HOME/bin/apachectl start
	fi
	CodeR=$?
	if [ "$CodeR" = "0" ]
	then
	 echo " "
	 echo "SUCCES du demarrage de l'apachectl"
	else
	 echo " "
	 echo "PROBLEME au demarrage de l'apachectl : Sortie du script en CR 3"
	 exit 3
	fi
	echo " "
        if [ -f $IHS_HOME/bin/adminctl ]
        then
	 if [ -f $IHS_HOME/bin/lp_adminctl ]
	 then
	  echo "--> Execution de la commande $IHS_HOME/bin/lp_adminctl start"
	  $IHS_HOME/bin/lp_adminctl start
	 else	
	  echo "--> Execution de la commande $IHS_HOME/bin/adminctl start "
	  $IHS_HOME/bin/adminctl start
	 fi
	CodeR=$?
        if [ "$CodeR" = "0" ]
        then
         echo " "
         echo "SUCCES du demarrage de l'adminctl"
	 echo "SUCCES : Sortie du script en CR 0"
	 exit 0 
        else
         echo "PROBLEME au demarrage de l'adminctl : Sortie du script en CR 3" 
         exit 3
        fi
	fi
 ;;
 stop)
        echo "--> Statut actuel de l'ihs avant arret :"
        ps -ef | grep httpd | grep websphere | grep -v grep
        CodeR=$?
        if [ "$CodeR" != "0" ]
        then
         echo "** L'ihs est deja arretee **"
         echo "Sortie du script en CR 1"
         exit 1
        else
         echo "**--> L'ihs est actuellement demarree **"
        fi
	echo " "
	if [ -f $IHS_HOME/bin/lp_apachectl ]
        then
         echo "--> Execution de la commande $IHS_HOME/bin/lp_apachectl stop "
         $IHS_HOME/bin/lp_apachectl stop
        else
	 echo "--> Execution de la commande $IHS_HOME/bin/apachectl stop"
         $IHS_HOME/bin/apachectl stop
	fi
        CodeR=$?
        if [ "$CodeR" = "0" ]
        then
         echo " "
         echo "SUCCES de l'arret de l'apachectl"
        else
         echo " "
         echo "PROBLEME a l'arret de l'apachectl : Sortie du script en CR 3"
         exit 3
        fi
	echo " "
	if [ -f $IHS_HOME/bin/adminctl ]
        then
         if [ -f $IHS_HOME/bin/lp_adminctl ]
         then
          echo "--> Execution de la commande $IHS_HOME/bin/lp_adminctl stop"
          $IHS_HOME/bin/lp_adminctl stop
         else
	  echo "--> Execution de la commande $IHS_HOME/bin/adminctl stop"
          $IHS_HOME/bin/adminctl stop
	 fi
        CodeR=$?
        if [ "$CodeR" = "0" ]
        then
         echo " "
         echo "SUCCES du l'arret de l'adminctl"
         echo "SUCCES : Sortie du script en CR 0"
         exit 0
        else
         echo "PROBLEME a l'arret de l'adminctl : Sortie du script en CR 3"
         exit 3
        fi
	fi
 ;;
 esac
