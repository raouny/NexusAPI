#!/usr/bin/python
# -*- coding: utf-8 -*-

#from w9n import 
from fr.laposte import xml2dic, w9n
#import fr.laposte.w9n
from fr.laposte.w9n import *
import logging
from os import environ as env
import os.path
from optparse import OptionParser
import sys
import pprint
import datetime


def optParse():
    from optparse import OptionParser

    # FIXME: non utilise pour le moment
    listeChoix= ('backup','restore','dbcc','start','stop','reindex')

    parser = OptionParser(usage="%prog [options] arg - Version 1.0", version="%prog 1.0")

    parser.add_option("-c","--conf",dest="conf", action="store", type="string",
                      help="charge le fichier de configuration FILE [default: $W9NCONF]", metavar="FILE")
    # parser.set_default(option.conf,"valeur de la variable 'W9NCONF'")
    # parser.add_option("-C","--class",dest="classtype",choices=listeChoix, type="choice",
    #                   default='backup',
    #                   help="type d'outil ("
    #                   +', '.join(listeChoix)
    #                   +') [default: %default]')
    # parser.add_option("-t","--tache",dest="task",choices=listeTChoix, type="choice",
    #                   default='TITI',
    #                   help="nom de la tache a lancer ("
    #                   +', '.join(listeTChoix)
    #                   +') [default: %default]')

    parser.add_option("-v",action="count", dest="verbosity",
                      help="affiche les informations d'execution de l'outil")
    parser.add_option("-l",action="store_true",dest="tasklist",
                      help="liste les taches disponibles dans le fichier de configuration")
    parser.add_option("-n",action="store",dest="task",
                      help="liste les taches disponibles dans le fichier de configuration")

    parser.add_option("-q",action="store_const", const=0, dest="verbosity",
                      help="n'affiche aucune information d'execution.")

    options,args = parser.parse_args()
    return (parser, options, args)


def configureTool(): pass

class MyParser:
    def __init__(self,file):
        self.operation = {}
        self.opts = {}
        self.confdict = xml2dic.ConvertXmlToDict(file)
        self.general = self._getGeneral(self.confdict.w9nconf.general)
        operations = self.confdict.w9nconf.operations
        for op in operations.operation:
            self.operation[op.nom] = self._getGeneral(op)
            self.opts[op.nom] = dict([(item,op[item]) for item in op.keys() if item not in self.operation[op.nom]])
    
    def _getGeneral(self,node):
        attr = {}
        if 'username' in node: 
            attr['username'] = node.username
        if 'password' in node:
            attr['password'] = node.password
        if 'server' in node:
            attr['server'] = node.server
        if 'database' in node:
            attr['database'] = node.database
        if 'port' in node:
            attr['port'] = node.port
        return attr
        
    def getTaskAttrs(self,op):
        try:
            ret = dict(self.general)
            ret1 = dict(self.operation[op])
            ret.update(ret1)
        except KeyError:
            raise BadConfigurationError("Tache introuvable.")
        else:
            return ret

    def getTaskOpts(self,op):
        return self.opts[op]
    
    def getClassType(self,op):
        if 'class' in self.opts[op]:
            return self.opts[op]['class']

def dumpEnv(): pass
    
def main():
    def listeTask(configdict,parser):
        '''Fonction utilitaire pour lister les taches du catalogue sous la forme:\\
        NOM -> DESCRIPTION DE LA TACHE.'''
        print "\n\nListe des taches parametrees dans le fichier de configuration:"
        try:
            operations = configdict.w9nconf.operations
            print 'Nom \t\t||  desc'
            for oper in operations.operation:
                print ' %s  || %s' % (oper.nom,oper.desc)
            print "\n\nUtilisez %s -n <nom> pour lancer la tache <nom>" % sys.argv[0]
        except:
            parser.error("Aucune operation trouvee.")

    if env['TRACES'] is None:
        print "Variable TRACE non positionnee"
        sys.exit(2)


    # Parsing de la ligne de commande
    # optparse retourne les options en tant qu'attribut d'une instance object
    # je prefere utiliser un dictionnaire
    parser, opts, args = optParse()
    o = opts.__dict__
    opts = o

    # Ligne de commande incorrecte ? Trash
    if not sys.argv[1:]:
        parser.print_help()
        parser.error("Erreur de lancement. Utilisez %s -h pour plus d'informations." % sys.argv[0])


    # Test presence du fichier de conf
    # si absent, on sort *dignement*
    # FIXME: doit y avoir moyen de faire *beaucoup* plus propre
    confdict = []
    conffile = opts['conf']
    if conffile is None:
        try:
            conffile = env['W9NCONF']
            if os.path.exists(conffile) and os.path.isfile(conffile):
                confdict = xml2dic.ConvertXmlToDict(conffile)
        except KeyError:        
            parser.error("Pas de fichier de configuration exploitable et variable W9NCONF non renseignee")

    if os.path.exists(conffile) and os.path.isfile(conffile):
        confdict = xml2dic.ConvertXmlToDict(conffile)
    
    # L'utilisateur a active le -l
    # on repond et on sort
    if opts['tasklist'] is True:
        parser.print_help()
        listeTask(confdict,parser)
        sys.exit(0)

    #    ### LE GROS DU TRAVAIL COMMENCE ICI ###
    # Gros hack pour charger des modules dynamiquement
    try:
    	classes = __import__('fr.laposte.w9n',globals(),locals(),['w9n'],-1) # python >= 2.5
    except TypeError:
    	classes = __import__('fr.laposte.w9n',globals(),locals(),['w9n']) # python 2.4
    retval=0

    # Une liste des malheureux qui ne se connecteront pas a une base MySQL
    # (-i.e. toutes les commandes shell)
    # FIXME: plus trop d'actualite
    exclude = {"DBTaskAR" : 1 ,"DBTaskBackup" : 1, "DBTaskAStop" : 1, "DBTaskAStart" : 1, 
               "DBTaskARestart" : 1, "DBTaskDbccAlt" : 1 , "DBTaskReindexAlt" : 1}

    # Note outil, nu, seul et malheureux
    tool = ()

    logger.info("Debut du traitement DBA_mys.")
    logger.info("Infomations machines: %s" % " ".join(os.uname()[0:2]))
    try:
        try:
            p = MyParser(conffile) # Parsing du fichier de conf

            logger.info("Recuperation des attributs de la tache et ses options.")
            # Recuperation des attributs d'une tache et de ses options
            attr = p.getTaskAttrs(opts['task'])
            classe = p.getClassType(opts['task'])
            opts = p.getTaskOpts(opts['task'])

            # Init de l'outil
            tool = getattr(classes,classe)() #(attr,opts) #,exclude.get(classe))
            log.debug(tool)
#            logger.info("Creation de la tache.")

            logger.info("P: Configuration de l'outil")
            # Configuration de l'outil
            tool.configure(attr,opts)
            print tool
            logger.info("G: Tentative de connexion a la base")
            # Tentative de connexion
            tool.open()
        
            # Lancement de la tache
            # FIXME: il faut ajouter les options specifiques a une tache (un dict de dict ?)
            logger.info("G: Execution de la tache")
            tool.execute()
        except BadConfigurationError, err:
            retval=2
            parser.print_help()
            log.error("E: Erreur de parametrage. Corrigez et relancez.")
            log.error(err)
            log.exception("E: Pile d'execution a remonter au support:")
        except SGBDError, err:
            retval=3
            log.error(err)
            log.exception("E: Pile d'execution a remonter au support:")
        except Exception, err:
            retval=3
            log.error("E: Erreur generale.")
            log.exception("E: Pile d'execution a remonter au support:")
            # print 'Erreur globale. \n' \
            #     '%s \n' % err
            # import traceback
            # traceback.print_exc()
    finally: # Quoiqu'il arrive, il faut finir proprement
        tool.close()
        logger.info("I: Code retour global: %d" % retval)
        logger.info("---=== END ===---")
        print "Fichier de log a consulter: %s" % log_fn
        sys.exit(retval)
    # ### ICI S'ACHEVE NOTRE TRAVAIL ###


if __name__ == "__main__":
    # Mise en place du logger
    logger = logging.getLogger()
    logger.setLevel(10)
    
    now = datetime.datetime.now()
    ts = now.strftime('%Y%m%d%H%M%S')
    try:
        log_fn = '%s/%s-%s.log' % (env['TRACES'], ts, os.path.basename(sys.argv[0]))
    except:
        print "Erreur installation: la variable TRACES n'est pas positionnee."
        sys.exit(2)
        
    hdlr  = logging.FileHandler(log_fn)
    frmt  = logging.Formatter("%(levelname)-6s; %(process)-5s ; %(asctime)s ;  %(name)-15s ; %(message)s")
    hdlr.setFormatter(frmt)
    logger.addHandler(hdlr)
        
    logger.info('---=== START ===---')
    # Everything happens in main !
    main()

