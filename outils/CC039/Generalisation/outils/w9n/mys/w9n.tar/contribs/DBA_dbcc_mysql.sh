#!/bin/ksh

##########################################################################################################
# DBA_dbcc_mysql.sh                                                                                      |
#                                                                                                        |
# Controle l'integrite d'une table ou d'une base de donn�es                                              |
#                                                                                                        |
#                                                                                                        |
# Fichiers:                                                                                              |
#     check.tmp   	Fichier de travail                                                               |
#     check.sql   	Fichier de travail                                                               |
#     lstTables.tmp     Fichier de travail                                                               |
#                                                                                                        |
# Variables d'environnement:                                                                             |
#     TRAVAIL                         Repertoire des fichiers de travail                                 |
#     TRACES                          Repertoire des fichiers de trace                                   |
#                                                                                                        |
# Retour :									                	 |
#    0 : traitement sans erreur                                                                          |
#    3 : erreur sur les param�tres ou erreur bloquante lors du traitement	                         |
#                                				                                	 |
#											                 |
# 01/04/2009: DECLIC/DETA&S - Cr�ation du script -                                                       |
# 16/04/2009: DECLIC/DETA&S - Passage en version 1.1                                                     |
#				 - passage par un fichier de requetes .sql afin de limiter le nombre de  |
#					connexions MySQL                                                 |
#				 - suppression de la commande analyze table                              |
##########################################################################################################


#-----------------------------------------------------------------------------------------
# Lecture des parametres
#-----------------------------------------------------------------------------------------
DATE_HEURE=`date +%y%m%d%H%M%S`

for i 
do
case "$i" in
 -U*) USERNAME=`echo $i |cut -c 3-`;;
 -P*) PASSWD=`echo $i | cut -c 3-`;;
 -B*) BASE=`echo $i | cut -c 3-`;;
 -T*) TBL=`echo $i | cut -c 3-`;;
 -V*) echo "`basename $0` - Version 1.2"
      exit 0;;
 -h*) echo "Usage: `basename $0` -U{user} -P{password} -B{base} [-T{table}|-[V|h]"
      echo "       -U Utilisateur" 
      echo "       -P Mot de passe" 
      echo "       -B Nom de la base" 
      echo "       [-T Nom d'une table]" 
      echo "       [-V Affiche la version]" 
      echo "       [-h Affiche de l'aide]" 
      exit 0;;
esac
done

#-----------------------------------------------------------------------------------------
#  Controle des parametres 
#-----------------------------------------------------------------------------------------
if [ -z "$TRACES" ]
then
    echo 'La variable d environnement $TRACES doit etre definie.' >&2
    exit 3
fi
if [ ! -d $TRACES ]
then
  echo "Le repertoire de trace $TRACES n'est pas valide" >&2
  exit 3
else
  FICHIER_TRACE=$TRACES/$DATE_HEURE'_'$$.`basename $0`.log
  echo "Ouverture du fichier trace : "`date +%y%m%d%H%M%S` >>$FICHIER_TRACE
  echo "-----------------------------------------">>$FICHIER_TRACE
fi
if [ -z "$PASSWD" -o -z "$USERNAME" ]
then
  echo "Le nom de l'utilisateur et son mot de passe sont des parametres obligatoires.">>$FICHIER_TRACE
  exit 3
fi

if [ -z "$BASE" ]
then
  echo "Le nom de la base est obligatoire.">>$FICHIER_TRACE
  exit 3
fi

#-----------------------------------------------------------------------------------------
#  V�rification des droits sur la base
#-----------------------------------------------------------------------------------------
mysql -u$USERNAME -p$PASSWD -e "select * from mysql.user where user='"$USERNAME"' and password='$PASSWD';">/dev/null 2<&1
if [ $? -ne 0 ]
then
  echo "L'utilisateur ou le mot de passe est incorrect.">>$FICHIER_TRACE
  exit 3
fi


#v�rification des droits de lecture sur la base
mysql -u$USERNAME -p$PASSWD $BASE -e 'select 1'>/dev/null 2<&1
if [ $? -ne 0 ]
then
  echo "L'utilisateur ne peut pas acc�der � la base "$BASE>>$FICHIER_TRACE
  exit 3
fi

#-----------------------------------------------------------------------------------------
#  V�rification des droits sur le r�pertoire de travail
#-----------------------------------------------------------------------------------------
if [ -z "$TRAVAIL" ]
then
  if [ -z "$TEMP" ]
  then
    echo 'La variable d environnement $TRAVAIL doit etre definie.' >>$FICHIER_TRACE
    exit 3
  else
    TRAVAIL=$TEMP
    echo 'La variable d environnement $TRAVAIL n est pas definie, la variable $TEMP est utilisee.' >>$FICHIER_TRACE
  fi
fi
if [ ! -d $TRAVAIL ]
then
  echo "Le repertoire de travail $TRAVAIL n'est pas valide" >>$FICHIER_TRACE
  exit 3
fi

#droits d'ecriture dans le repertoire de travail
touch $TRAVAIL/monrep
if [ $? -eq 0 ]
then echo "Droits d'ecriture sur le repertoire $TRAVAIL : OK" >>$FICHIER_TRACE
     rm $TRAVAIL/monrep
else echo "Verifier les droits d'ecriture sur le repertoire $TRAVAIL" >>$FICHIER_TRACE
     exit 3
fi

###################################### CONTEXTE ##################################
echo "Parametres d'execution :">>$FICHIER_TRACE
echo "-U $USERNAME">>$FICHIER_TRACE
echo "-P (YES)">>$FICHIER_TRACE
echo "-B $BASE">>$FICHIER_TRACE
echo '$TRACES='"$TRACES">>$FICHIER_TRACE
echo '$TRAVAIL='"$TRAVAIL">>$FICHIER_TRACE
echo "-----------------------------------------">>$FICHIER_TRACE
###################################### SCRIPT PRINCIPAL ###########################


if [ ! -z $TBL ]
then
  echo "check de la table " $TBL >>$FICHIER_TRACE
  tables[1]=$TBL
else

#-----------------------------------------------------------------------------------------
#  Recherche de toutes les tables de la base
#-----------------------------------------------------------------------------------------
 echo "check de toutes les tables de la base " $BASE >>$FICHIER_TRACE
#tables=( $(mysql -u$USERNAME -p$PASSWD --skip-column-names -e 'SHOW TABLES' $BASE))
#la liste des tables est r�cup�r�e dans un fichier de travail afin de ne pas afficher les messages d'erreur dans la console et de g�rer les grands nombres de tables.
mysql -u$USERNAME -p$PASSWD --skip-column-names -e 'SHOW TABLES' $BASE >/dev/null 2<&1 >>$TRAVAIL/lstTables.tmp
 if [ $? -ne 0 ]
 then
  echo "L'utilisateur ne peut pas afficher les tables de la base "$BASE>>$FICHIER_TRACE
  exit 3
 fi
fi
echo 'use '$BASE >$TRAVAIL/check.sql
#for table in ${tables[@]}  
#lecture du fichier contenant la liste des tables 
while read table
do 
 echo 'CHECK TABLE '$table' ;' >>$TRAVAIL/check.sql
 if [ $? -ne 0 ]
 then
  echo "L'utilisateur ne peut creer les requetes CHECK dans le fichier " $TRAVAIL"/check.sql">>$FICHIER_TRACE
  exit 3
 fi
done < $TRAVAIL/lstTables.tmp
#ex�cution du script
mysql -u$USERNAME -p$PASSWD --skip-column-names < $TRAVAIL/check.sql >> $TRAVAIL/check.tmp
  if [ $? -ne 0 ]
  then
    echo "Une erreur est survenue lors de l'ex�cution du script "$TRAVAIL"/check.sql">>$FICHIER_TRACE
    exit 3
  fi
#Suppression des fichiers
rm -f $TRAVAIL/check.sql
rm -f $TRAVAIL/lstTables.tmp
#-----------------------------------------------------------------------------------------
#  Analyse des r�sultats
#-----------------------------------------------------------------------------------------
RETOUR=0
#Les r�sultats du check
echo "">>$FICHIER_TRACE
echo "-----------------------------------------">>$FICHIER_TRACE
echo "R�sultats du check" >>$FICHIER_TRACE
while read LIGNE
do
 #ecriture de la ligne
 echo $LIGNE >>$FICHIER_TRACE
 result=`echo $LIGNE | grep -v 'OK'`
if [ ! -z $result ]
then
 echo "ANOMALIE $result" >>$FICHIER_TRACE
RETOUR=3
fi
done < $TRAVAIL/check.tmp
#Suppression du fichier
rm -f $TRAVAIL/check.tmp


echo "" >>$FICHIER_TRACE
if [ $RETOUR -eq 0 ]
then
 echo "Aucune anomalie detectee" >>$FICHIER_TRACE
else
 echo "Des anomalies ont ete detectees" >>$FICHIER_TRACE
fi
echo "" >>$FICHIER_TRACE
echo "-----------------------------------------">>$FICHIER_TRACE
echo "Fin du traitement: "`date +%y%m%d%H%M%S` >>$FICHIER_TRACE
exit $RETOUR
