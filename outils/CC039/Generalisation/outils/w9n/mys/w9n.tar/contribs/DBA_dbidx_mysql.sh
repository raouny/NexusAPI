#!/bin/ksh

###########################################################################################################
# DBA_dbidx_mysql.sh                                                                                      |
#                                                                                                         |
# Optimise/r�indexe une base de donn�es,                                                                  |
#										                          |
#                                                                                                         |
# Fichiers:                                                                                               |
#     optimize.tmp   	Fichier de travail                                                                |
#                                                                                                         |
# Variables d'environnement:                                                                              | 
#     TRAVAIL                         Repertoire des fichiers de travail                                  |
#     TRACES                          Repertoire des fichiers de trace                                    |
#                                                                                        		  |
# Retour :										 		  |
#     0 : traitement sans erreur                                                                          |
#     3 : erreur sur les param�tres ou erreur bloquante lors du traitement			          |
#											                  |
# Modifications:                                                                                          |
# 01/04/2009: DECLIC/DETA&S - Cr�ation du script -                                                        |
###########################################################################################################



#-----------------------------------------------------------------------------------------
# Lecture des parametres
#-----------------------------------------------------------------------------------------

DATE_HEURE=`date +%y%m%d%H%M%S`
integer nb_analyze=0
for i 
do
case "$i" in
 -U*) USERNAME=`echo $i |cut -c 3-`;;
 -P*) PASSWD=`echo $i | cut -c 3-`;;
 -B*) BASE=`echo $i | cut -c 3-`;;
 -V*) echo "`basename $0` - Version 1.2"
      exit 0;;
 -h*) echo "Usage: `basename $0` -U{user} -P{password} -B{base}|-[V|h]"
      echo "       -U Utilisateur" 
      echo "       -P Mot de passe" 
      echo "       -B Nom de la base" 
      echo "       [-V Affiche la version]" 
      echo "       [-h Affiche de l'aide]" 
      exit 0;;
esac
done

#-----------------------------------------------------------------------------------------
#  Controle des parametres 
#-----------------------------------------------------------------------------------------
if [ -z "$TRACES" ]
then
    echo 'La variable d environnement $TRACES doit etre definie.' >&2
    exit 3
fi
if [ ! -d $TRACES ]
then
  echo "Le repertoire de trace $TRACES n'est pas valide" >&2
  exit 3
else
  FICHIER_TRACE=$TRACES/$DATE_HEURE'_'$$.`basename $0`.log
  echo "Ouverture du fichier trace : "`date +%y%m%d%H%M%S` >>$FICHIER_TRACE
  echo "-----------------------------------------">>$FICHIER_TRACE
fi
if [ -z "$PASSWD" -o -z "$USERNAME" ]
then
  echo "Le nom de l'utilisateur et son mot de passe sont des parametres obligatoires.">>$FICHIER_TRACE
  exit 3
fi

if [ -z "$BASE" ]
then
  echo "Le nom de la base est obligatoire.">>$FICHIER_TRACE
  exit 3
fi

#-----------------------------------------------------------------------------------------
#  V�rification des droits sur la base
#-----------------------------------------------------------------------------------------
mysql --silent -u$USERNAME -p$PASSWD -e "select * from mysql.user where user='"$USERNAME"' and password='$PASSWD';">/dev/null 2<&1
if [ $? -ne 0 ]
then
  echo "L'utilisateur ou le mot de passe est incorrect.">>$FICHIER_TRACE
  exit 3
fi

#v�rification des droits de lecture sur la base
mysql -u$USERNAME -p$PASSWD $BASE -e 'select 1'>/dev/null 2<&1
if [ $? -ne 0 ]
then
  echo "L'utilisateur ne peut pas acc�der � la base "$BASE>>$FICHIER_TRACE
  exit 3
fi


#-----------------------------------------------------------------------------------------
#  V�rification des droits sur le r�pertoire de travail
#-----------------------------------------------------------------------------------------
if [ -z "$TRAVAIL" ]
then
  if [ -z "$TEMP" ]
  then
    echo 'La variable d environnement $TRAVAIL doit etre definie.' >>$FICHIER_TRACE
    exit 3
  else
    TRAVAIL=$TEMP
    echo 'La variable d environnement $TRAVAIL n est pas definie, la variable $TEMP est utilisee.' >>$FICHIER_TRACE
  fi
fi
if [ ! -d $TRAVAIL ]
then
  echo "Le repertoire de travail $TRAVAIL n'est pas valide" >>$FICHIER_TRACE
  exit 3
fi


#droits d'ecriture dans le repertoire de travail
touch $TRAVAIL/monrep
if [ $? -eq 0 ]
then echo "Droits d'ecriture sur le repertoire $TRAVAIL : OK" >>$FICHIER_TRACE
     rm $TRAVAIL/monrep
else echo "verifier les droits d'ecriture sur le repertoire $TRAVAIL" >>$FICHIER_TRACE
     exit 3
fi

###################################### CONTEXTE ##################################
echo "Parametres d'execution :">>$FICHIER_TRACE
echo "-U $USERNAME">>$FICHIER_TRACE
echo "-P (YES)">>$FICHIER_TRACE
echo "-B $BASE">>$FICHIER_TRACE
echo '$TRACES='"$TRACES">>$FICHIER_TRACE
echo '$TRAVAIL='"$TRAVAIL">>$FICHIER_TRACE
echo "-----------------------------------------">>$FICHIER_TRACE
###################################### SCRIPT PRINCIPAL ###########################


mysqlcheck -u$USERNAME -p$PASSWD -o $BASE>> $TRAVAIL/optimize.tmp
if [ $? -ne 0 ]
then
  echo "L'utilisateur ne peut pas r�indexer la base "$BASE>>$FICHIER_TRACE
  exit 3
fi
#analyse des r�sultats
RETOUR=0

while read LIGNE
do
 echo $LIGNE  | grep -v Msg_text >>$FICHIER_TRACE
 result=`echo $LIGNE | grep -v 'Table is already up to date' | grep -v 'OK' | grep -v Msg_text `
 if [ ! -z $result ]
 then
  RETOUR=3
 fi
done < $TRAVAIL/optimize.tmp
#Suppression du fichier
rm -f $TRAVAIL/optimize.tmp

echo "" >>$FICHIER_TRACE
if [ $RETOUR -eq 0 ]
then
 echo "Traitement sans erreur" >>$FICHIER_TRACE
else
 echo "Erreur sur le traitement" >>$FICHIER_TRACE
fi

echo "" >>$FICHIER_TRACE
echo "-----------------------------------------">>$FICHIER_TRACE
echo "Fin du traitement: "`date +%y%m%d%H%M%S` >>$FICHIER_TRACE
exit $RETOUR
