#!/usr/bin/env python
# -*- coding: utf-8 -*-

import unittest


import os
import sys

rep = '../'
if os.path.isdir(rep):
    sys.path.append(rep)

from fr.laposte import xml2dic
from fr.laposte.w9n import *

# une classe DBTask
class LoadConf(unittest.TestCase):
    """
    Classe de test pour notre module de configuration
    """

    def setUp(self):
        """
        set up data used in the tests.
        """
        self.confdict = {}

    def testLoad404(self):
        """
        verifie les conditions du chargement
        """
        self.assertRaises(IOError,xml2dic.ConvertXmlToDict,'nimp')
        
    def testLoadNone(self):
        # ParamError lorsque pas de xml
        self.assertRaises(xml2dic.ParamError,xml2dic.ConvertXmlToDict,None)

    def testLoadXMLChunk(self):
        self.assertRaises(IOError,xml2dic.ConvertXmlToDict,'<test>test</test>')

    def testLoadEmptyFile(self):
        self.assertRaises(IOError,xml2dic.ConvertXmlToDict,"test-empty.xml")

# DBTask with default value
class testW9NToolDefault(unittest.TestCase):
    """
    Classe de test pour notre module
    """

    def setUp(self):
        """
        set up data used in the tests.
        """
        self.tool = W9NTool()
#        self.tool2 = W9NTool(self.task)

    def testDefaultValue(self):
        self.assertEqual(self.tool.server,'localhost','Incorrect default value')
        self.assertEqual(self.tool.port,3306,'Incorrect default value')
        self.assertEqual(self.tool.username,'root','Not root ?')
        self.assertEqual(self.tool.database,'information_schema','Not information_schema')
        self.assertEqual(self.tool.password,'','Not empty password')
        self.assertEqual(self.tool.hdlr,None,'Not None')
        self.assertEqual(self.tool.opts,{},'Not Empty')

    # def testRepr(self):
    #     self.assertEqual(self.task.__repr__(),DBTask.__repr__())

    def testMethodDefault(self):
        '''testMethodDefault should return None everywhere'''
        self.assertEqual(self.tool.configure(),None)
        self.assertEqual(self.tool.prepare(),None)
        self.assertEqual(self.tool.runTask(),None)
        self.assertEqual(self.tool.execute(),None)
        self.assertEqual(self.tool.finalize(),None)

    def testTool(self):
        # Un outil sans options doit renvoyer BadConfigurationError
#        self.assertRaisesRegexp(BadConfigurationError,"Mauvaise definition de la tache",self.tool.create(),None,"Mauvaise definition de la tache")
        self.assertRaises(BadConfigurationError,self.tool.configure,{},{'server':'test'})

    def testToolOpen(self):
        
        self.assertRaises(SGBDError,self.tool.open)
    
    def testToolClose(self):
        # print self.task
        #self.task.db_connect = None
#        self.tool.setAttr(self.tool.attr)
        # self.tool.create()
        self.tool.open()
        self.assertRaises(NameError,self.tool.close)


if __name__ == '__main__':
    argv = sys.argv[:]
    argv.insert(1,"-v")
    unittest.main()
