#!/usr/bin/env python
# -*- coding: utf-8 -*-

import unittest
from fr.laposte.w9n import *

# une classe DBTask
class testDBTask(unittest.TestCase):
    """
    Classe de test pour notre module
    """

    def setUp(self):
        """
        set up data used in the tests.
        """
        task = DBTask()
        self.assertUnlessEqual(task.server,None,'Incorrect default value')

    def testdef(self):
        self.assertUnlessEqual(task.server,None,'Incorrect default value')


if __name__ == '__main__':
    unittest.main()
