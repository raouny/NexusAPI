# -*- coding: utf-8 -*-

import sys
import os
import logging
import logging.handlers
import datetime

log = logging.getLogger(__name__)


#__VERSION

# Classes d'exception
class NotImplementedError: pass
class BadConfigurationError(Exception): pass
    # def __init__(self,value):
    #     self.value = value
    # def __str__(self):
    #     return repr(self.value)

class SGBDError(Exception):
    def __init__(self,value):
        self.value = value
    def __str__(self):
        return repr(self.value)

class NoConfigurationError: pass
class ShellCmdError(Exception):
    def __init__(self,value):
        self.value = value
    def __str__(self):
        return repr(self.value)

class W9NTool(object):
    """ Classe parent """
    cursor = None
    hdlr = None
    server = 'localhost'
    port = 3306
    username = 'root'
    password = ''
    database = 'information_schema'
    socket = '/var/lib/mysql/mysql.sock'
    opts = {}
    nop = None
    
    def __init__(self):
        log = logging.getLogger('%s.%s' % (__name__,self.__class__.__name__))
        log.info("Instanciation d'un %s" % self.__class__.__name__)

    def configure(self, attr={}, opts={}):
        log.info("Configuration d'un %s" % self.__class__.__name__)
        try:
            self.setMandatory(attr)
            self.setOpts(opts)
        except:
            return None

    def setOpts(self, opts={}):
        if opts:
            log.info("Set opts du %s" % self.__class__.__name__)
            self.opts = opts
        else:
            log.info("Aucune option specifique pour %s" % self.__class__.__name__)
            return None

    def setMandatory(self, attr={}):
        if attr:
            log.info("Set parametres obligatoires pour %s" % self.__class__.__name__)
            try:
                self.server = attr['server']
                self.database = attr['database']
                self.username = attr['username']
                self.password = attr['password']
            except KeyError:
                raise BadConfigurationError, 'Mauvaise definition de la tache.'
        else:
            log.info("Les parametres par defaut seront utilises pour %s" % self.__class__.__name__)
            return None

    def __repr__(self):
        return "%s(%r,%r,%r,%r)" % (self.__class__.__name__,
                                    self.server,
                                    self.database,
                                    self.username,
                                    self.password)

    def prepare(self):
        log.info("Creation du curseur SQL.")
        self.cursor = self.hdlr.cursor()
        log.debug(self.cursor)
        query = "select VERSION();"
        self.cursor.execute(query)
        res = self.cursor.fetchone()

        log.info("P server info: %s" % (str(res[0])))

    def runTask(self): pass
    def finalize(self): pass

    def execute(self):
        log.info("Execution de la tache.")
        self.prepare()
        self.runTask()
        self.finalize()

    def open(self):
        from MySQLdb import connect
        log.info("Test de la chaine de connexion a la base.")
        log.info("Tentative de connexion au schema %s en tant que %s@%s" %(self.database,self.username,self.server))
        try:
            if 'localhost' == self.server:
                # FIXME: on devrait tester que le socket est ok.

                try:
                    self.socket=os.environ['socket']
                except:
                    pass

            log.info("On utilise la socket %s" % self.socket)
            self.hdlr = connect(host=self.server,
                                db=self.database,
                                user=self.username,
                                passwd=self.password,
                                unix_socket=self.socket
                                )
            log.debug(self.hdlr)
        except Exception, err:
            raise SGBDError("Erreur de connexion: \n" \
                                "%s" % str(err))

    def close(self):
        try:
            log.info("P Destruction du curseur SQL")
            self.cursor.close()
            log.info("P Fermeture de la connexion a la base.")
            self.hdlr.close()
            log.debug(self.hdlr)
        except Exception, err:
            raise SGBDError("Erreur a la deconnexion: \n" \
                                "%s" % str(err))

class DBTaskSaveRestore(W9NTool):
    compress = None
    multi = 1
    tables = ''
    directory = None
    cmd= 'mysqldump'
    argu = None
    ts = ''
    full = 'no'
    dump = 'None'

    def runTask(self):
        W9NTool.runTask(self)

    def wantCompress(self):
        comp = {'yes' : 1, 'oui' : 1}
        if 'compress' in self.opts:
            if self.opts['compress'] in comp:
                return 1

    def wantFull(self):
        if self.full == "yes":
            return 1
        else:
            return 0

    def getDirectory(self):
        directory = None
        ## FIXME: variable globale ?
        print self.opts
        if 'directory' not in self.opts:
            raise BadConfigurationError, "Pas de clause 'directory'"
	else:
            directory = self.opts['directory']

        try:
            from os import environ as env
            directory = env[self.opts['directory']]
        except:
            pass
        return directory

    def prepare(self):
        W9NTool.prepare(self)

        self.directory = self.getDirectory()
        self.compress = self.wantCompress()
        now = datetime.datetime.now()
        self.ts = now.strftime('%Y%m%d%H%M%S')
        
        if self.wantFull():
            self.dump = "%s/%s-FULL.dump" % (self.directory, self.ts)
        else:
            self.dump = "%s/%s-%s.dump" % (self.directory, self.ts, self.database)
        self.argu = ["--user=" + self.username, "--password=" + self.password,
                     "--host=" + self.server, "--port=" + str(self.port),]
        
    def summary(self,liste=[]):
        log.info("P Resume de la tache:")
        liste[2]='--password=HIDDEN'
        [log.info("G: \t" + str(x)) for x in liste]

    def finalize(self):
        log.info("P: \t Sauvegarde effectuee => %s/%s.dump" % (self.getDirectory(), self.database))
        log.info("P: \t Operation de nettoyage de la tache")

    def zipBackup(self): pass

class DBTaskBKHot(DBTaskSaveRestore):

    cmd=['mysqlhotcopy']

    def runTask(self):
        W9NTool.runTask(self)
        try:
            self.cmd += self.argu
            print self.cmd
            import subprocess
            proc=subprocess.Popen(self.cmd, shell=False)# ,
                                 # stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        except OSError:
            # FIXME: on pourrait tester une autre commande avant de sortir
            raise BadConfigurationError("ERREUR FATALE: %s commande introuvable. Verifiez l'option cmd" %(self.cmd))

#        stdout, stderr = proc.communicate()
        if proc.wait() != 0:
            raise ShellCmdError, "Erreur d'execution du script: %s" %(proc.stdout.read())

    def prepare(self):
        # Call parent class method
        DBTaskSaveRestore.prepare(self)

        self.argu += [ "--allowold", "--flushlog", self.database, self.directory]


class DBTaskBKDump(DBTaskSaveRestore):

    cmd= ['mysqldump']
    
    def runTask(self):
        DBTaskSaveRestore.runTask(self)
        try:
            self.cmd += self.argu[:]
            self.summary(self.cmd[:])
        
            import subprocess
            proc=subprocess.Popen(self.cmd, shell=False,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        except OSError:
            # FIXME: on pourrait tester une autre commande avant de sortir
            raise BadConfigurationError("ERREUR FATALE: %s commande introuvable. Verifiez l'option cmd" %(self.cmd))

        stdout, stderr = proc.communicate()
        if proc.wait() != 0:
            raise ShellCmdError, "Erreur d'execution du script: %s" %(proc.stdout.read())

    def wantCompress(self):
        comp = {'yes' : 1, 'oui' : 1}
        if 'compress' in self.opts:
            if self.opts['compress'] in comp:
                return 1

    def prepare(self):
        DBTaskSaveRestore.prepare(self)

        self.argu += ["--flush-logs", "--single-transaction",
                      "--create-options", "--databases", self.database,
                      "--result-file=" + self.dump]

        
    def finalize(self):
        try:
            os.unlink("%s/latest-%s.dump" % (self.directory, self.database))
        except: # pas grave
            pass
        
        os.symlink("%s/%s-%s.dump" % (self.directory, self.ts, self.database),
                   "%s/latest-%s.dump" % (self.directory, self.database))

        log.info("P: Sauvegarde effectuee => %s/%s.dump" % (self.getDirectory(), self.database))
        log.info("Le lien latest-%s.dump pointe vers ce backup." % (self.database))
        log.info("P: Operation de nettoyage de la tache")

    def zipBackup(self): pass

class DBTaskBKDumpFULL(DBTaskBKDump):
    full = 'yes'
    
    def prepare(self):
        DBTaskSaveRestore.prepare(self)
        print self.dump
        #log.info("%s" % " ".join(t))
        self.argu += ["--flush-logs", "--single-transaction",
                      "--create-options", "--all-databases",
                      "--result-file=" + self.dump]

    def finalize(self):
        try:
            os.unlink("%s/latest-FULL.dump" % (self.directory))
        except: # pas grave
            pass
        
        os.symlink("%s/%s-FULL.dump" % (self.directory, self.ts),
                   "%s/latest-FULL.dump" % (self.directory))

        log.info("P: Sauvegarde FULL effectuee => %s/%s-FULL.dump" % (self.getDirectory(), self.ts))
        log.info("Le lien latest-FULL.dump pointe vers ce backup.")
        log.info("P: Operation de nettoyage de la tache")
                    

                     
class DBTaskDbcc(W9NTool):

    def prepare(self):
        W9NTool.prepare(self)

    def runTask(self):
        W9NTool.runTask(self)
        res = 0
        log.info("Creation du curseur.")
        cursor = self.hdlr.cursor()
        cursor.execute('select table_name from information_schema.tables where table_schema="%s";' % self.database)
        tables = cursor.fetchall()
        for i in tables:
            log.info("Analyse de la table: %s " % i[0])
            cursor.execute("CHECK TABLE %s EXTENDED;" % i[0])
            result = cursor.fetchone()
            if 'status' == result[2]:
                log.info("Status: %s" % (result[3]))
            elif 'note' == result[2]:
                log.info("Status: N/A Message: %s" % (result[3]))
            else:
                log.error("Status: %s Erreur: %s" % (result[2], result[3]))
                res = 1
            log.debug("Table: %s - Op: %s - Type: %s - Res: %s" % (result[0],result[1],result[2],result[3]))

        # Lorsque le traitement est *totalement* termine
        if res == 1:
            log.error("Au moins une erreur a ete detectee lors de l'execution")
            raise ShellCmdError("Erreur lors de l'execution de la tache.")
        else:
            log.info("Fin d'execution de la tache: OK")
            
    def finalize(self):
        logging.info("Fin d'execution de la tache.")

class DBTaskDbccAlt(W9NTool):
    cmd= '$W9NOUTIL/contribs/DBA_dbcc_mysql.sh.new'

    def runTask(self):
        # print "Execution de la commande: \n"
        # print self.cmd
        os.system(self.cmd)

    def getDirectory(self):
        directory = None
        ## FIXME: variable globale ?
        if 'directory' not in self.opts:
            raise BadConfigurationError, "Pas de clause 'directory'"
        else:
            directory = self.opts['directory']

        try:
            from os import environ as env
            directory = env[self.opts['directory']]
        except:
            pass
        return directory

    def prepare(self):
        W9NTool.prepare(self)

        self.cmd += " -U%s -B%s -P%s" % (self.username, self.database, self.password)

    def finalize(self):
        print "DBCC effectue"

class DBTaskRestore(DBTaskSaveRestore):
    nop = 1
    cmd = ['mysql']
    full = 'no'

    def runTask(self):
        DBTaskSaveRestore.runTask(self)
        try:
            self.cmd += self.argu[:]
            self.summary(self.cmd[:])
            print self.cmd
            import subprocess
            proc=subprocess.Popen(self.cmd, shell=False,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        except OSError:
            # FIXME: on pourrait tester une autre commande avant de sortir
            raise BadConfigurationError("ERREUR FATALE: %s commande introuvable. Verifiez l'option cmd" %(self.cmd))

        #stdout, stderr = proc.communicate()
        if proc.wait() != 0:
            raise ShellCmdError, "Erreur d'execution du script: %s" %(proc.stdout.read())

    def prepare(self):
        DBTaskSaveRestore.prepare(self)

        if self.full == 'yes':
            output = "%s/latest-FULL.dump" % (self.directory)
        else:
            output = "%s/latest-%s.dump" % (self.directory, self.database)

        self.argu += [self.database, "-e", "source %s" % (output)]

        
    def finalize(self):
        log.info("P: Restore de %s effectuee" % self.database)

    # def runTask(self):
    #     W9NTool.runTask(self)
    #     res = 0
    #     cursor = self.cursor
    #     cursor.execute('use %s ;' % self.database)
    #     cursor.execute("""SOURCE %s""", '/tmp/w9n.dump')
    #     # tables = cursor.fetchall()
    #     # for i in tables:
    #     #     log.info("Rebuild de la table: %s " % i[0])
    #     #     cursor.execute("OPTIMIZE TABLE %s ;" % i[0])
    #     #     result = cursor.fetchone()
    #     #     if 'status' == result[2]:
    #     #         log.info("Status: %s" % (result[3]))
    #     #         log.debug("Table: %s - Op: %s - Type: %s - Res: %s" % (result[0],result[1],result[2],result[3]))
    #     #     else:
    #     #         log.error("Status: %s Erreur: %s" % (result[2], result[3]))
    #     #         log.debug("Table: %s - Op: %s - Type: %s - Res: %s" % (result[0],result[1],result[2],result[3]))
    #     #         res = 1

    #     # Lorsque le traitement est *totalement* termine
    #     if res == 1:
    #         log.error("Au moins une erreur a ete detectee lors de l'execution")
    #         raise ShellCmdError("Erreur lors de l'execution de la tache.")
    #     else:
    #         log.info("Fin d'execution de la tache: OK")
            
    # def finalize(self):
    #     logging.info("Fin d'execution de la tache.")

class DBTaskRestoreFULL(DBTaskRestore):
    database = ' '
    full = 'yes'
        
class DBTaskReindex(W9NTool):

    def prepare(self):
        W9NTool.prepare(self)
    
    def runTask(self):
        W9NTool.runTask(self)
        res = 0
        log.info("Creation du curseur.")
        cursor = self.hdlr.cursor()
        cursor.execute('select table_name from information_schema.tables where table_schema="%s";' % self.database)
        tables = cursor.fetchall()
        for i in tables:
            log.info("Rebuild de la table: %s " % i[0])
            cursor.execute("OPTIMIZE TABLE %s ;" % i[0])
            result = cursor.fetchone()
            if 'status' == result[2]:
                log.info("Status: %s" % (result[3]))
            elif 'note' == result[2]:
                log.info("Status: N/A Message: %s" % (result[3]))
            else:
                log.error("Status: %s Erreur: %s" % (result[2], result[3]))
                res = 1
            log.debug("Table: %s - Op: %s - Type: %s - Res: %s" % (result[0],result[1],result[2],result[3]))

        # Lorsque le traitement est *totalement* termine
        if res == 1:
            log.error("Au moins une erreur a ete detectee lors de l'execution")
            raise ShellCmdError("Erreur lors de l'execution de la tache.")
        else:
            log.info("Fin d'execution de la tache: OK")
            
    def finalize(self):
        logging.info("Fin d'execution de la tache.")

class DBTaskReindexAlt(W9NTool):
    cmd= 'mysqlcheck'

    def runTask(self):
        try:
            print [self.cmd,"-U" + self.username, "-P" + self.password,
                                   "-B" + self.database]
            import subprocess
            proc=subprocess.Popen(self.cmd, shell=False,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            stdout, stderr = proc.communicate()
            print stdout
            print stderr

        except OSError:
            # FIXME: on pourrait tester une autre commande avant de sortir
            raise BadConfigurationError("ERREUR FATALE: %s commande introuvable. Verifiez l'option cmd" %(self.cmd))

#        stdout, stderr = proc.communicate()
        if proc.wait() != 0:
            raise ShellCmdError, "Erreur d'execution du script: %s" %(proc.stdout.read())

        # print "Execution de la commande: \n"
        # print self.cmd
#        os.system(self.cmd)

    def getDirectory(self):
        directory = None
        ## FIXME: variable globale ?
        if 'directory' not in self.opts:
            raise BadConfigurationError, "Pas de clause 'directory'"
        else:
            directory = self.opts['directory']

        try:
            from os import environ as env
            directory = env[self.opts['directory']]
        except:
            pass
        return directory

    def prepare(self):
        W9NTool.prepare(self)
        self.cmd = [self.cmd, "-u" + self.username, "-p" + self.password,
                    "-o", "-v", self.database]

#        self.cmd += " -U%s -B%s -P%s" % (self.username, self.database, self.password)

    def finalize(self):
        print "DBCC effectue"

class DBTaskAR(W9NTool):

    cmd= 'rcmysql'
    mode = None

    def runTask(self):
        W9NTool.runTask(self)
        try:
            import subprocess
            proc=subprocess.Popen([self.cmd,self.mode], shell=False,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        except OSError:
            # FIXME: on pourrait tester une autre commande avant de sortir
            raise BadConfigurationError("ERREUR FATALE: %s commande introuvable. Verifiez l'option cmd" %(self.cmd))

#        stdout, stderr = proc.communicate()
        if proc.wait() != 0:
            raise ShellCmdError, "Erreur d'execution du script: %s" %(proc.stdout.read())

#        os.system(self.cmd)

    def prepare(self):
        W9NTool.prepare(self)

        output = None
	if self.mode is None:
            if 'mode' not in self.opts:
                raise BadConfigurationError, "Aucun parametrage de l'outil trouve. Manque la balise \"mode\""
            else:
                print "self.mode vaut %s" %(self.mode)
                self.mode = self.opts['mode']
                
#        self.cmd += " %s" % self.mode

class DBTaskAStart(DBTaskAR): 
    mode = "start"
    def prepare(self): pass
    def open(self): pass
    def close(self): pass

class DBTaskAStop(DBTaskAR): mode = "stop"

class DBTaskARestart(DBTaskAR): 
    mode = "restart"
    def prepare(self): pass
    def open(self): pass
    def close(self): pass


def checkNotNone(func):
    return func
