#!/bin/sh
SHLLNAME=$(basename $0)
# Version du shell (a changer a chaque modif)
VERSION="$SHLLNAME v1.0 - pour Oracle 10g Release 2 sur Unix\n"
CARTOUCHE="
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ PROJET                   : Oracle10g
# ~~~~ NOM DU PROGRAMME         : $SHLLNAME
# ~~~~ Version                  : $VERSION
# ~~~~ _________________________________________________________________________"
# ~~~~ HISTORIQUE
# ~~~~ Version---Date----------Auteur--------------Commentaires-----------------
# ~~~~   1.0    18/10/2007   C.Pivel       Creation
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ BUT DU PROGRAMME :
# ~~~~     Configurer rman pour mise en oeuvre outils dba save/restore
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ FICHIERS DE PARAMETRES APPELES :
# ~~~~  Aucun
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ CODES RETOURS :
# ~~~~  - 0 : Fin normale du programme
# ~~~~  - 1 : Un ou plusieurs alertes sont remontees sans incidence sur
# ~~~~        l'execution du programme.
# ~~~~  - 2 : Erreur sur les parametres passes au script. Interruption.
# ~~~~  - 3 : Traitement en erreur.
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ PARAMETRES D'ENTREE : (nom du parametre - format - libelle)
# ~~~~      char    repertoire de sauvegarde
# ~~~~ _________________________________________________________________________
# ~~~~

### Variables essentielles
# Identifiant date
IDDATE=$(date '+%y%m%d%H%M%S')

LOGFILE=${TRACES}/${IDDATE}.${SHLLNAME}.log
if [ $# -ne 1 ];then
	echo -e "usage: config_rman.sh <repertoire destination save control file>"
	exit 2
fi
rman target / log=$LOGFILE <<EOF
sql 'alter system set control_file_record_keep_time=8 scope=both';
CONFIGURE CONTROLFILE AUTOBACKUP ON;
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '$1/%d_%F';
show all;
quit
EOF
RC=$?
cat $LOGFILE
exit $RC
