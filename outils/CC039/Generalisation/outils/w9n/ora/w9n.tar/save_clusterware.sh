#!/bin/sh
SHLLNAME=$(basename $0)
# Version du shell (a changer a chaque modif)
VERSION="$SHLLNAME v1.1 - pour Oracle 10g Release 2 sur Unix\n"
CARTOUCHE="
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ PROJET                   : Oracle10g
# ~~~~ NOM DU PROGRAMME         : $SHLLNAME
# ~~~~ Version                  : $VERSION
# ~~~~ _________________________________________________________________________"
# ~~~~ HISTORIQUE
# ~~~~ Version---Date----------Auteur--------------Commentaires-----------------
# ~~~~   1.0    06/11/2007   C.Pivel       Creation
# ~~~~   1.1    23<F2>01<F2>2009   C.Pivel  Maj purge traces
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ BUT DU PROGRAMME :
# ~~~~    sauvegarde oracle cluster registry et fichier voting
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ FICHIERS DE PARAMETRES APPELES :
# ~~~~  Aucun
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ CODES RETOURS :
# ~~~~  - 0 : Fin normale du programme
# ~~~~  - 1 : Un ou plusieurs alertes sont remontees sans incidence sur
# ~~~~        l'execution du programme.
# ~~~~  - 2 : Erreur sur les parametres passes au script. Interruption.
# ~~~~  - 3 : Traitement en erreur.
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ PARAMETRES D'ENTREE : (nom du parametre - format - libelle)
# ~~~~  -d  char    repertoire de sauvegarde
# ~~~~ _________________________________________________________________________
# ~~~~

### Variables essentielles
# Identifiant date
IDDATE=$(date '+%y%m%d%H%M%S')
###
CRS_HOME="/oracle/crs/10.2.0.3"
CLUSTER=`${CRS_HOME}/bin/ocrcheck|grep /oradata|awk -F'/' '{print $4}'`
TRACES="/oradata/${CLUSTER}/traces"
LOGFILE=${TRACES}/${IDDATE}.${SHLLNAME}.log
HOSTNAME=`hostname|awk '{print tolower(\$1)}'`
###
# Fonction de logging
verbose ()
{
    echo -e "$*" | tee -a $LOGFILE
}

###
# Sortie du traitement et gestion du CR
code_retour ()
{
    CODE=$1 ; shift

    RAISON=$*

    case $CODE in
        0)
            verbose "[SUCCES]: =>> $RAISON"
           ;;
        1)
            verbose "!!ATTENTION!! : =>> $RAISON"
            ;;
        2|3)
            verbose "/!\ ERREUR CR${CODE} /!\ \n[ERREUR]: =>> $RAISON"
            verbose "\t\t*** Arret du programme ***\n"
            exit $CODE
            ;;
        *)
            verbose "Code retour en dehors du rang [0-3]. Verifiez le code.\n"\
                "# ~~~~ -=-=-=-=-=-= Fin du script $SHLLNAME. Code retour: 3 =-=-=--=-=-="
            exit $CODE
            ;;
    esac
}
###
# Usage du shell
usage ()
{
   [ "$1" ] && verbose "\n$SHLLNAME: $*"

   cat <<EOF

   $VERSION

   usage:     $SHLLNAME -d<repertoire sauvegarde>

   options:   -d <repertoire> : Nom du repertoire de sauvegarde.

              -V              : Affiche la version et quitte.

Exemple d'utilisation:

  $SHLLNAME -d/ccx_svdb/backup_ocr
EOF
}


if [ $# -ne 1 ];then
	echo -e "usage: save_clusterware.sh -d<repertoire destination save>"
	exit 2
fi
###
# Affectation des arguments
ARGSS="$*"
while getopts d:Vh OPT
do
     case $OPT in
         "d" ) REPDEST=$OPTARG ;;
         "V" ) echo -e $VERSION && exit 0 ;;
         "h" ) usage && exit 0 ;;
         "?" ) usage && code_retour 2 "Option non valide: -$OPTARG";;
         ":" ) usage && code_retour 2 "Parametre obligatoire non fourni pour l'option -$OPTARG";;
     esac
done

###
###
# Verification des arguments
#[ -z "${CLUSTER}" ] && usage && code_retour 2 "Aucun nom de cluster specifie (option -c). Arret du programme."
[ -z "${REPDEST}" ] && usage && code_retour 2 "Repertoire de sauvegarde non specifie (option -d). Arret du programme."

###
# Verification de la disponibilite du repertoire de sauvegarde
# Creation si necessaire
if [ ! -d ${REPDEST} ]
then mkdir -p ${REPDEST}
     code_retour $? "creation de ${REPDEST} car il n'existait pas"
     chmod 777 ${REPDEST}
     code_retour $? "positionnement des droits 777 sur ${REPDEST}"
else verbose "le repertoire ${REPDEST} existe deja"
fi

# Verification de la disponibilite du repertoire de traces
# Creation si necessaire
if [ ! -d ${TRACES} ]
then mkdir -p ${TRACES}
     code_retour $? "creation de ${TRACES} car il n'existait pas"
     chmod 777 ${TRACES}
     code_retour $? "positionnement des droits 777 sur ${TRACES}"
else verbose "le repertoire ${TRACES} existe deja"
fi


# sauvegarde du fichier voting
verbose "sauvegarde du fichier voting"
/bin/dd if=/oradata/${CLUSTER}/${CLUSTER}vote.crs of=${REPDEST}/bk_${CLUSTER}vote.crs >>$LOGFILE 2>&1
RC=$?
if [ "${RC}" -ne 0 ];then
	RC=3
fi
code_retour ${RC} "sauvegarde du fichier voting"
# export du fichier ocr
verbose "export du fichier ocr"
${CRS_HOME}/bin/ocrconfig -export ${REPDEST}/${CLUSTER}ocr.exp.${IDDATE} -s online >>$LOGFILE 2>&1
RC=$?
if [ "${RC}" -ne 0 ];then
	RC=3
fi
#cat ${CRS_HOME}/log/${HOSTNAME}/client/ocrconfig_${PID}.log
code_retour ${RC} "export du fichier ocr"
# purge des exports ocr de plus d une semaine
find ${REPDEST} -ctime +7 -name "${CLUSTER}ocr.exp.*" -exec rm {} \;
code_retour $? "purge export ocr"
# purge des fichiers trace des commandes ocr
find ${CRS_HOME}/log/${HOSTNAME}/client  -ctime +7 -name ocrcheck_*.log -exec rm {} \;
find ${CRS_HOME}/log/${HOSTNAME}/client  -ctime +7 -name ocrconfig_*.log -exec rm {} \;
#
# purge des traces de plus de 14 jours
find ${TRACES} -ctime +14  -exec rm {} \;
code_retour 0 "sauvegarde clusterware"
