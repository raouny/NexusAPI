#!/bin/ksh
##########################################################################################
# DBA_imp                                                               	         |
#                                                                                        |
# Appel de l'utilitaire import d'Oracle					                 |
#                                                                                        |
# Description:                                                                           |
# Permet d'importer une table, un schema ou une base de donn�es                          |
# La variable d'environnement NLS_LANG est positionn�e pour etre conforme au jeu         |
# de caract�res de la base de donn�es                                                    |
#                                                                                        |
# Restrictions :                                                                         |
# restrictions relatives � l'utilisation de l'utilitaire import                          |
#                                                                                        |
# Tables utilisees:                                                                      |
#     USER_ROLE_PRIVS                                                                    |
#     USER_TABLES                                                                        |
#     V$NLS_PARAMETERS                                                                   |
#                                                                                        |
# Fichiers:                                                                              |
#     YYMMDDHHMISS.DBA_imp.log       	Fichier de trace                                 |
#     expdat.dmp                     	Nom par d�faut du Fichier d'export               |
#     user.tmp		 	     	Fichier de travail 				 |
#     objet.tmp		     		Fichier de travail 				 |
#     nls_lang.tmp		     	Fichier de travail 				 |
#     $TRAVAIL/`basename $0`.$$.par  	Fichier de parametres de l'import		 |
#                                                                                        |
# Variables d'environnement:                                                             |
#     ORACLE_SID                      Base par defaut                                    |
#     TRACES                          Repertoire des fichiers de trace                   |
#     TRAVAIL                         Repertoire des fichiers de travail                 |
#     DMPREP                          Repertoire des fichiers DUMP Oracle                |
#                                                                                        |
# Retour :										 |
#     0 : traitement sans erreur							 |
#     1 : erreur sur le traitement avec erreur lors de l'import		 		 |
#     2 : erreur sur les parametres							 |
#     3 : erreur bloquante lors du traitement						 |
#											 |
# Modifications:                                                                         |
# 23/01/2009: CP reprise de l'existant 9i                                                |
##########################################################################################

# set -x

#-----------------------------------------------------------------------------------------
# Lecture des parametres
#-----------------------------------------------------------------------------------------
DATE_HEURE=`date +%y%m%d%H%M%S`
typeset FILENAME=""
typeset TABLE=""
typeset -i SCHEMAFLAG=0
typeset -i BASEFLAG=0
typeset -i IGNOREFLAG=0
typeset -i COMMITFLAG=0
typeset -i TRONQUER=0
typeset -u USERNAME
typeset -u TABLE
typeset -i TRANSPORT=0
REPERTOIRE=""
for i 
do
case "$i" in
 -U*) USERNAME=`echo $i |cut -c 3-`;;
 -P*) PASSWD=`echo $i | cut -c 3-`;;
 -T*) TABLE=`echo $i | cut -c 3-`;;
 -R*) REPERTOIRE=`echo $i | cut -c 3-`;;
 -S*) SCHEMAFLAG=1;;
 -B*) BASEFLAG=1;;
 -F*) FILENAME=`echo $i | cut -c 3-`;;
 -i*) IGNOREFLAG=1;;
 -c*) COMMITFLAG=1;;
 -t*) TRONQUER=1;;
 -O*) TRANSPORT=1;;
 -V*) echo "`basename $0` - Version 2.3\n"
      exit 0;;
 -h*) echo "Usage: `basename $0` [-U{user} -P{password} -[T{table}|S|B|O][-R{repertoire}][-F{fichier}][-i][-c]][-t][V|h]"
      echo "       -U\tUsername" 
      echo "       -P\tPassword" 
      echo "       -T\tTable"
      echo "       -S\tImporte le schema"
      echo "       -B\tImporte la base"
      echo "       -O\tImporte le schema specifie par -U dans le cadre de tablespaces transportables"
      echo "       -R\tNom de repertoire de destination du dump"
      echo "       -F\tFichier"
      echo "       -i\tIgnore les erreurs de creation"
      echo "       -c\tCommits intermediaires"
      echo "       -t\tTronque les tables avant de les charger"
      echo "       -V\tAffiche la version" 
      echo "       -h\tAffiche de l'aide" 
      exit 0;;
esac
done

#-----------------------------------------------------------------------------------------
#  Controle des parametres 
#-----------------------------------------------------------------------------------------

integer n=0

if [ -z "$TRACES" ]
then
    echo 'La variable d environnement $TRACES doit etre definie.' >&2
    exit 2
fi
if [ ! -d $TRACES ]
then
  echo "Le repertoire de trace $TRACES n'est pas valide" >&2
  exit 2
else
  FICHIER_TRACE=$TRACES/$DATE_HEURE.`basename $0`.log
  echo "Ouverture du fichier trace : "`date +%y%m%d%H%M%S` >>$FICHIER_TRACE
  echo "-----------------------------------------">>$FICHIER_TRACE
fi

if [ -z "$PASSWD" -o -z "$USERNAME" ]
then
  echo "Le nom de l'utilisateur et son mot de passe sont des parametres obligatoires.">>$FICHIER_TRACE
  exit 2
fi

if [ -z "$ORACLE_SID" ]
  then
    echo 'La variable d environnement $ORACLE_SID doit etre definie.'>>$FICHIER_TRACE
    exit 2
fi
sqlplus -s $USERNAME/$PASSWD > $TRACES/user.tmp << FIN
WHENEVER SQLERROR exit 2
exit
FIN
if [ $? -ne 0 ]
then
  echo "L'utilisateur ou le mot de passe est incorrect ou base arretee.">>$FICHIER_TRACE
  rm -f $TRACES/user.tmp
  exit 2
fi
rm -f $TRACES/user.tmp

if [ ! -z "$TABLE" ]
then
  let n=n+1
fi
if [ "$SCHEMAFLAG" -eq 1 ]
then
  let n=n+1
fi
if [ "$BASEFLAG" -eq 1 ]
then
  let n=n+1
fi
if [ "$TRANSPORT" -eq 1 ]
then
  let n=n+1
fi

if [ n -eq 0 ]
then
  echo "!!! Un des parametres T, S, B ou O est obligatoire." >&2
  exit 2
elif [ n -gt 1 ]
then
  echo "Les options T, S, B et O sont exclusives">&2
  exit 2
fi
if [ -z "$TABLE" -a -z "$SCHEMAFLAG" -a -z "$BASEFLAG" -a -z "$TRANSPORT" ]
then
  echo "Le parametres T doit etre suivi d'une valeur." >>$FICHIER_TRACE
  exit 2
fi
if [ -z "$TRAVAIL" ]
then
  if [ -z "$TEMP" ]
  then
    echo 'La variable d environnement $TRAVAIL doit etre definie.' >>$FICHIER_TRACE
    exit 2
  else
    TRAVAIL=$TEMP
    echo 'La variable d environnement $TRAVAIL n est pas definie, la variable $TEMP est utilisee.' >>$FICHIER_TRACE
  fi
fi
if [ ! -d $TRAVAIL ]
then
  echo "Le repertoire de travail $TRAVAIL n'est pas valide" >>$FICHIER_TRACE
  exit 2
fi

touch $TRAVAIL/essai_ecriture
if [ $? -eq 0 ]
then echo "on a bien les droits d'ecriture sur le repertoire $TRAVAIL" >>$FICHIER_TRACE
     rm $TRAVAIL/essai_ecriture
else echo "verifier les droits d'ecriture sur le repertoire $TRAVAIL" >>$FICHIER_TRACE
     exit 2
fi

# Verification de l'existence de l'objet
if [ -n "$TABLE" ]
then
  echo $TABLE > $TRAVAIL/table.tmp
  sed -e "s/,/','/g" $TRAVAIL/table.tmp|cat|read TABLES
  sqlplus -s $USERNAME/$PASSWD > $TRAVAIL/objet.tmp << FIN
  WHENEVER SQLERROR exit 2
  set head off
  set feed off
  select 'X' from user_tables
  where table_name in ('$TABLES');
FIN
  if [ $? -ne 0 -o ! -s $TRAVAIL/objet.tmp ]
  then
    echo "La ou les table(s) $TABLE n'existe(nt) pas dans le schema $USERNAME." >>$FICHIER_TRACE
    rm -f $TRAVAIL/objet.tmp
    exit 2
  fi
  rm -f $TRAVAIL/objet.tmp
fi

if [ -z "$REPERTOIRE" ]
then if [ -z "$DMPREP" ]
     then echo "l option -R doit etre renseignee ou la variable d environnement \$DMPREP doit etre definie." >>$FICHIER_TRACE
          exit 2
     else REP=$DMPREP
     fi
else REP=$REPERTOIRE
fi

if [ ! -d "$REP" ]
then echo "Le repertoire de travail $REP n'est pas valide" >>$FICHIER_TRACE
     exit 2
fi

if [ $TRANSPORT -eq 1 ]
then REPDATA=$REP/datafiles
     if [ ! -d "$REPDATA" ]
     then echo "!!! Le repertoire de travail $REPDATA n'existe pas" >>$FICHIER_TRACE
     fi
fi

###################################### CONTEXTE ##################################
echo "Parametres d'execution :">>$FICHIER_TRACE
echo "-U $USERNAME">>$FICHIER_TRACE
echo "-P $PASSWD">>$FICHIER_TRACE
echo "-T $TABLE">>$FICHIER_TRACE
echo "-R $REPERTOIRE">>$FICHIER_TRACE
echo "-S $SCHEMAFLAG">>$FICHIER_TRACE
echo "-B $BASEFLAG">>$FICHIER_TRACE
echo "-O $TRANSPORT">>$FICHIER_TRACE
echo "-F $FILENAME">>$FICHIER_TRACE
echo "-i $IGNOREFLAG">>$FICHIER_TRACE
echo "-c $COMMITFLAG">>$FICHIER_TRACE
echo "-t $TRONQUER">>$FICHIER_TRACE
echo '$ORACLE_SID='"$ORACLE_SID">>$FICHIER_TRACE
echo '$TRACES='"$TRACES">>$FICHIER_TRACE
echo '$TRAVAIL='"$TRAVAIL">>$FICHIER_TRACE
echo '$DMPREP='"$DMPREP">>$FICHIER_TRACE
echo "-----------------------------------------">>$FICHIER_TRACE

#-----------------------------------------------------------------------------------------
# Definition des variables
#-----------------------------------------------------------------------------------------

typeset PARTEMP=$TRAVAIL/`basename $0`.$$.par

###################################### SCRIPT PRINCIPAL ##################################
#-----------------------------------------------------------------------------------------
# Generation du fichier de parametrage
#-----------------------------------------------------------------------------------------


if [ -z "$FILENAME" ]
then echo "FILE=$REP/expdat.dmp">>$PARTEMP
     FILE=$REP/expdat.dmp
else echo "FILE=$REP/$FILENAME">>$PARTEMP
     FILE=$REP/$FILENAME
fi

if [ ! -s "$FILE" ]
then echo "le fichier d'export $FILE n'existe pas !">>$FICHIER_TRACE
     rm $PARTEMP
     exit 2
fi
#Dans le cadre de tablespaces transportables (option -O), des operations specifiques ont lieu et sont decrites dans le paragraphe ci-dessous
if [ $TRANSPORT -eq 1 ]
then
     echo "TRANSPORT_TABLESPACE=Y" >>$PARTEMP
     DebutTSName=$(echo $USERNAME|cut -c1-9)

#####recuperation des noms des TS en fonction du nom du schema
     sqlplus -S '$USERNAME/$PASSWD as sysdba' > $TRAVAIL/tablespaces.tmp << FIN_SQL
     WHENEVER SQLERROR EXIT 3
     set pagesize 0
     set head off
     set feed off
     select tablespace_name from dba_tablespaces
     where tablespace_name like upper('$DebutTSName%');
FIN_SQL
     if [ $? -ne 0 -o ! -s $TRAVAIL/tablespaces.tmp ]
     then
          echo "!!! Erreur lors de la recherche des noms des tablespaces">>$FICHIER_TRACE
          rm -f $TRAVAIL/tablespaces.tmp
          rm -f $PARTEMP
          exit 3
     fi

#### recuperation des datafiles pour ces tablespaces
     sqlplus -S '$USERNAME/$PASSWD as sysdba' > $TRAVAIL/ts_data_files.tmp << FIN_SQL
     WHENEVER SQLERROR EXIT 3
     set pagesize 0
     set head off
     set feed off
     select file_name from dba_data_files where tablespace_name like upper('$DebutTSName%');
FIN_SQL
     if [ $? -ne 0 -o ! -s $TRAVAIL/ts_data_files.tmp ]
     then
          echo "!!! Erreur lors de la recherche des noms des fichiers des tablespaces">>$FICHIER_TRACE
          rm -f $TRAVAIL/ts_data_files.tmp
          rm -f $PARTEMP
          exit 3
     else
##########Verification de l'existence des datafiles
          for DATAFILE in `cat $TRAVAIL/ts_data_files.tmp`
          do
          NOM_DATAFILE=`basename ${DATAFILE}`
          if [ ! -s "$REPDATA/$NOM_DATAFILE" ]
          then echo "!!! le fichier $NOM_DATAFILE n'est pas present dans le repertoire $REPDATA: on arrete la">>$FICHIER_TRACE
               exit 3
          fi
          done
     fi

#####suppression des TS a importer
     for TS in `cat $TRAVAIL/tablespaces.tmp`
     do
#####suppression du TS
     sqlplus -S '$USERNAME/$PASSWD as sysdba' <<FIN_SQL
     set pagesize 0
     set head off
     set feed off
     alter tablespace $TS offline;
     drop tablespace $TS including contents and datafiles;
FIN_SQL
     if [ $? -ne 0 ]
     then echo "!!! Probleme de mise offline ou de la suppression du tablespace $TS">>$FICHIER_TRACE
          exit 3
     else echo "$TS mis offline et supprime">>$FICHIER_TRACE
     fi
     done
#####copie depuis l espace de la sauvegarde les datafiles des TS concernes
     for FICHIER in `cat $TRAVAIL/ts_data_files.tmp`
     do
        NOM_FIC=`basename ${FICHIER}`
        cp -p $REPDATA/${NOM_FIC} ${FICHIER}
        if [ $? -ne 0 ]
        then echo "Erreur dans la copie du fichier ${NOM_FIC}: Import arrete">>$FICHIER_TRACE
        exit 3
        fi
     done

     LST_TS="("
     for TS in `cat $TRAVAIL/tablespaces.tmp`
     do
     LST_TS=${LST_TS}" $TS,"
     done

     NbCar=$(expr $(echo $LST_TS|wc -c) - 1)
     LST_TS_FIN=$(echo $LST_TS|cut -c1-$(expr $NbCar - 1))
     LST_TS_FIN=${LST_TS_FIN}" )"
     echo "TABLESPACES=${LST_TS_FIN}" >>$PARTEMP

     LST_FIC="("
     for FICHIER in `cat $TRAVAIL/ts_data_files.tmp`
     do
        LST_FIC=${LST_FIC}"'${FICHIER}',"
        NOM_FIC=`basename ${FICHIER}`
     done
     NbCar=$(expr $(echo $LST_FIC|wc -c) - 1)
     LST_FIC_FIN=$(echo $LST_FIC|cut -c1-$(expr $NbCar - 1))
     LST_FIC_FIN=${LST_FIC_FIN}")"
     echo "DATAFILES=${LST_FIC_FIN}" >>$PARTEMP

     echo "Les tablespaces a importer sont "$LST_TS_FIN>>$FICHIER_TRACE
     echo "Les datafiles a importer sont "$LST_FIC_FIN>>$FICHIER_TRACE


else

     if [ $IGNOREFLAG -eq 1 ]
     then echo "IGNORE=Y">>$PARTEMP
     fi

     if [ $COMMITFLAG -eq 1 ]
     then echo "COMMIT=Y">>$PARTEMP
     fi

     #fin du remplissage du fichier de parametre et troncature eventuelle avant import des donnees
     if [ ! -z "$TABLE" ]
     then echo "TABLES=$TABLE">>$PARTEMP
          FIN_REQUETE_TRONCATURE="where owner=upper('$USERNAME') and table_name in ('$TABLES');"
     fi

     if [ SCHEMAFLAG -eq 1 ]
     then echo "FROMUSER=$USERNAME">>$PARTEMP
          FIN_REQUETE_TRONCATURE="where owner=upper('$USERNAME');"
     fi

     if [ BASEFLAG -eq 1 ]
     then echo "FULL=Y">>$PARTEMP
          FIN_REQUETE_TRONCATURE=";"
     fi

     if [ $TRONQUER -eq 1 ]
     then sqlplus -s $USERNAME/$PASSWD > $TRAVAIL/troncature.tmp << FIN
          WHENEVER SQLERROR EXIT 3
          set pagesize 0
          set head off
          set feed off
          select 'truncate table '||owner||'.'||table_name||';' from dba_tables $FIN_REQUETE_TRONCATURE 
FIN
          if [ $? -ne 0 ]
          then echo "la requete pour constituer les ordres de troncature des tables a echoue: la suite en donne l explication">>$FICHIER_TRACE
               cat $TRAVAIL/troncature.tmp >> $FICHIER_TRACE
               rm $TRAVAIL/troncature.tmp
               exit 3
          else sqlplus -s $USERNAME/$PASSWD > $TRAVAIL/troncature.log << FIN
               WHENEVER SQLERROR EXIT 3
               set pagesize 0
               set head off
               set feed off
               @$TRAVAIL/troncature.tmp
FIN
               if [ $? -ne 0 ]
               then echo "la troncature des tables a echoue: la suite en donne l explication">>$FICHIER_TRACE
                    cat $TRAVAIL/troncature.log >> $FICHIER_TRACE
                    rm $TRAVAIL/troncature.log
                    exit 3
               else echo "la troncature des tables devant etre chargees a ete effectuee avec succes">>$FICHIER_TRACE
               fi
          fi
     fi
fi

#-----------------------------------------------------------------------------------------
# Lancement de la commande
#-----------------------------------------------------------------------------------------
# construction du NLS_LANG
echo "Recherche des parametres NLS de la base de donnees">>$FICHIER_TRACE
sqlplus -s $USERNAME/$PASSWD > $TRAVAIL/nls_lang.tmp << FIN
WHENEVER SQLERROR EXIT 3
set pagesize 0
set head off
set feed off
select value from v\$nls_parameters
where parameter='NLS_LANGUAGE';
select value from v\$nls_parameters
where parameter='NLS_TERRITORY';
select value from v\$nls_parameters
where parameter='NLS_CHARACTERSET';
FIN
if [ $? -ne 0 -o ! -s $TRAVAIL/nls_lang.tmp ]
then
  echo "Erreur lors de la recherche des parametres NLS">>$FICHIER_TRACE
  rm -f $TRAVAIL/nls_lang.tmp
  rm -f $PARTEMP
  exit 3
fi
integer i=0
for LIGNE in `cat $TRAVAIL/nls_lang.tmp`
do
   let i=i+1
   if [ i -eq 1 ]
   then
     NLS_LANG=$LIGNE
   elif [ i -eq 2 ]
   then
     NLS_LANG=${NLS_LANG}_$LIGNE
   elif [ i -eq 3 ]
   then
     NLS_LANG=${NLS_LANG}.$LIGNE
   fi
done
echo 'La variable $NLS_LANG a pour valeur: '$NLS_LANG>>$FICHIER_TRACE
export NLS_LANG

echo "Appel de l'utilitaire import d'Oracle.">>$FICHIER_TRACE

if [ $TRANSPORT -eq 1 ];then
	imp userid = \'$USERNAME/$PASSWD as sysdba\' PARFILE=$PARTEMP 1>>$FICHIER_TRACE 2>&1
else
	imp userid = \'$USERNAME/$PASSWD\' PARFILE=$PARTEMP 1>>$FICHIER_TRACE 2>&1
fi
if [ $? -ne 0 ]
then
     echo "Erreur lors de l'appel a l'utilitaire import d'Oracle">>$FICHIER_TRACE
     rm -f $TRAVAIL/nls_lang.tmp
     rm -f $PARTEMP
     exit 3
fi
 
echo "-----------------------------------------">>$FICHIER_TRACE
echo "Fin du traitement: "`date +%y%m%d%H%M%S` >>$FICHIER_TRACE 
rm -f $PARTEMP
rm -f $TRAVAIL/nls_lang.tmp

if grep "IMP-" ${FICHIER_TRACE} >/dev/null
then
   if [ "$IGNOREFLAG" -eq 0 ]
   then
      exit 1
   else
      exit 3
   fi
fi

#####mise en read write des TS
     for TS in `cat $TRAVAIL/tablespaces.tmp`
     do
     sqlplus -S '$USERNAME/$PASSWD as sysdba' <<FIN_SQL
     set pagesize 0
     set head off
     set feed off
     alter tablespace $TS read write;
FIN_SQL
     if [ $? -ne 0 ]
     then echo "!!! Probleme de mise en read write du tablespace $TS">>$FICHIER_TRACE
          exit 3
     else echo "$TS mis en read write">>$FICHIER_TRACE
     fi
     done

# Compilation des objets invalides du schema
sqlplus -S '$USERNAME/$PASSWD as sysdba' <<FIN_SQL  >$TRAVAIL/compile_objets.tmp
set pagesize 0
set head off
set feed off
spool $TRAVAIL/objets.tmp
select 'alter ' || object_type || ' ' || owner || '.'|| object_name || DECODE (object_type, 'VIEW', ' compile;', 'PACKAGE', ' compile package;')
from   dba_objects
where  owner = upper('$SCHEMA_NAME')
and    object_type in ('VIEW','PACKAGE')
and    status = 'INVALID'
order by object_type desc;

spool off
@$TRAVAIL/objets.tmp
FIN_SQL
if grep "ORA-" $TRAVAIL/compile_objets.tmp >/dev/null
then
  echo "Erreur lors de compilation des objets invalides pour le schema $SCHEMA_NAME">>$FICHIER_TRACE
else
 rm -f $TRAVAIL/objets.tmp
 rm -f $TRAVAIL/compile_objets.tmp
fi

echo "-----------------------------------------">>$FICHIER_TRACE
echo "Fin du traitement: "`date +%y%m%d%H%M%S` >>$FICHIER_TRACE
rm -f $PARTEMP
rm -f $TRAVAIL/tablespaces.tmp
rm -f $TRAVAIL/ts_data_files.tmp

