#!/bin/ksh

# ~~~~			FICHE SIGNALETIQUE SHELL
#set -x
# Nom des fichiers issus du shell
SHLLNAME=$(basename $0)
# Version du shell (a changer a chaque modif)
VERSION="$SHLLNAME v2.4 - pour Oracle 10g Release 2 sur Unix\n"
CARTOUCHE="
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ PROJET			: Oracle10g
# ~~~~ NOM DU PROGRAMME	        : DBA_anlz.sh
# ~~~~ Creation         	: 2007-10-18
# ~~~~ Derniere Modification	: <2007-10-18 16:58:33 nkr629>
# ~~~~ Version                  : $VERSION
# ~~~~ _________________________________________________________________________"
# ~~~~ HISTORIQUE
# ~~~~ Version---Date----------Auteur--------------Commentaires-----------------
# ~~~~   1.0    18/10/2007    C.Pivel       Reprise de l'existant
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ BUT DU PROGRAMME :
# ~~~~     Fait un estimate sur les tables et indexes d'un schema passe en parametre
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ FICHIERS DE PARAMETRES APPELES :
# ~~~~  Aucun
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ CODES RETOURS :
# ~~~~  - 0 : Fin normale du programme
# ~~~~  - 1 : Un ou plusieurs alertes sont remontees sans incidence sur
# ~~~~        l'execution du programme.
# ~~~~  - 2 : Erreur sur les parametres passes au script. Interruption.
# ~~~~  - 3 : Traitement en erreur.
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ PARAMETRES D'ENTREE : (nom du parametre - format - libelle)
# ~~~~ -U	char	utilisateur
# ~~~~ -P	char	Mot de passe
# ~~~~ [ -p]    int 	pourcentage des lignes de la base prises pour effectuer l'analyse
# ~~~~ [ -S ]   char	schema, si different de -U
# ~~~~ [ -B ]	char	Oracle SID, si different de la valeur contenue dans le .profile
# ~~~~ [ -V ]	bool	Affiche la version et quitte
# ~~~~ _________________________________________________________________________
# ~~~~

### Variables essentielles
# Identifiant date
IDDATE=$(date '+%y%m%d%H%M%S')
# Code retour des traitements
RETCODE=0
DF_CMD=""

###
# Valeurs par defaut
VERBOSE="true" #${VERBOSE:-""}
#SCHEMA=${TSNAME2:-""}
PERCENT=${PERCENT:-"30"}
#ESTIMATE=${ESTIMATE:-}
SAYVER=""

###
# Verification en amont
[ -z "${TRACES}" ] && echo -e "La variable TRACES n'est pas positionnee. Renseignez-la et recommencez." && exit 3
LOGFILE=${TRACES}/${IDDATE}.${SHLLNAME}.log


###
# Fonction de logging
verbose ()
{
    [ "$SAYVER" ] && echo -e "\n$*" && return ## Juste pour afficher la version
    [ "$VERBOSE" ] && echo -e "$*" | tee -a $LOGFILE
}

###
# Usage du shell
usage ()
{
   [ "$1" ] && verbose "\n$SHLLNAME: $*"

   cat <<EOF

   $VERSION

   usage:     $SHLLNAME [-U<utilisateur>] [-P<mot_de_passe>]
                        [ -S<schema> ] [ -B<oracle SID> ]
                        [ -p<pourcent> ] [-V]

   options:   -U <utilisateur>: Le nom de l'utilisateur qui possede des droits dba sur l'instance.
				Format: <utilisateur>/<mot de passe> (comme sur la ligne sqlplus.
                                L'utilisateur doit OBLIGATOIREMENT detenir les droits sysdba.
                                (Defaut: sys/???)
	      
	      -P <mot de passe>: Mot de passe pour l'utilisateur passe en argument.

              -p <pourcent>     : pourcentage de lignes de la base prises pour effectuer l'analyse
                                (Defaut: 30)

              -S <schema>     : Nom du schema a utiliser
                                (Defaut: $USERNAME).

              -B <Oracle SID>  : Le SID Oracle 
                                (Defaut: $ORACLE_SID).

              -v              : Mode non verbeux.

              -V              : Affiche la version et quitte.

Exemple d'utilisation:
  
  $SHLLNAME -Usys -Psys -Stoto -B$ORACLE_SID
EOF
}

# Fichiers temporaires
TMPSQL=/tmp/${SHLLNAME}_$$.sql
TMPFILE=/tmp/${SHLLNAME}_$$.tmp
TMPPIPE=/tmp/${SHLLNAME}_$$.pipe
TMPRET=/tmp/${SHLLNAME}_$$.ret

retour ()
{
# Sortie du traitement et gestion du CR
# Calcul du nb d'erreurs
typeset -i NBERR=$(grep -c '[^0]' ${TMPRET})

# Calcul du code retour max
RETCODE=$(cat ${TMPRET} |sort -n -u |tail -1)
[ ${RETCODE} -ge 3 ] && RETCODE=3
verbose " ${NBERR} Erreur(s) , code retour le plus haut : ${RETCODE}"
}

###
# Sortie du traitement et gestion du CR
code_retour ()
{
    CODE=$1 
    if [ -z $CODE ]; then
	$CODE=-1
    else
	shift
    fi
    
    RAISON=$*

    case $CODE in
	-1) verbose "[INFO]: =>> $RAISON"
	    ;;
	0)
	    echo -e "$CODE" >> ${TMPRET}
            verbose "[SUCCES]: =>> $RAISON"
	   ;;
	1)
	    echo -e "$CODE" >> ${TMPRET}
	    verbose "!!ATTENTION!!: =>> $RAISON"
	    ;;
	2|3)
	    verbose "/!\ ERREUR CR${CODE} /!\ \n[ERREUR]: =>> $RAISON"
	    verbose "\t\t*** Arret du programme ***\n"
	    echo -e $CODE >> ${TMPRET} && exit
	    ;;
	*)
	    verbose "Code retour en dehors du rang [0-3]. Verifiez le code.\n"\
		"# ~~~~ -=-=-=-=-=-= Fin du script $SHLLNAME. Code retour: 3 =-=-=--=-=-=" 
	    echo -e $CODE >> ${TMPRET} && exit
	    ;;
    esac
}

_log ()
{
   code_retour -1 "$*"
}

trap 'echo =====================================================;
_log !!!Programme interrompu en reponse a un signal INT, HUP ou TERM!!!;
_log "Sortie en code retour 3"; echo 3 >> ${TMPRET} && exit' INT HUP TERM

trap 'retour;
_log Suppression des fichiers temporaires et Fin du script; 
rm -f ${TMPFILE} ${TMPSQL} ${TMPRET} ${TMPPIPE} 2>/dev/null;
echo =====================================================;
_log Fichier traces disponibles sous $LOGFILE;
exit $RETCODE' EXIT QUIT


###
# Affectation des arguments
ARGSS="$*"
ARGSS=$(echo -e $ARGSS | sed 's/-P.* /-P***** /')
while getopts :B:U:P:S:p:vVF OPT
do
     case $OPT in
         "B" ) SID=$OPTARG ;;
         "U" ) USERID=$OPTARG ;;
         "P" ) PASSWD=$OPTARG ;;
         "S" ) SCHEMA=`echo -e $OPTARG | tr 'a-z_' 'A-Z_'` ;;
	 "p" ) POURCENT=$OPTARG ;;
         "v" ) VERBOSE="" ;;
	 "V" ) SAYVER="true" 
	     verbose "$VERSION"
	     trap '' EXIT QUIT
	     SAYVER="";
	     exit 0 ;;
	 "h" ) usage && exit 0 ;;
         "?" ) usage && code_retour 2 "Option non valide: -$OPTARG";;
         ":" ) usage && code_retour 2 "Parametre obligatoire non fourni pour l'option -$OPTARG";;
     esac
done
echo -e "schema = "$SCHEMA
shift `expr $OPTIND - 1`

###
# Moyen simple de deboguer le script
DEBUG=${DEBUG:=0}
DEBUG_=""
if [[ ${DEBUG} -gt 0 ]]; then
    echo -e "Mode DEBUG active. Mise en place des traps."
    set -x
    trap 'verbose "DEBUG: Ligne $LINENO"' DEBUG
    trap 'verbose "ERREUR LIGNE: $LINENO" ' ERR
    DEBUG_=echo
fi

###
# Affichage du cartouche
verbose "$CARTOUCHE \n"\
"# ~~~~**** Resume du lancement: ****\n"\
"# ~~~~Arguments passes au script :\n"\
"# ~~~~ ----+ $ARGSS +----\n"\
"# ~~~~Fichiers temporaires: ...........\n"\
"# ~~~~ ----+ SQL:          ....... $TMPSQL\n"\
"# ~~~~ ----+ Code retour : ....... $TMPRET\n"\
"# ~~~~ ----+ Temp:         ....... $TMPFILE\n"\
"# ~~~~Variables ENV: ..........\n"\
"# ~~~~ ----+ TRACES:       ....... $TRACES\n"\
"# ~~~~ ----+ ORACLE_SID:   ....... $ORACLE_SID\n"\
"# ~~~~Fichier resultat a consulter:\n"\
"# ~~~~ ----+ $LOGFILE\n"\
"# ~~~~ _________________________________________________________________________\n"

_log "Sauvegarde du Oracle SID"
SAVED_SID=${SAVED_SID:-$ORACLE_SID}

SID=${SID:-$SAVED_SID}
SCHEMA=${SCHEMA:-$USERID}
POURCENT=${POURCENT:-"30"}

###
# Fait un estimate a l'aide du paquet DBMS_UTILITY
# dbms_utility.analzyze_schema (
# schema           VARCHAR2,
# method           VARCHAR2,
# estimate_rows    NUMBER   DEFAULT NULL,
# estimate_percent NUMBER   DEFAULT NULL,
# method_opt       VARCHAR2 DEFAULT NULL);

# -- method options
# COMPUTE
# DELETE
# ESTIMATE
analyze_estimate()
{
#  [[ $# -lt 2 ]] && code_retour 3 "[Ligne $LINENO]: Probleme de passage de parametre"

#  dbms_utility.analyze_schema(upper('$SCHEMA'),'ESTIMATE', NULL, '$POURCENT');
  sqlplus -S "$LOGIN"<<EOF
SET SERVEROUTPUT ON
SET HEAD OFF FEEDBACK OFF VERIFY OFF
SET LINESIZE 200 TRIMSPOOL ON TRIMOUT ON
whenever sqlerror exit 3
begin
  
  dbms_output.put_line('Lancement avec la commande: dbms_utility.analyze_schema(upper(''$SCHEMA''),''ESTIMATE'', NULL, ''$POURCENT'')');
  -- dbms_stats.gather_schema_stats(OWNNAME=>upper('$SCHEMA'),estimate_percent => dbms_stats.auto_sample_size, method_opt => 'for all indexed columns');
  -- dbms_utility.analyze_schema(upper('$SCHEMA'),'ESTIMATE', NULL, '$POURCENT');
  -- dbms_stats.gather_schema_stats(OWNNAME=>upper('$SCHEMA'),estimate_percent => dbms_stats.auto_sample_size, CASCADE=>TRUE );
  dbms_stats.gather_schema_stats(OWNNAME=>upper('$SCHEMA'),estimate_percent =>5, CASCADE=>TRUE );
end;
/
exit
EOF
    
}


### 
# Verification des arguments    
[ -z "${SID}" ] && usage && code_retour 2 "Aucun Oracle SID specifie ou Oracle SID non valide (option -B). Arret du programme."

[ -z "${USERID}" ] && usage && code_retour 2 "[Ligne $LINENO]: Le nom d'utilisateur est un parametre obligatoire (-U)"
[ -z "${PASSWD}" ] && usage && code_retour 2 "[Ligne $LINENO]: Le mot de passe est un parametre obligatoire (-P)"

LOGIN="$USERID/$PASSWD as sysdba"
LOGIN="/ as sysdba"

###
# Test du USERID
_log "Verification du bon fonctionnement de la connexion..."
case $USERID in
    "sys" )
	sqlplus -S '$USERID/$PASSWD as sysdba' > $TMPFILE<<EOF
WHENEVER SQLERROR exit 3
exit
EOF
	if [ $? -ne 0 ]
	    then
	    code_retour 3 "[Ligne $LINENO]: Utilisateur/Mot de passe incorrect ou droits insuffisants."
	else
	    code_retour 0 "[Ligne $LINENO]: La connexion a l'instance s'est bien effectuee"
	    LOGIN="$USERID/$PASSWD as sysdba"
	fi
	;;	     
    *)  
	sqlplus -S $LOGIN > $TMPFILE <<EOF
WHENEVER SQLERROR exit 3
set pagesize 0
set head off
set feed off
select 'X' from dba_role_privs
where grantee = upper('$USERID') and granted_role = 'DBA';
quit
EOF
	if [ $? -ne 0 ]
	    then
	    code_retour 3 "[Ligne $LINENO]: L'utilisateur ou le mot de passe est incorrect."
#	elif [ ! -s $TMPFILE ]
#	    then
#	    code_retour 3 "[Ligne $LINENO]: L'utilisateur $USERNAME n'a pas les droits suffisants."
	else
	    code_retour 0 "[Ligne $LINENO]: La connexion a l'instance s'est bien effectuee"
	fi
	;;
esac

####verification du role DBA du USERID
sqlplus -S "$LOGIN"> $TMPFILE <<EOF
WHENEVER SQLERROR exit 3
set pagesize 0
set head off
set feed off
select 'X' from dba_role_privs
where grantee = '$USERID' and granted_role = 'DBA';
quit
EOF
CR=$?
if [ $CR -ne 0 ] 
    then
    if [ -s $TMPFILE ]
	then
        verbose "la base n'est pas ouverte et il est impossible de lire la table dba_role_privs;"
        verbose "on continue quand meme mais il n'est possible d'affirmer ou d'informer que le login $USERID"
        verbose "possede le role DBA ou pas: attention a la suite du script"
    else code_retour 3 "[Ligne $LINENO]: erreur lors de la verification du role de DBA"
    fi
else
#    if [ -s $TMPFILE ]
#	then
	 verbose "l'utilisateur $USERID possede bien le role DBA" 
#else code_retour 0 "[Ligne $LINENO]: l'utilisateur $USERID ne possede pas le role de DBA: arret du script"
#fi
fi

###
# Boucle principale
###

###
# Suppression des fichiers temporaires si
# le script est interrompu par l'utilisateur (signaux 2 et 3)
trap '_log "Annulation du script"
_log "Suppression des fichiers temporaires et Fin du script"; 
rm -f ${TMPFILE} ${TMPSQL} ${TMPRET} ${TMPPIPE}
code_retour 3 "!!! Interruption du programme !!!"\
"             \n\t\t!!! For�age du code retour en 3 !!!";' INT HUP TERM

_log "Lancement des estimate statistiques..."
analyze_estimate

exit

### DBA_anlz ends here

## Local variables:
## folded-file: t
## fold-internal-margins: nil
## mode: shell-script
## time-stamp-line-limit: 0
## time-stamp-start: "Derniere Modification[\t]+:[ \t]+\\\\?[\"<]+"
## end:
