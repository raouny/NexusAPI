#!/bin/ksh
# ~~~~			FICHE SIGNALETIQUE SHELL

# set -x
# Nom des fichiers issus du shell
SHLLNAME=$(basename $0)
# Version du shell (a changer a chaque modif)
VERSION="$SHLLNAME v2.3 - pour Oracle 10g Release 2 sur Unix\n"
CARTOUCHE="
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ PROJET			: Oracle10g
# ~~~~ NOM DU PROGRAMME	        : DBA_rbld.sh
# ~~~~ Creation         	: 2007-10-18
# ~~~~ Version                  : $VERSION
# ~~~~ _________________________________________________________________________"
# ~~~~ HISTORIQUE
# ~~~~ Version---Date----------Auteur--------------Commentaires-----------------
# ~~~~   1.0    18/10/2007    C.Pivel       Reprise de l'existant
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ BUT DU PROGRAMME :
# ~~~~     Reconstruire tout ou partie des indexes d'un schema
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ FICHIERS DE PARAMETRES APPELES :
# ~~~~  Aucun
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ CODES RETOURS :
# ~~~~  - 0 : Fin normale du programme
# ~~~~  - 1 : Un ou plusieurs alertes sont remont�es sans incidence sur
# ~~~~        l'execution du programme.
# ~~~~  - 2 : Erreur sur les param�tres pass�s au script. Interruption.
# ~~~~  - 3 : Traitement en erreur.
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ PARAMETRES D'ENTREE : (nom du parametre - format - libelle)
# ~~~~ -U	char	utilisateur
# ~~~~ -P	char	Mot de passe
# ~~~~ [ -B ]	char	Oracle SID (base) � traiter
# ~~~~ [ -S ]	char	Schema � utiliser
# ~~~~ [ -T ]	char	Table(s) ou fichier contenant une liste de table
# ~~~~ [ -I ]	char	Index � traiter
# ~~~~ [ -V ]	bool	Affiche la version et quitte
# ~~~~ _________________________________________________________________________
# ~~~~

## Chargement de la bibliotheque Sybase
[[ -f ${W9NOUTIL}/liboracle && -r ${W9NOUTIL}/liboracle ]] && . ${W9NOUTIL}/liboracle

### Variables essentielles
# Identifiant date
IDDATE=$(date '+%Y%m%d%H%M%S')
# Nom des fichiers issus du shell
SHLLNAME=$(basename $0 .ksh)
# Code retour des traitements
RETCODE=""


# Suppression des fichiers temporaires si
# le script est interrompu par l'utilisateur (signaux 2 et 3)

trap '_log =====================================================;
_log !!!Programme interrompu en r�ponse � un signal INT, HUP ou TERM!!!;
echo 3 >> ${TMPRET} && exit' INT HUP TERM

trap 'retour;
_log "\nFin du traitement le $(date +%d/%m/%y) a $(date +%H:%M:%S) \n"
_log Suppression des fichiers temporaires et Fin du script; 
rm -f ${TMPFILE} ${TMPSQL} ${TMPRET} 2>/dev/null;
_log =====================================================;
_log Fichier traces disponibles sous $LOGFILE;
exit $RETCODE' EXIT QUIT

typeset LOGFILE=${TRACES}/${IDDATE}_$$.${SHLLNAME}.log
typeset TMPSQL=${TRAVAIL}/${SHLLNAME}_$$.sql
typeset TMPFILE=${TRAVAIL}/${SHLLNAME}_$$.tmp
typeset TMPRET=${TRAVAIL}/${SHLLNAME}_$$.ret
typeset TMPTABLE=${TRAVAIL}/${SHLLNAME}_$$.table
typeset TMPINDEX=${TRAVAIL}/${SHLLNAME}_$$.index
typeset LOGIN=""
# Initialisation du fichier
echo 0 > $TMPRET

exec 2>&1 # Redirection de la sortie d'erreur sur la sortie standard

####################################################################
#                                                                  #
#            FONCTIONS                                             #
####################################################################

###
#  Fonction de log charg�e de tout enregistrer dans un fichier
#  journal.
_log()
{
    echo -e "$*" | tee -a $LOGFILE
}

###
#  Fonction de log charg�e de tout enregistrer dans un fichier
#  journal.
_log_outfile()
{
    _log "Sortie de $* : \n $(cat ${TMPFILE})"
}

###
#  Fonction charg�e de retourner le bon code retour
#  suivant le contenu du fichier $TMPRET
retour ()
{
# Sortie du traitement et gestion du CR
# Calcul du nb d'erreurs
    typeset -i NBERR=$(grep -c '[^0]' ${TMPRET})
    
# Calcul du code retour max
    RETCODE=$(cat ${TMPRET} |sort -n -u |tail -1)
    [ ${RETCODE} -ge 3 ] && RETCODE=3
    _log " ${NBERR} Erreur(s) , code retour le plus haut : ${RETCODE}"
}

###
#  Fichier r�sultat et fichiers temporaires
[ -z "${TRACES}" ] && echo -e "La variable TRACES n'est pas positionn�e. Renseignez-l� et recommencez." && echo 3 >> ${TMPRET} && exit 3
[ ! -d "${TRACES}" ] && echo -e "La variable TRACES doit definir un repertoire existant." && echo 3 >> ${TMPRET} && exit 3
[ -z "${TRAVAIL}" ] && echo -e "La variable TRAVAIL n'est pas positionn�e. Renseignez-l� et recommencez." && echo 3 >> ${TMPRET} && exit 3
[ ! -d "${TRAVAIL}" ] && echo -e "La variable TRAVAIL doit definir un repertoire existant." && echo 3 >> ${TMPRET} && exit 3

###
# Usage du shell
###
# Usage du shell
usage ()
{
   [ "$1" ] && _log "\n$SHLLNAME: $*"

   cat <<EOF

   $VERSION

   usage:     $SHLLNAME [-U<utilisateur>] [-P<mot_de_passe>]
                        [ -B<oracle SID> ]
                        [ -S<Schema> ] [ -T<liste de tables ou fichier> ] 
                        [ -I<index> ] 
                        [ -h ] [-V]

   options:   -U <utilisateur>: Le nom de l'utilisateur qui poss�de des droits dba sur l'instance.
                                L'utilisateur doit OBLIGATOIREMENT d�tenir les droits (sys)dba.
	      
	      -P <mot de passe>: Mot de passe pour l'utilisateur pass� en argument.

              -S <Schema>     : Nom du sch�ma sur lequel travailler.
                                (D�faut: valeur du parametre -U).

              -T <tables> :     Liste de tables separees par des virgules ou fichier contenant
                                une ligne par table. Ce parametre peut etre vide.

              -I <index> :      Nom de l'index a traiter 
                               (vide pour traiter tous les indexes)

              -B <Oracle SID>  : Le SID Oracle a traiter.
                                (Defaut: $ORACLE_SID).

              -h              : Affiche ce message

              -V              : Affiche la version et quitte.

Exemple d'utilisation:
  
  $SHLLNAME -Usys -Psys -I
EOF

}

###
# Renvoie 0 si la tentative de connexion a reussie
test_connexion ()
{
    [[ $# -ne 2 ]] && _log "[$LINENO] test_connexion(): la fonction attend deux parametres" && \
	echo 3 >> ${TMPRET} && exit
    
    _log "Tentative de connexion a l'instance ${ORACLE_SID} en tant que $1/XXXXX..."
    TMPSTR="$1/$2"
    if [ "$1" = "sys" ]; then
	_log "Utilisation d'une connexion en tant que sysdba..."
	TMPSTR="${TMPSTR} as sysdba"
    fi
    
    sqlplus -S /NOLOG> $TMPFILE<<EOF
WHENEVER SQLERROR exit 3
connect $TMPSTR
exit
EOF

    if [[ $? -ne 0 ]]; then
	return 1
    else
	LOGIN=$TMPSTR
	_log "La connexion a l'instance en tant que $1 s'est bien effectuee"
	return 0
    fi
}

###
# Reconstruit l'index passe en parametre
Rebuild_Index()
{
    INDEXNAME=${1:-""} # Nom de l'index ou de la colonne si fourni sinon nul
    _log "$(date)"    
    if [[ -z ${INDEXNAME} ]]; then
	_log "Rebuild de tous les indexes de la table ${TABLENAME}"
    else
	_log "Rebuild de l'index ${INDEXNAME} de la table ${TABLENAME}"
    fi
    sqlplus -S /NOLOG >$TMPFILE << EOF
WHENEVER SQLERROR EXIT 3
connect $LOGIN
alter index $1 rebuild;
SHOW ERRORS;
EOF
      
    if [[ $? -ne 0 && `is_error` -eq 1 ]]
	then
	_log "Erreur lors de la reconstruction de l'index $INDEX."
	_log_outfile
	echo 3 >> $TMPRET
    else
	_log "Compilation realisee avec succes."
    fi
    _log "$(date)"    
}

###
#
#
is_error()
{
    if [ $(egrep -c 'ORA-14456|ORA-00701|ORA-14086' ${TMPFILE}) -ge 1 ]; then
	return 0
    else
	return 1
    fi
}

###
# Renvoie 0 si l'utilisateur pass� en parametre possede les droits DBA
# Necessite que la variable ${LOGIN} soit renseign�e.
is_dba ()
{
    [[ $# -ne 1 ]] && _log "[$LINENO] is_dba(): nombre d'arguments insuffisants." && echo 3 >>$TMPRET && exit

    sqlplus -S $LOGIN > $TMPFILE <<EOF
WHENEVER SQLERROR exit 3
set pagesize 0
set head off
set feed off
select 'X' from dba_role_privs
where grantee = upper('$USERNAME') and granted_role = 'DBA';
quit
EOF

       if [ $? -ne 0 ]
	    then
	    return 0
       elif [ ! -s $TMPFILE ]
	    then
	    return 0
       else
	    return 1
       fi
}


###
# Renvoie 0 si la table existe, 1 sinon
table_existe ()
{
    [[ $# -lt 1 ]] && \
	_log "[$LINENO] table_existe(): Il manque un parametre." && \
	echo 3 >> $TMPRET && exit
    
    sqlplus -S /NOLOG > $TMPFILE << EOF
  WHENEVER SQLERROR exit 3
  connect $LOGIN
  set head off
  set feed off
  select 'X' from dba_tables
  where table_name = upper('$TABLE')
  and OWNER = upper('$SCHEMA');
EOF

    if [ $? -ne 0 -o ! -s ${TMPFILE} ]; then
	return 1
    else
	return 0
    fi
}

###
# Renvoie 0 si l'index existe, 1 sinon
index_existe ()
{
    [[ $# -lt 1 ]] && \
	_log "[$LINENO] index_existe(): Il manque un parametre." && \
	echo 3 >> $TMPRET && exit

    sqlplus -S /NOLOG > $TMPFILE << EOF
WHENEVER SQLERROR exit 3
connect $LOGIN
set head off
set feed off
select 'X' from dba_indexes
where index_name = upper('$INDEX')
and OWNER = upper('$SCHEMA');
EOF

  if [ $? -ne 0 -o ! -s ${TMPFILE} ]
  then
      return 0
  else
      return 1
  fi
}
 
###
# Pr�pare la liste des indexs
liste_index ()   
{
    sqlplus -S /NOLOG > $TMPFILE << EOF
connect $LOGIN
set feed off;
set head off;
set linesize 100;
set pagesize 0;
set echo off;
select table_name||';'||owner||'.'||index_name
from dba_indexes
where owner=upper('$SCHEMA')
and index_type not in ('LOB', 'IOT - TOP');
EOF
    _log "La sortie se trouve dans ${TMPINDEX}"
    sed '1d' $TMPFILE > ${TMPINDEX}
}

## On cache le mot de passe pour �viter de le voir passer
## en clair dans les logs :)
_log "$CARTOUCHE"
ARGSS="$*"
ARGSS=$(echo -e $ARGSS | sed 's/-P.* /-P***** /')
while getopts :hVU:P:B:T:I:S: option 2>/dev/null
  do
  case ${option} in 
      B) SID=$OPTARG ;;
      U) USERNAME=$OPTARG ;;
      P) PASSWD=$OPTARG ;;
      S) SCHEMA=$OPTARG ;;
      T) TABLE=$OPTARG ;;
      I) INDEX=$OPTARG ;;
      V) trap '' EXIT QUIT
	  exit ;;
      h) usage
	  trap '' EXIT QUIT
	  exit ;;
      ?) 
	  if [[ -z ${INDEX} || -z ${TABLE} ]]
	      then
	      echo
	      else
	      _log "\n Un des parametres n'est pas reconnu ou vide ( -${OPTARG} )"
	      _log " Parametres de la commande : $0 $*"
	      usage
	      echo 2 >> ${TMPRET} && exit
	  fi
	  ;;
  esac
done
SID=${SID:-$ORACLE_SID}

#  Controle des parametres 
[[ -z ${PASSWD} ]] && _log "Le mot de passe (-P) est un parametre obligatoire" && echo 2 >>$TMPRET && exit
[[ -z ${USERNAME} ]] && _log "Le login (-U) est un parametre obligatoire" && echo 2 >>$TMPRET && exit
[[ -z ${SID} ]] && _log "Le parametre SID (-B) doit etre definie si ORACLE_SID ne l'est pas" && echo 2 >>$TMPRET && exit


# Test du USERID
if test_connexion ${USERNAME} ${PASSWD}
    then
    _log ""
    else
    _log "Probleme lors de la tentative de connexion a l'instance"
    echo 3 >> ${TMPRET} && exit
fi
_log "Le couple login/mdp vaut ${LOGIN}"

_log "Verification que l'utilisateur ${USERNAME} possede les droits DBA..."
if [[ ${USERNAME} != "sys" ]]; then
    is_dba ${USERNAME} 
    if [ $? -eq 1 ]
	then
	_log "L'utilisateur ${USERNAME} a suffisamment de droits."
    else
	_log "[Ligne $LINENO]: L'utilisateur $USERNAME n'a pas les droits suffisants." && \
	    echo 3 >> $TMPRET && exit
    fi
else
    _log "Pas de v�rification sur les droits de ${USERNAME} car il est sysdba"
fi

## On affecte la valeur de schema
SCHEMA=${SCHEMA:-$USERNAME}

if [ -n "$TABLE" -a -n "$INDEX" ]
    then
    _log "Les parametres T et I sont exclusifs."
    echo 2 >> $TMPRET && exit
elif [ -n "$TABLE" ]; then
###
# On teste la validit� du param�tre TABLE et INDEX
    TABP=0
    _log "Analyse du parametre TABLE"
    if [[ -f $TABLE ]]; then
	_log "Le param�tre $TABLE designe un fichier"
    elif [[ -n $TABLE ]]; then
	_log "Le param�tre designe une table ou une liste de tables"
	TABP=1
    fi
fi


###################################### SCRIPT PRINCIPAL ##################################
#set -x
_log "Generation de la liste des indexes pour le schema $SCHEMA..."
liste_index

_log "Boucle principale..."
T=""
if [[ -n ${TABLE} && $TABP -eq 1 ]]; then
    T="$(echo -e ${TABLE} | tr -s ',' ' ')"
elif [[ -n ${TABLE} && $TABP -eq 0 ]]; then
    T=$(cat ${TABLE})
fi
    
if [[ -n ${T} ]]; then
    for TABLE1 in $T
      do   
      _log "\n|====>    TRAITEMENT DE LA TABLE  ** \"${TABLE1}\" **    <====|\n"
      
    # On test que la table n'est pas une table Oracle et/ou une table
    # inexistante
      _log "V�rifions que la table existe"
      table_existe ${TABLE1}
      case $? in
	  0) 
	      _log "La table ${TABLE1} existe et est une table SYBASE\n"
	      for i in `awk -F';' -vtest=$TABLE1  '$1 == test {print $2 }' ${TMPINDEX}`
		do
		_log "Construction de l'index $i"
		Rebuild_Index $i
	      done
	      ;;
	  1) 
	      _log "La table ${TABLE1} n existe pas." 
	      echo 1 >> $TMPRET
	      ;;
	  *) ;;
      esac
      _log "\n|==>    FIN DE TRAITEMENT DE LA TABLE  ** \"${TABLE1}\" **    <==|"
    done
elif [[ -n ${INDEX} ]]; then
    _log "L'index existe ... ?"
    for i in `awk -F'.' -vtest=$INDEX  '$2 == test {print $1"."$2 }' ${TMPINDEX}`
      do
      i=$(echo -e $i | cut -d';' -f2-)
      _log "OUI"
      _log "\n|====>    TRAITEMENT DE L'INDEX  ** \"${i}\" **    <====|\n"
      Rebuild_Index $i
      _log "\n|==>    FIN DE TRAITEMENT DE L'INDEX  ** \"${i}\" **    <==|"
    done
else
    _log "Rebuild de tous les indexes sur toutes les tables"
    for ligne in $(cat ${TMPINDEX})
      do
      _INDEX=$(echo -e $ligne | awk -F';' '{print $2}')
      _log "\n|====>    TRAITEMENT DE L'INDEX  ** \"${_INDEX}\" **    <====|\n"
      Rebuild_Index ${_INDEX}
      _log "\n|==>    FIN DE TRAITEMENT DE L'INDEX  ** \"${_INDEX}\" **    <==|"
    done
fi

_log "\n            FIN DU REBUILD\n    ----------------------------"
_log "  Machine : $(hostname) , date : $(date '+%d/%m/%Y a %H:%M:%S')"
_log "======================================================================="
_log "======================================================================="

cat <<EOF >$TMPFILE
\n\n-----------------------------------------
# ~~~~**** Resume du lancement: ****
-----------------------------------------
# ~~~~Arguments pass�s au script :
# ~~~~ ----+ $ARGSS +----
# ~~~~Fichiers temporaires: ...........
# ~~~~ ----+ SQL:          ....... $TMPSQL
# ~~~~ ----+ Code retour : ....... $TMPRET
# ~~~~ ----+ Temp:         ....... $TMPFILE
# ~~~~Variables ENV: ..........
# ~~~~ ----+ TRACES:       ....... $TRACES
# ~~~~ ----+ ORACLE_SID:   ....... $ORACLE_SID
# ~~~~ _________________________________________________________________________\n
EOF
_log "$(cat $TMPFILE)"

exit
### DBA_rbld.sh ends here

## Local variables:
## folded-file: t
## fold-internal-margins: nil
## mode: shell-script
## time-stamp-line-limit: 0
## time-stamp-start: "Derni�re Modification[\t]+:[ \t]+\\\\?[\"<]+"
## end:
