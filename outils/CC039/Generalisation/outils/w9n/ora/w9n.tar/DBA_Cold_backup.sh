#!/bin/ksh
# ~~~~			FICHE SIGNALETIQUE SHELL
# Nom des fichiers issus du shell
SHLLNAME=$(basename $0)
# Version du shell (a changer a chaque modif)
VERSION="$SHLLNAME v1.0 - pour Oracle 10g sur Linux\n"
CARTOUCHE="
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ PROJET			: Oracle10g
# ~~~~ NOM DU PROGRAMME	        : $SHLLNAME
# ~~~~ Version                  : $VERSION
# ~~~~ _________________________________________________________________________"
# ~~~~ HISTORIQUE
# ~~~~ Version---Date----------Auteur--------------Commentaires-----------------
# ~~~~   1.0    07/02/2009   C.Pivel       Creation
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ BUT DU PROGRAMME :
# ~~~~     Effectuer une sauvegarde a froid d'une instance avec RMAN
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ FICHIERS DE PARAMETRES APPELES :
# ~~~~  Aucun
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ CODES RETOURS :
# ~~~~  - 0 : Fin normale du programme
# ~~~~  - 1 : Un ou plusieurs alertes sont remontees sans incidence sur
# ~~~~        l'execution du programme.
# ~~~~  - 2 : Erreur sur les parametres passes au script. Interruption.
# ~~~~  - 3 : Traitement en erreur.
# ~~~~ _________________________________________________________________________
# ~~~~
# ~~~~ PARAMETRES D'ENTREE : (nom du parametre - format - libelle)
# ~~~~ -d	char	repertoire de sauvegarde
# ~~~~ [ -B ]	char	Oracle SID (base) a sauvegarder
# ~~~~ [ -l ]	num 	niveau de sauvegarde (0,1 ou 2)
# ~~~~ [ -V ]	bool	Affiche la version et quitte
# ~~~~ _________________________________________________________________________
# ~~~~

### Variables essentielles
# Identifiant date
IDDATE=$(date '+%y%m%d%H%M%S')
# Code retour des traitements
RETCODE=0
DF_CMD=""
SID=$ORACLE_SID
BKP_LEVEL=0
typeset -i TAILLE=0
typeset -i taille=0
FIC_SORTI=""
LOGIN="/ as sysdba"

# Fichiers temporaires
TMPFILE=/tmp/${SHLLNAME}_$$.tmp
RMAN_INPUT=/tmp/rman_input$$
RMAN_OUTPUT=/tmp/rman_output$$

###
# Verification en amont
[ -z "${TRACES}" ] && echo -e "La variable TRACES n'est pas positionnee. Renseignez-la et recommencez." && exit 3
LOGFILE=${TRACES}/${IDDATE}.${SHLLNAME}.log

###
# Fonction de logging
verbose ()
{
    echo -e "$*" | tee -a $LOGFILE
}

###
# Sortie du traitement et gestion du CR
code_retour ()
{
    CODE=$1 ; shift
    
    RAISON=$*

    case $CODE in
	0)
            verbose "[SUCCES]: =>> $RAISON"
	   ;;
	1)
	    verbose "!!ATTENTION!! : =>> $RAISON"
	    ;;
	2|3)
	    verbose "/!\ ERREUR CR${CODE} /!\ \n[ERREUR]: =>> $RAISON"
	    verbose "\t\t*** Arret du programme ***\n"
	    exit $CODE
	    ;;
	*)
	    verbose "Code retour en dehors du rang [0-3]. Verifiez le code.\n"\
		"# ~~~~ -=-=-=-=-=-= Fin du script $SHLLNAME. Code retour: 3 =-=-=--=-=-=" 
	    exit $CODE
	    ;;
    esac
}

#____________________________________________________________________________#
# Fonction pour tester la plate-forme                                        #
#____________________________________________________________________________#
Machine=$(uname)
case ${Machine} in
        SunOS)
                DF_CMD="df -k"
                verbose " * * * Environnement SUN * * *\n"
                CPUS=`/usr/bin/mpstat|grep -v CPU|wc -l`
                ;;
        Linux)
                DF_CMD="df -k"
                verbose " * * * Environnement Linux * * *\n"
                CPUS=`/usr/bin/mpstat -P ALL|awk '{print $2}'|tail -1`
                ;;
        HP-UX)
                DF_CMD="bdf"
                verbose " * * * Environnement Hewlett-Packard * * *\n"
                CPUS=`/usr/sbin/ioscan -fnkC processor|grep PROCESSOR|wc -l`
                ;;
esac
###
# Usage du shell
usage ()
{
   [ "$1" ] && verbose "\n$SHLLNAME: $*"

   cat <<EOF

   $VERSION

   usage:     $SHLLNAME -d directory [ -B<oracle SID> ] [ -l<backup level>] [-o<fichier>] [V]

   options:   -d <repertoire> : Nom du repertoire de sauvegarde.

              -B <Oracle SID>  : Le SID Oracle a sauvegarder. 
                                (Defaut: $ORACLE_SID).

              -l <niveau de sauvegarde>    : 0 -> full backup(defaut)  1,2 -> backup incremental

              -V              : Affiche la version et quitte.

Exemple d'utilisation:
  
  $SHLLNAME -d\$HOME/dump 
EOF
}

###
# Affectation des arguments
ARGSS="$*"
while getopts d:B:l:Vh OPT
do
     case $OPT in
         "d" ) REPDEST=$OPTARG ;;
         "B" ) SID=$OPTARG ;;
         "l" ) BKP_LEVEL=$OPTARG ;;
	 "V" ) echo -e $VERSION && exit 0 ;;
	 "h" ) usage && exit 0 ;;
         "?" ) usage && code_retour 2 "Option non valide: -$OPTARG";;
         ":" ) usage && code_retour 2 "Parametre obligatoire non fourni pour l'option -$OPTARG";;
     esac
done

###
# Moyen simple de deboguer le script
DEBUG=${DEBUG:=0}
DEBUG_=""
if [[ ${DEBUG} -gt 0 ]]; then
    echo -e "Mode DEBUG active. Mise en place des traps."
    set -x
    trap 'verbose "DEBUG: Ligne $LINENO"' DEBUG
    trap 'verbose "ERREUR LIGNE: $LINENO" ' ERR
    DEBUG_=echo -e
fi

###
# Affichage du cartouche
verbose "$CARTOUCHE \n"\
"# ~~~~**** Resume du lancement: ****\n"\
"# ~~~~Arguments passes au script :\n"\
"# ~~~~ ----+ $ARGSS +----\n"\
"# ~~~~Fichiers temporaires: ...........\n"\
"# ~~~~ ----+ Temp:         ....... $TMPFILE\n"\
"# ~~~~Variables ENV: ..........\n"\
"# ~~~~ ----+ TRACES:       ....... $TRACES\n"\
"# ~~~~ ----+ ORACLE_SID:   ....... $SID\n"\
"# ~~~~Fichier resultat a consulter:\n"\
"# ~~~~ ----+ $LOGFILE\n"\
"# ~~~~ _________________________________________________________________________\n"

### 
# Verification des arguments    
[ -z "${SID}" ] && usage && code_retour 2 "Aucun Oracle SID specifie ou Oracle SID non valide (option -B). Arret du programme."
[ -z "${REPDEST}" ] && usage && code_retour 2 "Repertoire de sauvegarde non specifie (option -d). Arret du programme."
if [ "${BKP_LEVEL}" -ne 0 -a "${BKP_LEVEL}" -ne 1 -a "${BKP_LEVEL}" -ne 2 ];then
 code_retour 2 "niveau de backup different de 0,1 ou 2 . Arret du programme."
fi

###
# Verification de la disponibilite du repertoire de sauvegarde
# Creation si necessaire
if [ ! -d ${REPDEST} ] 
then mkdir -p ${REPDEST}
     code_retour $? "creation de ${REPDEST} car il n'existait pas"
     chmod 777 ${REPDEST}
     code_retour $? "positionnement des droits 777 sur ${REPDEST}"
else verbose "le repertoire ${REPDEST} existe deja" 
fi	

#####
# Test de l'etat de l'instance: 
#####
db_status=`sqlplus -s "$LOGIN" <<EOF 
set heading off 
set feedback off 
set verify off 
select status from v\\$instance; 
exit 
EOF 
` 

code_retour $? "recherche du statut de l'instance"

if [ $db_status = "MOUNTED" -o $db_status = "OPEN" ]; then 
verbose "la base est ouverte: on peut continuer"
else code_retour 3 "la base n'etant pas ouverte ou montee, on ne peut interroger les tables systeme"
fi

# 
# Get the archivelog-mode of the database 
# 
archive_log=`sqlplus -s "$LOGIN" <<EOF 
set heading off 
set feedback off 
set verify off 
select log_mode from v\\$database; 
exit 
EOF 
` 

code_retour $? "requete de recherche du mode d'archivage de la base"

if [ $archive_log = "NOARCHIVELOG" ]; then 
	verbose "la base est en mode NOARCHIVELOG"
	BACKUP_WHAT="database;"
	ARCH_MAINT=""
fi
if [ $archive_log = "ARCHIVELOG" ]; then 
	verbose "la base est en mode ARCHIVELOG"
	BACKUP_WHAT="database plus archivelog delete all input;"
	ARCH_MAINT="crosscheck archivelog all;"
fi

ALC_CHNL="allocate channel d1 device type disk;"
RLS_CHNL="release channel d1;"
if [ "$CPUS" -gt 1 ];then
	ALC_CHNL=${ALC_CHNL}"\nallocate channel d2 device type disk;"
	RLS_CHNL=${RLS_CHNL}"\nrelease channel d2;"
fi
if [ "$CPUS" -gt 2 ];then
	ALC_CHNL=${ALC_CHNL}"\nallocate channel d3 device type disk;"
	RLS_CHNL=${RLS_CHNL}"\nrelease channel d3;"
fi
    
###
# sauvegarde des fichiers oracle
###
ORAPW=$(ls -rtl $ORACLE_HOME/dbs/orapw${SID})
if [ $? -ne 0 ]
then code_retour 1 "le fichier $ORACLE_HOME/dbs/orapw${SID} n'a pas ete trouve mais on continue quand meme"
else code_retour 0 "recherche de orapw${SID}"
fi

cp $ORACLE_HOME/dbs/orapw${SID} $REPDEST

PFILE=$(ls -rtl $ORACLE_HOME/dbs/init${SID}.ora)
if [ $? -ne 0 ]
then code_retour 1 "le fichier $ORACLE_HOME/dbs/init${SID}.ora n'a pas ete trouve mais on continue quand meme"
else code_retour 0 "recherche de init${SID}.ora"
fi

cp $ORACLE_HOME/dbs/init${SID}.ora $REPDEST
     
TNSNAMES=$(ls -rtl ${TNS_ADMIN}/tnsnames.ora)
if [ $? -ne 0 ]
then code_retour 1 "le fichier ${TNS_ADMIN}/tnsnames.ora n'a pas ete trouve mais on continue quand meme"
else code_retour 0 "recherche de ${TNS_ADMIN}/tnsnames.ora"
fi

cp ${TNS_ADMIN}/tnsnames.ora $REPDEST

LISTENER=$(ls -rtl ${TNS_ADMIN}/listener.ora)
if [ $? -ne 0 ]
then code_retour 1 "le fichier ${TNS_ADMIN}/listener.ora n'a pas ete trouve mais on continue quand meme"
else code_retour 0 "recherche de ${TNS_ADMIN}/listener.ora"
fi

cp ${TNS_ADMIN}/listener.ora $REPDEST


###
# espace libre sur le repertoire de sauvegarde
###

DISPO=`$DF_CMD $REPDEST | sed '1d' | awk '{print $4}'`

verbose "l'espace disponible sur le repertoire $REPDEST est $DISPO KB"

###
# switch des redo logs

sqlplus -S "$LOGIN" <<EOF

set linesize 600
set pause off
set pagesize 0
set echo on
set feedback off
whenever sqlerror exit 3
alter system switch logfile;
EOF

code_retour $? "switch des redo logs"

###
# sauvegarde a froid 
###
verbose `date` "debut sauvegarde a froid"
echo -e "delete noprompt obsolete;" >$RMAN_INPUT
echo -e "shutdown immediate;" >>$RMAN_INPUT
echo -e "startup mount;" >>$RMAN_INPUT
echo -e "run {" >>$RMAN_INPUT
echo -e "${ALC_CHNL}" >>$RMAN_INPUT
echo -e "backup incremental level ${BKP_LEVEL}" >>$RMAN_INPUT
echo -e "format '${REPDEST}/%d_inc${BKP_LEVEL}_%T_%U.bak'" >>$RMAN_INPUT
echo -e "check logical" >>$RMAN_INPUT
echo -e "${BACKUP_WHAT}" >>$RMAN_INPUT
echo -e "backup current controlfile tag=inc${BKP_LEVEL}" >>$RMAN_INPUT
echo -e "format '${REPDEST}/cf_inc${BKP_LEVEL}_%T_%U.ctl';" >>$RMAN_INPUT
echo -e "backup spfile tag=inc${BKP_LEVEL}" >>$RMAN_INPUT
echo -e "format '${REPDEST}/sp_inc${BKP_LEVEL}_%T_%U.ctl';" >>$RMAN_INPUT
echo -e "${RLS_CHNL}" >>$RMAN_INPUT
echo -e "}" >>$RMAN_INPUT
echo -e "sql 'alter database backup controlfile to trace';" >>$RMAN_INPUT
echo -e "sql" "\"alter database backup controlfile to trace as ''$REPDEST/controlfile_trace${dbid}'' reuse\";" >>$RMAN_INPUT
echo -e "alter database open;" >>$RMAN_INPUT
echo -e "crosscheck backup;" >>$RMAN_INPUT
echo -e "${ARCH_MAINT}" >>$RMAN_INPUT
echo -e "list backup of database;" >>$RMAN_INPUT
echo -e "report unrecoverable;" >>$RMAN_INPUT
echo -e "report schema;" >>$RMAN_INPUT
echo -e "report need backup;" >>$RMAN_INPUT
echo -e "report obsolete;" >>$RMAN_INPUT
echo -e "delete noprompt expired backup of database;" >>$RMAN_INPUT
echo -e "delete noprompt expired backup of controlfile;" >>$RMAN_INPUT
echo -e "delete noprompt expired copy;" >>$RMAN_INPUT
echo -e "quit" >>$RMAN_INPUT
${ORACLE_HOME}/bin/rman target / cmdfile=${RMAN_INPUT} log=${RMAN_OUTPUT}
verbose `date` "fin sauvegarde a froid"
#
#
cat ${RMAN_OUTPUT} >>$LOGFILE
grep "RMAN-00569" ${RMAN_OUTPUT}
if [ "$?" -eq 0 ];then
	# on teste si la base est demarree; on la relance sinon
	db_status=`sqlplus -s "$LOGIN" <<EOF 
	set heading off 
	set feedback off 
	set verify off 
	select status from v\\$instance; 
	exit 
	EOF 
	` 
	if [ $db_status = "MOUNTED" ]; then 
		verbose "sauvegarde en erreur : relance de l instance "
		echo "alter database open;"|sqlplus / as sysdba
	fi
	code_retour 3 "sauvegarde en erreur : verifier le contenu de $LOGFILE"
fi

sqlplus -S "$LOGIN" >${TMPFILE} <<EOF
WHENEVER SQLERROR exit 3
  set head off
  set feed off
  select 'X' from v\$database_block_corruption;
EOF

if [ $? -ne 0 -o -s ${TMPFILE} ]; then
        code_retour 3 "presence de blocs corrompus : verifier la vue v\$database_block_corruption"
fi


rm -f $TMPFILE $RMAN_INPUT $RMAN_OUTPUT
code_retour 0 "sauvegarde effectuee"
