#!/bin/ksh
##########################################################################################
# DBA_expdp                                                                              |
#                                                                                        |
# Appel de l'utilitaire export datapump                                                  |
#                                                                                        |
# Description:                                                                           |
# Permet d'exporter un schema dont le nom est passe en parametre (-U)                    |
# Permet d'exporter une table particuliere de ce schema en precisant le parametre -T     |
# La variable d'environnement NLS_LANG est positionnie pour etre conforme au jeu         |
# de caracteres de la base de donnees                                                    |
#                                                                                        |
#                                                                                        |
# Tables utilisees:                                                                      |
#     USER_ROLE_PRIVS                                                                    |
#     USER_TABLE                                                                         |
#     V$NLS_PARAMETERS                                                                   |
#                                                                                        |
# Fichiers:                                                                              |
#     YYMMDDHHMISS.DBA_exp.log       Fichier de trace                                    |
#     user.tmp                       Fichier de travail                                  |
#     objet.tmp                      Fichier de travail                                  |
#     nls_lang.tmp                   Fichier de travail                                  |
#                                                                                        |
# Variables d'environnement:                                                             |
#     ORACLE_SID                      Base par defaut                                    |
#     TRACES                          Repertoire des fichiers de trace                   |
#     TRAVAIL                         Repertoire des fichiers de travail                 |
#                                                                                        |
# Retour :                                                                               |
#     0 : traitement sans erreur                                                         |
#     2 : erreur sur les parametres                                                      |
#     3 : erreur bloquante lors du traitement                                            |
#                                                                                        |
# Modifications:                                                                         |
# 10/04/2011: DTP/CC SGBD creation                                                       |
##########################################################################################

# set -x

#-----------------------------------------------------------------------------------------
# Lecture des parametres
#-----------------------------------------------------------------------------------------
DATE_HEURE=`date +%y%m%d%H%M%S`
LOGIN="/ as sysdba"
typeset USERNAME=""
typeset PASSWD=""
typeset FILENAME=""
typeset TABLE=""
typeset DIRECTORY="DATA_PUMP_DIR"
default_directory=1
for i
do
case "$i" in
 -U*) USERNAME=`echo $i |cut -c 3-`;;
 -P*) PASSWD=`echo $i | cut -c 3-`;;
 -T*) TABLE=`echo $i |cut -c 3-`;;
 -D*) DIRECTORY=`echo $i | cut -c 3-`
      default_directory=0;;
 -F*) FILENAME=`echo $i | cut -c 3-`;;
 -V*) echo "`basename $0` - Version 1.0\n"
      exit 0;;
 -h*) echo "Usage: `basename $0` -U{user} -P{password} [-D{directory}] [-T(table)] [-F{fichier}] [-V|-h]"
      echo "       -U\tUsername"
      echo "       -P\tPassword"
      echo "       -D\tDirectory"
      echo "       -T\tTable"
      echo "       -F\tFichier"
      echo "       -V\tAffiche la version"
      echo "       -h\tAffiche de l'aide"
      exit 0;;
esac
done

#-----------------------------------------------------------------------------------------
#  Controle des parametres
#-----------------------------------------------------------------------------------------

integer n=0
if [ -z "$TRACES" ]
then
    echo '!!! La variable d environnement $TRACES doit etre definie.' >&2
    exit 2
fi
if [ ! -d $TRACES ]
then
  echo "!!! Le repertoire de trace $TRACES n'est pas valide" >&2
  exit 2
else
  FICHIER_TRACE=$TRACES/$DATE_HEURE.`basename $0`.log
  echo "Ouverture du fichier trace : "`date +%y%m%d%H%M%S` >>$FICHIER_TRACE
  echo "-----------------------------------------">>$FICHIER_TRACE
fi

if [ -z "$PASSWD" -o -z "$USERNAME" ]
then
  echo "!!! Le nom de l'utilisateur et son mot de passe sont des parametres obligatoires.">>$FICHIER_TRACE
  exit 2
fi

if [ -z "$ORACLE_SID" ]
  then
    echo '!!! La variable d environnement $ORACLE_SID doit etre definie.'>>$FICHIER_TRACE
    exit 2
fi
# controle existence du nom de schema
sqlplus -S $USERNAME/$PASSWD > $TRACES/user.tmp << FIN
WHENEVER SQLERROR exit 2
exit
FIN
if [ $? -ne 0 ]
then
  echo "!!! L'utilisateur ou le mot de passe est incorrect.">>$FICHIER_TRACE
  rm -f $TRACES/user.tmp
  exit 2
fi
rm -f $TRACES/user.tmp
# controle existence du nom de directory
sqlplus -S "$LOGIN" > $TRACES/directory.tmp << FIN
SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE
VARIABLE NUM NUMBER;
BEGIN
    BEGIN
        SELECT COUNT(*) INTO :NUM FROM ALL_DIRECTORIES WHERE DIRECTORY_NAME=UPPER('$DIRECTORY');
    END;
END;
/
EXIT :NUM
FIN
if [ $? -ne 1 ];then
    echo "Erreur lors du controle de l'existence de la directory $DIRECTORY" >>$FICHIER_TRACE
    rm -f $TRACES/directory.tmp
    exit 2
fi
rm -f $TRACES/directory.tmp
#
if [ -z "$TRAVAIL" ]
then
  if [ -z "$TEMP" ]
  then
    echo '!!! La variable d environnement $TRAVAIL doit jtre difinie.' >>$FICHIER_TRACE
    exit 2
  else
    TRAVAIL=$TEMP
    echo 'La variable d environnement $TRAVAIL n est pas definie, la variable $TEMP est utilisee.' >>$FICHIER_TRACE
  fi
fi
if [ ! -d $TRAVAIL ]
then
  echo "!!! Le repertoire de travail $TRAVAIL n'est pas valide" >>$FICHIER_TRACE
  exit 2
fi

touch $TRAVAIL/essai_ecriture
if [ $? -eq 0 ]
then echo "on a bien les droits d'ecriture sur le repertoire $TRAVAIL" >>$FICHIER_TRACE
     rm $TRAVAIL/essai_ecriture
else echo "!!! verifier les droits d'ecriture sur le repertoire $TRAVAIL" >>$FICHIER_TRACE
     exit 2
fi

if [ -n "$FILENAME" ];then
        FILENAME=${FILENAME}.exp
else
	if [ -z "$TABLE" ];then
        	FILENAME=${USERNAME}.exp
	else
		FILENAME=${TABLE}"."${USERNAME}".exp"
	fi
fi
	

###################################### CONTEXTE ##################################
echo "Parametres d'execution :">>$FICHIER_TRACE
echo "-U $USERNAME">>$FICHIER_TRACE
echo "-P PASSWD">>$FICHIER_TRACE
echo "-D $DIRECTORY">>$FICHIER_TRACE
echo "-F $FILENAME">>$FICHIER_TRACE
if [ -z "$TABLE" ];then
        SCHEMAS="SCHEMAS="${USERNAME}
else
        echo "-T $TABLE">>$FICHIER_TRACE
        TABLE="TABLES="${USERNAME}"."${TABLE}
        SCHEMAS=""
fi
echo '$ORACLE_SID='"$ORACLE_SID">>$FICHIER_TRACE
echo '$TRACES='"$TRACES">>$FICHIER_TRACE
echo '$TRAVAIL='"$TRAVAIL">>$FICHIER_TRACE
echo "-----------------------------------------">>$FICHIER_TRACE

###################################### SCRIPT PRINCIPAL ##################################
#-----------------------------------------------------------------------------------------
# Lancement de la commande
#-----------------------------------------------------------------------------------------
# construction du NLS_LANG
echo "Recherche des parametres NLS de la base de donnees">>$FICHIER_TRACE
sqlplus -S $USERNAME/$PASSWD > $TRAVAIL/nls_lang.tmp << FIN
WHENEVER SQLERROR EXIT 3
set pagesize 0
set head off
set feed off
select value from v\$nls_parameters
where parameter='NLS_LANGUAGE';
select value from v\$nls_parameters
where parameter='NLS_TERRITORY';
select value from v\$nls_parameters
where parameter='NLS_CHARACTERSET';
FIN
if [ $? -ne 0 -o ! -s $TRAVAIL/nls_lang.tmp ]
then
  echo "!!! Erreur lors de la recherche des parametres NLS">>$FICHIER_TRACE
  rm -f $TRAVAIL/nls_lang.tmp
  exit 3
fi
integer i=0
for LIGNE in `cat $TRAVAIL/nls_lang.tmp`
do
   let i=i+1
   if [ i -eq 1 ]
   then
     NLS_LANG=$LIGNE
   elif [ i -eq 2 ]
   then
     NLS_LANG=${NLS_LANG}_$LIGNE
   elif [ i -eq 3 ]
   then
     NLS_LANG=${NLS_LANG}.$LIGNE
   fi
done
echo 'La variable $NLS_LANG a pour valeur: '$NLS_LANG>>$FICHIER_TRACE
export NLS_LANG
echo "Appel de l'utilitaire expdp">>$FICHIER_TRACE
echo "expdp '/ as sysdba' ${SCHEMAS} DUMPFILE=${FILENAME} DIRECTORY=${DIRECTORY} ${TABLE} " >>$FICHIER_TRACE

expdp \'/ as sysdba\' ${SCHEMAS} DUMPFILE=${FILENAME} DIRECTORY=${DIRECTORY} ${TABLE} 1>>$FICHIER_TRACE 2>&1
RET_VAL=$?
if [ ${RET_VAL} -ne 0 -o $(grep -c "ORA-" $FICHIER_TRACE) -gt 0 ]
then
     echo "!!! Erreur lors de l'execution expdp">>$FICHIER_TRACE
     rm -f $TRAVAIL/nls_lang.tmp
     exit 3
fi

echo "-----------------------------------------">>$FICHIER_TRACE
echo "Fin du traitement: "`date +%y%m%d%H%M%S` >>$FICHIER_TRACE
rm -f $TRAVAIL/nls_lang.tmp

echo "Fermeture du fichier trace : "`date +%y%m%d%H%M%S` >>$FICHIER_TRACE
exit 0
