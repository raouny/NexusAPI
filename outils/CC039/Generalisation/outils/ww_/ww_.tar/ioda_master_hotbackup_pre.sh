#!/bin/bash
#*********************************************************************/
#**  Nom        : ioda_master_hotbackup_pre.sh
#**  Descript.  : Sauvegarde a chaud du Master Centreon - script de preactions
#**
#**  Changelog  : G.MICHON - 26/01/2011 - 1.0 - Creation initiale
#**
#*********************************************************************/
VERSION="1.0"

export PATH="$PATH:/sbin"


# Entete
header() {
    echo "***************************************************************"
    echo "Sauvegarde a chaud du Master Centreon - script de preactions"
    echo "$0"
    echo "Cible : SLES 10 SP2, plateforme IODA, serveur Master"
    echo
    echo "Description : Realise un snapshot LVM de $IODA_BACKUPED_LV"
    echo
    echo "Version $VERSION"
    echo "***************************************************************"
    echo 
}

# Fin d'execution
footer() {
    echo
    echo "***************************************************************"
    echo "Fin d'execution : OK - snapshot realise"
    echo "***************************************************************"
}


# Verification de l'espace disponible sur un VG
# Utilisation : check_vg_free_space <vg> <taille min en Gio>
check_vg_free_space() {
    vg=$1
    min_space=$2

    if vgs /dev/$vg >/dev/null 2>&1 ; then
        true
    else
        echo "ERROR: Le VG $vg n'existe pas"
        exit 3
    fi
    
    echo "Verification de l'espace disponible sur le VG $vg..."
    free_space=$(vgs --units G --noheadings /dev/$vg | sed 's/G$//' | awk '{print $7}' | sed 's/\.[0-9]*$//' | sed 's/,[0-9]*$//' )
    if [ $min_space -gt $free_space ] ; then
        echo "ERROR: Espace manquant sur le VG $vg ($free_space Gio). Requis : $min_space Gio"
        exit 3
    else
        echo "Espace disque sur le VG $vg : $free_space Gio > $min_space Gio"
    fi
}


# Creation d'un LV de type snapshot et montage dans l'arborescence
# Utilisation : create_lv_snapshot <VG> <LV> <LV Snapshot> <taille en Gio> <point de montage>
create_lv_snapshot() {
    vg=$1
    lv=$2
    lv_snapshot=$3
    lv_size=$4
    mount_point=$5

    echo "Creation du LV $lv_snapshot (snapshot de $lv sur $vg) et montage sur $mount_point..."

    # Verifications prealables
    check_vg_free_space $vg $lv_size
    if lvs /dev/$vg/$lv_snapshot >/dev/null 2>&1 ; then
        echo "ERROR: Le LV $lv_snapshot existe deja sur $vg"
        exit 3
    fi
    if [ ! -d $mount_point ] ; then
        echo "ERROR: Le point de montage $mount_point n'existe pas"
        exit 3
    fi
    
    # Creation et montage
    lvcreate -s -n $lv_snapshot -L ${lv_size}G /dev/$vg/$lv
    if [ $? -ne 0 ] ; then
        echo "ERROR: Impossible de faire un snapshot de /dev/$vg/$lv"
        exit 3
    fi
    mount /dev/$vg/$lv_snapshot $mount_point
    if [ $? -ne 0 ] ; then
        echo "ERROR: Impossible de monter /dev/$vg/$lv_snapshot sur $mount_point"
        delete_lv_snapshot $vg $lv_snapshot
        exit 3
    fi
}


# Suppression d'un LV de type snapshot en le demontant au prealable
# Utilisation : delete_lv_snapshot <VG> <LV> [<point de montage>]
delete_lv_snapshot() {
    lv=/dev/$1/$2
    mount_point=$3

    echo "Suppression du snapshot $lv..."

    # Verification : ne fonctionne que sur un snapshot
    if lvs $lv >/dev/null 2>&1 ; then
        if [ "$(lvs --noheadings $lv | awk '{print $5}')" = "" ] ; then
            echo "ERROR: $lv n'est pas un snapshot LVM"
            exit 3
        fi
    else
        echo "ERROR: $lv n'existe pas"
        exit 3
    fi

    # Demontage et suppression
    if [ "$mount_point" != "" ] ; then
        umount $mount_point
        if [ $? -ne 0 ] ; then
            echo "ERROR: Impossible de demonter $mount_point"
            exit 3
        fi
    fi

    lvremove -f $lv
    if [ $? -ne 0 ] ; then
        echo "ERROR: Impossible de supprimer le LV $lv"
        exit 3
    fi
}


if [ "$IODA_VG" = "" -o "$IODA_BACKUPED_LV" = "" -o "$IODA_SNAPSHOT_LV" = "" -o "$IODA_SNAPSHOT_SIZE" = "" -o "$IODA_SNAPSHOT_MOUNTPOINT" = "" ] ; then
    echo "ERROR: Importer /ioda/admin/etc/current/ioda.env avant lancement"
    exit 3
fi


header
create_lv_snapshot $IODA_VG $IODA_BACKUPED_LV $IODA_SNAPSHOT_LV $IODA_SNAPSHOT_SIZE $IODA_SNAPSHOT_MOUNTPOINT
footer
exit 0


