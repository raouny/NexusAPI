#!/bin/bash
#*********************************************************************/
#**  Nom        : ioda_master_hotbackup_post.sh
#**  Descript.  : Sauvegarde a chaud du Master Centreon - script de postactions
#**
#**  Changelog  : G.MICHON - 26/01/2011 - 1.0 - Creation initiale
#**
#*********************************************************************/
VERSION="1.0"

export PATH="$PATH:/sbin"

# Entete
header() {
    echo "***************************************************************"
    echo "Sauvegarde a chaud du Master Centreon - script de postactions"
    echo "$0"
    echo "Cible : SLES 10 SP2, plateforme IODA, serveur Master"
    echo
    echo "Description : Supprime le snapshot LVM cree avant la sauvegarde"
    echo
    echo "Version $VERSION"
    echo "***************************************************************"
    echo 
}

# Fin d'execution
footer() {
    echo
    echo "***************************************************************"
    echo "Fin d'execution : OK - snapshot supprime"
    echo "***************************************************************"
}


# Suppression d'un LV de type snapshot en le demontant au prealable
# Utilisation : delete_lv_snapshot <VG> <LV> [<point de montage>]
delete_lv_snapshot() {
    lv=/dev/$1/$2
    mount_point=$3

    echo "Suppression du snapshot $lv..."

    # Verification : ne fonctionne que sur un snapshot
    if lvs $lv >/dev/null 2>&1 ; then
        if [ "$(lvs --noheadings $lv | awk '{print $5}')" = "" ] ; then
            echo "ERROR: $lv n'est pas un snapshot LVM"
            exit 3
        fi
    else
        echo "ERROR: $lv n'existe pas"
        exit 3
    fi

    # Demontage et suppression
    if [ "$mount_point" != "" ] ; then
        umount $mount_point
        if [ $? -ne 0 ] ; then
            echo "ERROR: Impossible de demonter $mount_point"
            exit 3
        fi
    fi

    lvremove -f $lv
    if [ $? -ne 0 ] ; then
        echo "ERROR: Impossible de supprimer le LV $lv"
        exit 3
    fi
}


if [ "$IODA_VG" = "" -o "$IODA_SNAPSHOT_LV" = "" -o "$IODA_SNAPSHOT_MOUNTPOINT" = "" ] ; then
    echo "ERROR: Importer /ioda/admin/etc/current/ioda.env avant lancement"
    exit 3
fi


header
delete_lv_snapshot $IODA_VG $IODA_SNAPSHOT_LV $IODA_SNAPSHOT_MOUNTPOINT
footer
exit 0


