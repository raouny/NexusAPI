#!/bin/ksh

# Script permettant de recetter l'installation et le fonctionnement d'un client NBU sur Linux

#----------------------------------------------
# Historique des modifications:

# 25/10/2011 EB: Creation du script v 1.0

#----------------------------------------------

# Fonctions a appeler

# ********************
# Fonctions de sortie
# ********************
quit_OK() {

echo " " | tee -a $Fic_log
echo "SUCCES: Fin de la recette du client Netbackup 6.5 pour HP-UX 11iv3 le `date +%d%b%Y%Hh%M` sans erreur" | tee -a $Fic_log
echo "Consulter le fichier de log $Fic_log pour plus de details" | tee -a $Fic_log
echo "Sortie du script en CR=0" | tee -a $Fic_log
exit 0

} # END quit_OK

quit_KO() {

echo " " | tee -a $Fic_log
echo "PROBLEME: Erreurs lors de la recette du client Netbackup 6.5 pour HP-UX 11iv3 le `date +%d%b%Y%Hh%M`" | tee -a $Fic_log
echo "Consulter le fichier de log $Fic_log pour plus de details" | tee -a $Fic_log
echo "Sortie du script en CR=3" | tee -a $Fic_log
exit 3

} # END quit_KO 

# ***********************************
# Fonction verif presence filesystem 
# ***********************************

verif_presence_fs() {

echo "* Verification presence du filesystem $1 " | tee -a $Fic_log
df | grep $1 >/dev/null 2>&1
    if [ $? -ne 0 ] ; then
        echo "-- ERREUR : Le FS $1 n'existe pas" >&2 | tee -a $Fic_log
        quit_KO 
    else
        echo "--> Le FS $1 existe. Poursuite de la recette..." 2>&1 | tee -a $Fic_log
    fi

} # END verif_presence_fs 


# *********************************
# Fonction verif de l'espace occupe
# *********************************

verif_espace_occupe() {

echo "* Verification taux d'occupation du FS $1" | tee -a $Fic_log
OCCUPIEDSPACE=$(df -k $1 | tail -1 |awk '{ print $4 }' | cut -c0-2)

if [ $OCCUPIEDSPACE -gt 95 ]
then
	echo " Taux d'occupation superieur a 95% sous $1" | tee -a $Fic_log
	echo " Verifier le contenu du FS $1 (presence d'un fichier core,logs a supprimer sous /usr/openv/netbackup/logs,etc...)" | tee -a $Fic_log 
        echo " Si menage impossible, agrandir le FS $1" | tee -a $Fic_log
	quit_KO 
else
	echo "-- Espace occupe inferieur a 95% sur $1 \n la recette continue... " | tee -a $Fic_log
fi

} # END verif_espace_occupe

#***************************************************
# Fonction Verification presence du client Netbackup
#***************************************************

verif_client_NBU() {

echo "* Verification presence du client Netbackup" | tee -a $Fic_log
if [ -f /usr/openv/netbackup/bin/version ] ; then
    NBU_version=`cat /usr/openv/netbackup/bin/version | awk '{ print $2 }'`
    echo "--> Le client Netbackup est installe en version $NBU_version \n la recette continue..." | tee -a $Fic_log
else
    echo "--> Aucune version du client Netbackup detectee sur le serveur" | tee -a $Fic_log
    quit_KO 
fi

} # verif_client_NBU

#**************************************
# Fonction Verification Fichier bp.conf
#************************************** 

verif_bpconf() {

echo "* Verification presence du Master PRA dans le fichier bp.conf" | tee -a $Fic_log
master_match=`cat /usr/openv/netbackup/bp.conf | grep -l "SERVER = $Master_PRA" |wc -l`
if [ $master_match -eq 1 ]
 then
     echo "--> Le Master $Master_PRA est bien present dans le fichier bp.conf \n la recette continue..." | tee -a $Fic_log
 else
     echo "--> le Master $Master_PRA n'est pas renseigne dans le fichier bp.conf, les restaurations ne pourront pas fonctionner" | tee -a $Fic_log
     quit_KO 
fi 

} # verif_bpconf

# ************************
# Fonction ping Master PRA
# ************************

ping_master_pra() {

echo "* Test de ping vers le hostname du Master PRA pour valider la resolution de nom:" | tee -a $Fic_log 

/bin/ping $Master_PRA -c 5

if [ $? -eq 0 ]
 then
     echo "--> Resolution de nom OK vers le Master $Master_PRA \n la recette continue..." | tee -a $Fic_log 
 else
     echo "--> Resolution de nom KO vers le Master $$Master_PRA" | tee -a $Fic_log
     echo "--> Verifier la config DNS ou fichier /etc/hosts sur le client" | tee -a $Fic_log
     quit_KO 
fi

} # END ping_master_pra

# *****************************
# Fonction verif service xinetd 
# *****************************

verif_xinetd_service() {

echo "* Verification etat du service xinetd:" | tee -a $Fic_log

if [ -x "/usr/sbin/xinetd" ]
 then
     check_xinetd_status=`/bin/ps -ef | grep "xinetd" | grep -v grep | wc -l` 
     if [ $check_xinetd_status -eq 1 ]
      then
          echo "--> Le service xinetd est bien demarre\n la recette continue..." | tee -a $Fic_log
      else
          echo "--> Le service xinetd n'est pas demarre, le client Netbackup ne pourra pas fonctionner correctement" | tee -a $Fic_log
          echo "--> Essayer de relancer manuellement le service a l'aide de la commande: service xinetd restart puis relancer le script de recette" | tee -a $Fic_log
          quit_KO 
     fi
 else
    echo "--> Le service xinetd n'est pas present, le client NBU ne pourra pas fonctionner" | tee -a $Fic_log
    quit_KO 
fi

} # END verif_xinetd_service

#**********************************************
# Verification contenu du fichier /etc/services
#**********************************************

verif_etc_services() {

echo "* Verification du contenu du fichier /etc/services:" | tee -a $Fic_log

# Verification presence des differents services
bprd=`grep bprd /etc/services`
bpcd=`grep bpcd /etc/services`
vnetd=`grep vnetd /etc/services`
vopied=`grep vopied /etc/services`
bpjava=`grep bpjava-msvc /etc/services`

if [ "$bprd" = "" -o "$bpcd" = "" -o "$vnetd" = "" -o "$vopied" = "" -o "$bpjava" = "" ] 
 then
     echo "--> Les services Netbackup ne sont pas presents dans le fichier /etc/services" | tee -a $Fic_log
     echo "--> Rajouter les services suivants dans le fichier /etc/services:\n bprd:13720\n bpcd:13782\n vnetd:13724\n vopied:13783\n bpjava-msvc:13722" | tee -a $Fic_log
     quit_KO 
 else
     echo "--> Tous les services Netbackup sont bien declares dans le fichier /etc/services\n la recette continue..." | tee -a $Fic_log
fi

} # END verif_etc_services

#************************************
# Test de communication client/Master
#************************************

test_com_clt_mast() {

echo "* Execution du test de communication Client/Master:" | tee -a $Fic_log

if [ -f /usr/openv/netbackup/bin/bpclntcmd ] 
 then
     /usr/openv/netbackup/bin/bpclntcmd -pn
         if [ $? != 0 ]
          then
              echo "--> Echec lors du test de communication Client/Master" | tee -a $Fic_log
              echo "--> Verifier que le client ping le master $Master_PRA et inversement" | tee -a $Fic_log
              quit_KO
          else
              echo "--> Test de communication Client/Master reussi" | tee -a $Fic_log
         fi
else
    echo "--> ECHEC: Verifier la presence du binaire bpclntcmd sous /usr/openv/netbackup/bin" | tee -a $Fic_log
    quit_KO 
fi

} # END test_com_clt_mast

#******
# Main
#******

# Nom du master NBU du PRA
Master_PRA=CEU00057
# Nom du FS d'installation de netbackup
FS_NBU="/usr/openv"
# Fichier de log general du script
Fic_log=/usr/openv/netbackup/tmp/recette_client_linux_`date +%d%b%Y%Hh%M`.log

# Creation du repertoire /usr/openv/netbackup/tmp si inexistant

if [ ! -d "/usr/openv/netbackup/tmp" ]
 then
     mkdir /usr/openv/netbackup/tmp
fi

# Appel de la fonction verif_presence_fs
verif_presence_fs ${FS_NBU} 

# Appel de la fonction verif_client_NBU
verif_client_NBU 

# Appel de la fonciton verif_espace_occupe
verif_espace_occupe ${FS_NBU} 

# Appel de la fonction verif_bp.conf
verif_bpconf 

# Appel de la fonction ping_master_pra
ping_master_pra 

# Appel de la fonction verif_inetd_service
verif_xinetd_service 

# Appel de la fonction verif_etc/services
verif_etc_services 

# Appel de la fonction test_com_clt_mast
test_com_clt_mast 

# Sortie du script par appel de la fonction quit_OK
quit_OK 
