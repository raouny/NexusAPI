#! /bin/sh
# PROJET
# NOM DU PROGRAMME : VTL_flag_repli.sh
# DESIGNATION : Test du flag de fin de replication du COFFRE-E a TRZ-A ou TRZ-B
# HISTORIQUE
# VERSION------DATE------AUTEUR------COMMENTAIRES
# 1.0----------10-09-12--E.WEBER-----CREATION----
# -----------------------S.MUROVEC---------------
# PERIODICITE : Quotidien
# BUT DU PROGRAMME : Verifier que la replication est terminee avant de lancer l'import Netbackup a STO
# PARAMETRE D'ENTREE : "A" pour choisir TRZ-A, "B" pour choisir TRZ-B
# reset de la variable entree
unset VAR
if [ $1 = "A" ]
then
VAR=5
elif [ $1 = "B" ]
then
VAR=6
else
echo "erreur de syntaxe"
echo "La syntaxe est VTL_flag_repli.sh [A|B]"
echo "A pour TRZ-A, B pour TRZ-B"
exit 3
fi

if [ `snmpwalk -v2c -c public 221.129.10.26 1.3.6.1.4.1.19746.1.8.1.1.1.11.$VAR | awk '{print $4}'` = "0" ]
then
echo  $?
echo "La replication de TRZ-$1 est terminee"
exit 0
else
echo "La replication de TRZ-$1 n'est pas terminee"
exit 3
fi

