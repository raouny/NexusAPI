#!/usr/bin/perl
#############################################################
# Nom : sauvegarde.pl
# Langage : Perl 5
# Auteur : Guillaume MICHON 19/08/2009 (v 1.0 - Création initiale)
# Modif. :
#
# Description :
#     Script Client pour SE Sauvegarde en bulle internet
#     Pour fonctionner correctement, ce script doit tourner avec
#       les droits du compte "sauvegarde"
#
# Paramètres : 3 variables d'"environnement" HOME, XM_OUTIL et TRACES, puis paramètres obligatoires (voir usage)
# Config : config_sauvegarde/ . Les fichiers sont importés dans l'ordre suivant (si existants) :
#     * <appli>.conf
#     * <appli>_<module>.conf
#     * <appli>_<module>_<environnement>.conf
#############################################################

# Constantes globales
$HOME = shift(@ARGV);
$XM_OUTIL = shift(@ARGV);
$TRACES = shift(@ARGV);
&usage unless ($HOME && $XM_OUTIL && $TRACES);
$CONF = "$XM_OUTIL/conf";
$DATE = `/bin/date +%Y%m%d`; $DATE =~ s/\s+//g;
$FICLOG = "sauvegarde_$DATE.log";
$FICLOG_MASQUE = "sauvegarde_*.log";
$ERREUR_ARG = 2;
$ERREUR_FATALE = 3;
$NUM = -1;
@PARAMS = @ARGV;

# Paramètres de configuration par défaut
$MSBI = "msbi";
$COMPTE_MSBI_CLIENT = "msbi_client";
$COMPTE_MSBI = "msbi";
$CHEMIN_MSBI = "/usr/bin/sauvegarde_msbi";
$LOG_AGE_GZIP = 1; # Age d'un fichier de log avant "gzippage"
$LOG_AGE_MAX = 15; # Age d'un fichier de log gzippé avant suppression


# usage : Ecrit une aide sur la sortie d'erreur et quitte
# Paramètres : Aucun
# Retourne : Rien
sub usage {
    print STDERR "Service de sauvegarde. Paramètres obligatoires :\n";
    print STDERR "  -p <politique> (ex: sauvegarde_en_ligne)\n";
    print STDERR "  -r <retention> (ex: 1m)\n";
    print STDERR "  -f <fichier/repertoire a sauver>\n";
    print STDERR "  -a <application>\n";
    print STDERR "  -m <module>\n";
    print STDERR "  -e <environnement>\n";
    print "$NUM\n";
    exit $ERREUR_ARG;
}

# log : Ecrit la chaine de caractères fournie en la préfixant de la date et heure
sub log {
    @lignes = @_;
    foreach $ligne_log (@lignes) {
        $ligne_log =~ s/\s*$//;
        print FICLOG localtime()." - $ligne_log\n";
    }
}
sub openLog {
    unless (open(FICLOG, ">>$TRACES/$FICLOG")) {
        print "$NUM\n";
        print STDERR "Impossible d'ouvrir $TRACES/$FICLOG en écriture\n";
        exit $ERREUR_FATALE;
    }
}
 

# getTaille : Calcule la taille occupée sur le disque par un fichier/répertoire.
#             Cette taille peut être supérieure à la taille réelle des fichiers
#             (il s'agit de la taille __occupee sur le disque__)
# Paramètres : Fichier/répertoire à analyser
# Retourne : La taille en Kio
sub getTaille {
    $du = `sudo du -sk '$_[0]'`;
    if ($? != 0) {
        print "$NUM\n";
        &log("Impossible de lire la taille de $fichier. Sauvegarde annulée.");
        exit $ERREUR_ARG;
    }
    @taille = split(/\s+/, $du);
    return $taille[0];
}

# Ouverture du fichier de log
&openLog();
&log("##### Appel avec paramètres : @PARAMS #####");
# Rotation des logs précédents
&log("Rotation éventuelle des logs précédents (compression à $LOG_AGE_GZIP jours et suppression à $LOG_AGE_MAX jours)");
`/usr/bin/find "$TRACES" -name '$FICLOG_MASQUE.gz' -mtime +$LOG_AGE_MAX -exec 'rm' '-f' '{}' ';'`;
`/usr/bin/find "$TRACES" -name '$FICLOG_MASQUE' -mtime +$LOG_AGE_GZIP -exec '/bin/gzip' '{}' ';'`;


# Vérification des arguments
@args = @ARGV;
while ($arg = shift(@args)) {
    $politique = shift(@args) if ($arg eq "-p");
    $retention = shift(@args) if ($arg eq "-r");
    $fichier = shift(@args) if ($arg eq "-f");
    $application = shift(@args) if ($arg eq "-a");
    $module = shift(@args) if ($arg eq "-m");
    $environnement = shift(@args) if ($arg eq "-e");
}
&log("Appel avec paramètres : -p '$politique' -r '$retention' -f '$fichier' -a '$application' -m '$module' -e '$environnement'");
unless ($politique && $retention && $fichier && $application && $module && $environnement) {
    &log("Paramètre manquant - annulation.");
    &usage();
}

# Import des fichiers de configuration si présents
foreach $fic ( ("$CONF/${application}.conf", "$CONF/${application}_${module}.conf", "$CONF/${application}_${module}_${environnement}.conf" ) ) {
    if ( -r $fic ) {
        &log("Lecture de $fic...");
        $res = `. $fic ; /bin/echo \$MSBI ; /bin/echo \$COMPTE_MSBI_CLIENT ; /bin/echo \$COMPTE_MSBI ; /bin/echo \$CHEMIN_MSBI ; /bin/echo \$LOG_AGE_GZIP ; /bin/echo \$LOG_AGE_MAX`;
        ($new_msbi, $new_compte_msbi_client, $new_compte_msbi, $new_chemin_msbi, $new_log_age_gzip, $new_log_age_max) = split(/\n/, $res);
        $MSBI = $new_msbi || $MSBI;
        $COMPTE_MSBI_CLIENT = $new_compte_msbi_client || $COMPTE_MSBI_CLIENT;
        $COMPTE_MSBI = $new_compte_msbi || $COMPTE_MSBI;
        $CHEMIN_MSBI = $new_chemin_msbi || $CHEMIN_MSBI;
        $LOG_AGE_GZIP = $new_log_age_gzip || $LOG_AGE_GZIP;
        $LOG_AGE_MAX = $new_log_age_max || $LOG_AGE_MAX;
    } else {
        &log("$fic n'existe pas.");
    }
}

# Constitution des paramètres d'appel du script master
&log("Vérification de la taille de $fichier...");
$taille = &getTaille($fichier);
&log("$fichier pèse $taille Kio.");
$hostname = `/bin/hostname | /usr/bin/cut -d. -f1`; $hostname =~ s/\s*$//;

# Appel effectif
&log("Appel du script master...");
&log("Commande lancée : ( (/usr/bin/ssh -l '$COMPTE_MSBI_CLIENT' '$MSBI' sudo -u '$COMPTE_MSBI' '$CHEMIN_MSBI' -p '$politique' -r '$retention' -s '$hostname' -f '$fichier' -a '$application' -m '$module' -e '$environnement' -t '$taille' ; /bin/echo \"cr: \$?\") | /bin/sed -e 's/^/stdout: /') 2>&1");
@tout_retour = `( (/usr/bin/ssh -l '$COMPTE_MSBI_CLIENT' '$MSBI' sudo -u '$COMPTE_MSBI' '$CHEMIN_MSBI' -p '$politique' -r '$retention' -s '$hostname' -f '$fichier' -a '$application' -m '$module' -e '$environnement' -t '$taille' ; /bin/echo "cr: \$?") | /bin/sed -e 's/^/stdout: /') 2>&1`;
for (@tout_retour) {
    if (s/stdout: //) {
        if (s/cr: //) {
            $cr = $_; $cr =~ s/\s*$//;
        } else {
            push(@lignes_out, $_);
        }
    } else {
        if ($_ !~ /#######################/ && $_ !~ /non autorises sont interdits/) {
            push(@lignes_err, $_);
        }
    }
}
&log("Stdout :"); &log(@lignes_out);
&log("Stderr :"); &log(@lignes_err);
&log("Code retour : $cr");

# Interprétation du retour
if ($cr < 0 || $cr > 3) {
    print "$NUM\n";
    print STDERR "Erreur d'appel au master\n";
    &log("Erreur appel au master!#!".localtime()."!#!$NUM!#!$hostname!#!$fichier!#!$taille!#!$application!#!$module!#!$environnement");
    exit $ERREUR_FATALE;
}
if (scalar(@lignes_out) == 0) {
    print "$NUM\n";
    &log("Transfert KO!#!".localtime()."!#!$NUM!#!$hostname!#!$fichier!#!$taille!#!$application!#!$module!#!$environnement");
    if ($cr == 1) {
        # Un CR de 1 signifie un warning, donc le numéro de sauvegarde aurait dû être fourni
        $cr = 3;
    }
    if (scalar(@lignes_err) != 0) {
        foreach $ligne (@lignes_err) {
            print STDERR $ligne;
        }
        exit $cr;
    }
    else {
        print STDERR "Erreur d'appel au master\n";
        &log("Erreur appel au master!#!".localtime()."!#!$NUM!#!$hostname!#!$fichier!#!$taille!#!$application!#!$module!#!$environnement");
        exit $ERREUR_FATALE;
    }
}
$NUM = $lignes_out[0];
$NUM =~ s/\s*$//;
print "$NUM\n";
if ($cr == 0) {
    &log("Transfert OK!#!".localtime()."!#!$NUM!#!$hostname!#!$fichier!#!$taille!#!$application!#!$module!#!$environnement");
} else {
    &log("Transfert KO!#!".localtime()."!#!$NUM!#!$hostname!#!$fichier!#!$taille!#!$application!#!$module!#!$environnement");
}
foreach $ligne (@lignes_err) {
    print STDERR $ligne;
}
exit $cr;

