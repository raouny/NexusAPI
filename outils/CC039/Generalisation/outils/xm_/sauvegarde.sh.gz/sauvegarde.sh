#!/bin/bash
#############################################################
# Nom : sauvegarde.sh
# Langage : bash
# Auteur : Guillaume MICHON 19/08/2009 (v 1.0 - Création initiale)
# Modif. :
#
# Description :
#     Script Client pour SE Sauvegarde en bulle internet
#     Script englobant plaçant les variables d'environnement minimales
#
# Paramètres, config, etc : $XM_OUTIL/sauvegarde.pl
#############################################################

export HOME=/home/sauvegarde
. $HOME/.profile
export PATH=$PATH:$XM_OUTIL
if [ -x $XM_OUTIL/sauvegarde ] ; then
    $XM_OUTIL/sauvegarde "$HOME" "$XM_OUTIL" "$TRACES" $*
    exit $?
else
    echo -1
    echo "Script de sauvegarde introuvable, vérifiez les variables d'environnement" >&2
    exit 3
fi
