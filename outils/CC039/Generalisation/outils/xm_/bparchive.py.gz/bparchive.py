#!/usr/bin/python
# -*- coding: iso-8859-15 -*-

#****************************    Fiche signaletique shell  encodage: iso-8859-15    ****************************************    #
# Nom du programme : Maquette.py    But du programme : Maquette     Version minimum de l'interpreteur python : 2.4
#***********************************************    Syntaxe    **************************************************************   #
#                       maquette.py -d param1 | param2
#**********************************************    Historique    *************************************************************  #
# Version       Date            AUTEUR          ENTREPRISE      Commentaires
# 1.0           14/02/2011      C.CHAPUT        La Poste        Creation
# 1.1           24/02/2011      C.CHAPUT        La Poste        Gestion des codes retour + commentaires
# 1.2           14/04/2011      C.CHAPUT        La Poste        Ajout d'un bouchon + section __ main __
# 1.3           02/01/2012      C.CHAPUT        La Poste        Suppresion du code retour 2
# 1.4           12/01/2012      C.CHAPUT        La Poste        Ajout du bouchon sur la lg de commande
# 1.5           04/09/2013      C.CHAPUT        La Poste        "Normalisation" + fonctions utiles
# 1.6           30/09/2013      C.CHAPUT        La Poste        Ajout de la ligne de commange executee
# 1.7           18/09/2014      T.VOLLET        La Poste        Creation de toute la partie lie a Netbackup
# 1.8           11/06/2015      T.VOLLET        La Poste        Modif du -help suite test qualif avec R. Savigny
# 1.9           20/09/2015      R.SAVIGNY       PIXON           Correction du path vers les logs (pour windows)
#                                                               Correction variable utilisation vg_Param_Log
# 2.0		20/01/2016	T.VOLLET	La Poste	Ajout de l'option -i et modification de la commande bparchive
# 2.1		22/01/2016	T.VOLLET	La Poste	Creation du repertoire de log si absent
# 2.2           02/03/2016      T.VOLLET        La Poste        Prise en compte plateforme existante pour translation ou pas des noms de politiques
#                                                               Optimisation de certaines parties du code
# 2.3           17/03/2016      T.VOLLET        La Poste        Modification pour soucis de log pour SLES10
# 2.4           18/03/2016      T.VOLLET        La Poste        Sortie en code retour 3 du script si absence de la variable d environnement NBU_POL
# 2.5           22/03/2016      T.VOLLET        La Poste        Modification de la methode d affichage des logs afin de compenser les 
#                                                               soucis de log NBU tronques d origine
# 2.6           05/09/2016      T.VOLLET        La Poste        Modification de la m�thode pour traiter les r�pertoires pass�s en param�tre (la m�thode pr�c�dente, ne 
#                                                               prend qu'un seul des r�pertoires indiqu�s)
# 2.7           22/05/2017      T.VOLLET        La Poste        Modification de la m�thode pour traiter les r�pertoires pass�s en param�tre (contrairement � la m�thode pr�c�dente, il n'y a pas de r�gression
#																dans la mani�re de faire par rapport aux versions en shell/vbs)
# 2.8           10/11/2017      T.VOLLET        La Poste        Ajout purge des r�pertoires de log
#
#**********************************************    Codes retour    ***********************************************************  #
# code 0: Normal - Code retour normal : L enchainement est poursuivi
# code 1: Warning - Detection d une anomalie : L enchainement peut etre poursuivi
# code 3: Critique - Erreur Critique
# code 3: Exemple d erreur - Erreur parametres incorrects
# code > 3 : Traitement en erreur avec un code retour particulier
#*****************************************************************************************************************************  #

# bonnes pratiques :
# ------------------

# Cas des constantes :
#    Tout en majuscule
#    S�parer les mots par des underscore
#    Donner des noms simples et descriptifs
#    N'utiliser que des lettres [a-z][A-Z] et [0-9]

# Cas des variables :
#    Premi�re lettre en minuscule
#    M�lange de minuscule, majuscule avec la premi�re lettre de chaque mot en majuscule
#    Donner des noms simples et descriptifs
#    Variable d'une seule lettre � �viter au maximum sauf dans des cas pr�cis et locaux (tour de boucle)
#    N'utiliser que des lettres [a-z][A-Z] et [0-9]

#    pour debuter une variable :
#    vg_ Variable Globale
#    vl_ Variable Locale

# Cas des fonctions et procedures :

#    Premi�re lettre en majuscule
#    M�lange de minuscule, majuscule avec la premi�re lettre de chaque mot en majuscule
#    Donner des noms simples et descriptifs
#    Eviter les acronymes hormis les communs (Xml, Url, Html)
#    N'utiliser que des lettres [a-z][A-Z] et [0-9]
#    Mettre un commentaire en dessous por decrire la fonction / procedure

#    pour d�buter une fonction pr�fixer par :
#    f_ pour les fonctions
#    p_ pour les proc�dures

# Syntaxe des parametres transmis au script

#  -x     option oligatoire passee en argument
# [-x]    option optionnelle passe en argument
# <x>     champ obligatoire
# |       separe des options correspond a un ou
# (text)  message de description


# ____________________________


# Constantes : nom et version du script
__NOM_SCRIPT="bparchive.py"
__VERSION_SCRIPT="2.8"


# Import des modules python
import os
import sys
import platform
import getopt
import re
import glob
import string
import subprocess
import random
import time
import datetime
from os import path
from datetime import datetime, timedelta

# Import des modules clients ou fonctions globales

# Mode Bouchon mis en place pour les besoins du CCO: False ou True
vg_Bouchon_CCO = False
vg_Code_Retour_Bouchon_CCO = 5 # Code retour dans le cas de l'utilisation du mode bouchon
# Fin du parametrage du mode bouchon

# Definition des constantes systemes
__SYSTEM = sys.platform
__PYTHON_VERSION = sys.version

# Definition des constantes code retour VTOM
CR_WG = 1 # code retour warning
CR_BL = 3 # code retour bloquant
CR_OK = 0 # code retour bonne execution

# Definitions des variables globales :
vg_Debug = True
vg_Param_p = None # politique
vg_Param_s = None # schedule
vg_Param_r = None # repertoire
vg_Param_L = None # option de log
vg_Param_h = None # VM
vg_Param_f = None # fichier
vg_Param_i = None # option immediate
vg_Param_Log = None # repertoire ou se trouvent les logs
vg_Param_Timestamp = None # valeur de timestamp du log
vg_chaine_param = "" # option sans valeur
compteur_arg = 0

# liste des masters Legacy
l_masters_lgy = ['CEUV0006', 'CEUV0007', 'CEUV0008', 'CEN00190', 'CEN00191', 'CEY00028', 'CEY00030', 'CEY00039', 'CEY00040']

# Version du CC a completer
__VERSION = __NOM_SCRIPT + "  v" + __VERSION_SCRIPT + " - python "+__PYTHON_VERSION+" - "+__SYSTEM

#*****************************************************************************************************************************  #
# Definitions des fonctions et procedures
#*****************************************************************************************************************************  #
def p_Debug(chaine):
    # affiche la chaine lorsque l option debug est positionnee a True
    if vg_Debug : print str(chaine)

def p_Test_Options_Script(arguments):
    # tests les arguments passes en parametres au script
        print "Tests des arguments du script"

        if (arguments == []) or (arguments is None) :
                print "*** un argument est manquant ***"
                p_Print_Usage(CR_BL)


        if vg_Param_p is None or vg_Param_s is None :
                print "*** le nom de la politique et du schedule sont obligatoires"
                p_Print_Usage(CR_BL)

        if vg_Param_h is not None and vg_Param_f is not None :
                print "*** l'option -f et -h sont incompatibles"
                

        p_Debug("Fin de p_Test_Options")

def p_Print_Usage(err):
#   Affiche le message d utilisation du script
#   quitte le programme avec le code retour passe en argument
    print r"""
    Usage de la commande :
    bparchive -p <politique> -s <schedule> /repertoire/exemple /fichier/backup


    Sous UNIX / Linux le caractere * doit etre remplace par \*

    -p         : nom de la politique a utiliser
    -s         : nom du schedule a utiliser
    [-f]       : nom du fichier contenant les differents fichiers ou repertoires a sauvegarder
    [-h]       : nom de la VM a sauvegarder
    [-S]       : nom du master
    [-L]       : preciser 'nolog' si on ne souhaite pas en avoir
    [-i]       : option immediate
    [--help]   : produit l'aide suivante
    [--debug]  : mode verbose - permet de debugger
    [-B | --bouchon=<code retour>]   : bouchon CCO

    Exemple de commande:
    bparchive.py -p COFFRE_A -s SAUVEG_1S /etc/hosts
    bparchive.py -p COFFRE_A -s SAUVEG_1S /etc/hosts /tmp/:usr/openv/
    bparchive.py -p VMWARE -s SAUVEG_1M -h CPYV0456 -L nolog
    bparchive.py -p COFFRE_A -s SAUVEG_1M -f /fic/bckup
    bparchive.py -i -p COFFRE_A -s FULL_1M -h CEY0052
    bparchive.py -i -p LINUX_LGY -s FULL_1S -h CPYV0456 -L nolog
    bparchive.py -i -p LINUX_LGY -s INCR_1S -h CPYV0456 -L nolog
    bparchive.py -i -p VMWARE -s SAUVEG_1M -h CPYV0456 -L nolog
    """

    sys.exit(err)

def f_Valorisation_Variable_System(chaine): # permet de valoriser des $ sous unix ou % sous windows
    vl_Resultat = os.path.expandvars(chaine)
    p_Debug("Resultat de la valorisation " + str(vl_Resultat))
    return vl_Resultat

def f_Replace_Backshlashs(chaine):
        # Remplace les \ des chemins Windows par des \\ lisibles par python
        # Attention la chaine ne doit pas etre vide
        if chaine != None :
           vl_Resultat = chaine.replace("\\","\\\\")
           p_Debug("Resultat du Replace_Backshlashs : "+str(vl_Resultat))
           return vl_Resultat

def p_Print_Error(mesg, num):
    # retourne le message d erreur et sort en code retour
    print mesg
    print "Sortie en code retour " + str(num)
    sys.exit(num)

def f_Generation_Log(OS):
    # permet de generer le log de sortie netbackup
    global vg_Param_Log
    # generation du timestamp
    vg_Param_Timestamp = str(time.strftime("%Y%m%d_%H%M%S")) + str(random.randint(0,1000))
    if OS == ("win32"):
        vg_Param_Log = "c:\\windows\\temp\\bparchive_" + str(vg_Param_Timestamp)+ ".log"
    elif OS == ("hp-ux11"):
        vg_Param_Log = "/usr/openv/netbackup/tmp/bparchive_" + str(vg_Param_Timestamp)+ ".log"
    elif OS == ("linux2"):
        vg_Param_Log = "/usr/openv/netbackup/tmp/bparchive_" + str(vg_Param_Timestamp)+ ".log"

def p_Param_Lg_Commande(params):
    # Gestion des arguments passes en parametre de la ligne de commandes
    global vg_Bouchon_CCO
    global vg_Code_Retour_Bouchon_CCO
    global vg_Param_p
    global vg_Param_s
    global vg_Param_L
    global vg_Param_r
    global vg_Param_h
    global vg_Param_M
    global vg_Param_f
    global vg_Param_i
    global vg_Param_t
    global vg_Param_w
    global compteur_arg
    global vg_chaine_param

    try:
        opts, args = getopt.getopt(params, "p:s:L:B:h:S:f:it:w", ["help", "debug","bouchon="])

    except getopt.GetoptError, err:
        # print help information and exit:
        print str(err) # will print something like "option -a not recognized"
        p_Print_Usage(CR_BL)

    for o, a in opts:
        if o == ("--help"):
            p_Print_Usage(CR_BL)
        elif o == ("-p"):
            compteur_arg = compteur_arg +2
            vg_Param_p = f_Valorisation_Variable_System(a)
            
        elif o == ("-s"):
            compteur_arg = compteur_arg + 2
            vg_Param_s = f_Valorisation_Variable_System(a)
            
        elif o == ("-h"):
            compteur_arg = compteur_arg + 2
            vg_Param_h = f_Valorisation_Variable_System(a)
            
        elif o == ("-S"):
            compteur_arg = compteur_arg + 2
            vg_Param_M = f_Valorisation_Variable_System(a)
            
        elif o == ("-L"):
            compteur_arg = compteur_arg + 2
            vg_Param_L = f_Valorisation_Variable_System(a)
            vg_Param_L = vg_Param_L.upper()
            
        elif o == ("-f"):
            compteur_arg = compteur_arg + 2
            vg_Param_f = f_Valorisation_Variable_System(a)

        elif o == ("-t"):
            compteur_arg = compteur_arg + 2
            vg_Param_t = f_Valorisation_Variable_System(a)    
      
        elif o == ("-i"):
            compteur_arg = +1
            vg_chaine_param = vg_chaine_param + " " + "-i"
            vg_Param_i = True

        elif o == ("-w"):
            compteur_arg = +1
            vg_Param_w = True
	    
        elif o in ("--bouchon","-B"): # UTILISER POUR LE MODE BOUCHON
            compteur_arg = compteur_arg + 2
            vg_Bouchon_CCO = True
            vg_Code_Retour_Bouchon_CCO = int(a)
            p_Print_Error("Mode bouchon",vg_Code_Retour_Bouchon_CCO)
            
        elif o in ("--debug"):
            compteur_arg = +1
            vg_Debug = True
            p_Debug("Mode DEBUG Actif")
            
        else:
            assert False, "option invalide"



    # affiche un message d erreur en cas de params incorrects
    p_Test_Options_Script(params)



#*****************************************************************************************************************************  #
# definition des fonctions par system d exploitation
#*****************************************************************************************************************************  #
def f_verification_rep_log(__SYSTEM):
    # verification de la presence du repertoire de log et creation si besoin
    if __SYSTEM == ("win32"):
        path = "c:\\windows\\temp"
    elif __SYSTEM == ("hp-ux11") or __SYSTEM == ("linux2"):
        path = "/usr/openv/netbackup/tmp"

    if os.path.exists(path) == False:
        os.makedirs(path, mode=0755)

def f_purge_logs(__SYSTEM):	
	print "Purge des logs de plus de 14 jours"
	# valorisation du path

	if __SYSTEM == ("win32"):
		path_log = "c:\\windows\\temp\\bparchive_*"
	elif __SYSTEM == ("hp-ux11") or __SYSTEM == ("linux2"):
		path_log = "/usr/openv/netbackup/tmp/bparchive_*"

	liste_fic_logs = glob.glob(path_log)

	for file_log in liste_fic_logs:
		print file_log
		diff_date = datetime.now() - timedelta(days=14)
		date_fichier = datetime.fromtimestamp(path.getctime(file_log))

		if date_fichier < diff_date:
			print file_log
			os.remove(file_log)
		
		
def f_force_media_coffre (vg_Param_p):
    if vg_Param_p[:7] == "COFFRE_" or vg_Param_p[:10] == "NT_COFFRE_":
        OLDMDSRV = os.getenv('NBU_POL')
        if not OLDMDSRV:
            p_Print_Error('Erreur, la variable NBU_POL n\'est pas positionnee', 3)
        else:
            if vg_Param_p[:10] == "NT_COFFRE_":
                vg_Param_p = OLDMDSRV + vg_Param_p[3:]
            else:
                vg_Param_p = OLDMDSRV + vg_Param_p
    return vg_Param_p
                  
    
def f_verification_plateforme(__SYSTEM, vg_Param_p):
    # verification du master utilise afin de modifier ou pas les politiques
    if __SYSTEM == ("win32"):
        import _winreg
        key = _winreg.OpenKey( _winreg.HKEY_LOCAL_MACHINE, 'SOFTWARE\\Veritas\\NetBackup\\CurrentVersion\\Config',0, _winreg.KEY_READ) 
        (valeur,autrevaleur) = _winreg.QueryValueEx(key,'Server')
        _winreg.CloseKey(key)
        vl_Nom_Master = valeur[0] 
        
    elif __SYSTEM == ("hp-ux11") or __SYSTEM == ("linux2"):
        BPCONF = "/usr/openv/netbackup/bp.conf"
        f_BPCONF = open (BPCONF, "r")
        vl_Nom_Master = f_BPCONF.readline().rstrip('\n').split('=')[1].replace(" ","")
        f_BPCONF.close()
    
    if (vl_Nom_Master in l_masters_lgy) == False:
        # alors on modifie le nom de la politique
           # on modifie les anciens noms de politique
        if vg_Param_p[:16] == "CQU00056_COFFRE_": #preprod
            vg_Param_p = "LINUX_LGY"
        elif str(vg_Param_p[:16]) == "CEY00033_COFFRE_": #prod trz a
            vg_Param_p = "LINUX_LGY"
        elif str(vg_Param_p[:16]) == "CEU00024_COFFRE_": # prod trz b
            vg_Param_p = "LINUX_LGY"
        elif str(vg_Param_p[:16]) == "CEU00023_COFFRE_": #preprod
            vg_Param_p = "LINUX_LGY"
        elif str(vg_Param_p[:16]) == "CEU00033_COFFRE_": #prod trz a
            vg_Param_p = "WINDOWS_LGY"
        elif str(vg_Param_p[:16]) == "CEU00025_COFFRE_": # prod trz b
            vg_Param_p = "UNIX_LGY"
        elif str(vg_Param_p[:16]) == "CEUV0009_COFFRE_": #preprod
            vg_Param_p = "LINUX_LGY"
        elif str(vg_Param_p[:16]) == "CEU00027_COFFRE_": #prod trz a
            vg_Param_p = "UNIX_LGY"
        elif str(vg_Param_p[:16]) == "CEN00185_COFFRE_": # prod trz b
            vg_Param_p = "WINDOWS_LGY"
        elif str(vg_Param_p[:16]) == "CEN00183_COFFRE_": #preprod
            vg_Param_p = "WINDOWS_LGY"
        elif str(vg_Param_p[:16]) == "CEN00184_COFFRE_": #prod trz a
            vg_Param_p = "WINDOWS_LGY"
        elif str(vg_Param_p[:16]) == "CEUV0010_COFFRE_": # prod trz b
            vg_Param_p = "UNIX_LGY"
        elif str(vg_Param_p[:16]) == "CEUV0006_COFFRE_": #preprod
            vg_Param_p = "LINUX_LGY"
        elif str(vg_Param_p[:16]) == "CEUV0007_COFFRE_": #prod trz a
            vg_Param_p = "LINUX_LGY"
        elif str(vg_Param_p[:16]) == "CEUV0008_COFFRE_": # prod trz b
            vg_Param_p = "LINUX_LGY"
        elif str(vg_Param_p[:16]) == "CEN00054_COFFRE_": # prod trz b
            vg_Param_p = "WINDOWS_LGY"

    return vg_Param_p
    
def f_Lancement_Windows(params):
    # global code_retour_fonction si pas modifie ...
    vl_Code_Retour = 256
    global vg_Param_Log
    f_Generation_Log(__SYSTEM)

    # print "debut de la fonction windows"

    # la commande que je veux executer
    if vg_Param_L == "NOLOG":
        vl_Commande = "bparchive.exe " + params
    else:
        vl_Commande = "bparchive.exe -L "+ str(vg_Param_Log) + " " + params

    print  vl_Commande

    f_output = os.popen(vl_Commande)

    if vg_Param_L != "NOLOG":
        print "**Affichage du log"
        # affichage du log netbackup
        time.sleep(10)

        vl_Fichier_Lecture = open(vg_Param_Log,'r')


        while 1:
            where = vl_Fichier_Lecture.tell()
            line = vl_Fichier_Lecture.readline()
            print line
            
            if vl_Code_Retour:
                time.sleep(5)
                print vl_Fichier_Lecture.read()
                break

    # reccupere le code retour de la commande system
    vl_Return = f_output.close()
    if vg_Param_L != "NOLOG":
        vl_Fichier_Lecture.close()

    if vl_Return == None :
        vl_Code_Retour = CR_OK
    else:
        vl_Code_Retour = vl_Return


    # retourne le code retour de l execution de la commande
    print "Code Retour : " + str(vl_Code_Retour)
    return vl_Code_Retour

def f_Lancement_Hpux(params):
    return f_Lancement_Linux(params)

def f_Lancement_Solaris(params):
    p_Print_Error("OS non supporte", CR_BL)
    
def f_Vers_Sles():
    vl_Vers_Sles = "0"
    vl_Fichier_Vers_Sles = open("/etc/SuSE-release",'r')

    for ligne in vl_Fichier_Vers_Sles:
        if "VERSION = 10" in ligne:
            vl_Vers_Sles = "10"
    vl_Fichier_Vers_Sles.close()
    return vl_Vers_Sles

def f_Lancement_Linux(params):
    # global code_retour_fonction si pas modifie ...
    vl_Code_Retour = 256
    global vg_Param_Log
    f_Generation_Log(__SYSTEM)
    ##vl_Fichier_Log = str(f_Generation_Log(__SYSTEM))

    # print "debut de la fonction linux/unix"

    # la commande que je veux executer
    if vg_Param_L == "NOLOG":
        vl_Commande = "/usr/openv/netbackup/bin/bparchive " + params
    else:
        vl_Commande = "/usr/openv/netbackup/bin/bparchive -L "+ str(vg_Param_Log) + " " + params

    print  vl_Commande

    f_output = os.popen(vl_Commande)


    if vg_Param_L != "NOLOG":
        print "**Affichage du log"
        # affichage du log netbackup
        time.sleep(10)
        # on cherche la version pour du SLES
        if (__SYSTEM) == "linux2":
            vl_Vers_Sles = f_Vers_Sles()
            
        vl_Fichier_Lecture = open(vg_Param_Log,'r')


        while 1:
            where = vl_Fichier_Lecture.tell()
            line = vl_Fichier_Lecture.readline()
            print line
            
            if vl_Code_Retour:
                time.sleep(5)
                print vl_Fichier_Lecture.read()
                break
                                
    # reccupere le code retour de la commande system
    vl_Return = f_output.close()
    if vg_Param_L != "NOLOG":
        vl_Fichier_Lecture.close()

    if vl_Return == None :
        vl_Code_Retour = CR_OK
    else:
        vl_Code_Retour = vl_Return


    # retourne le code retour de l execution de la commande
    print "Code Retour : " + str(vl_Code_Retour)
    return vl_Code_Retour




#*****************************************************************************************************************************  #
# Main
#*****************************************************************************************************************************  #
if __name__ == "__main__":
    # Variables du programme principal


    # Affiche la version
    print __VERSION + "\n"

   

    # Affiche la commande lancee
    print "Execution de la commande : " + str(sys.argv)

    p_Param_Lg_Commande(sys.argv[1:])
    
    # on compte le nombre d'arguments pour prendre le dernier contenant le fichier ou le r�pertoire � sauvegarder
    total = len(sys.argv[1:])

    if vg_Param_h == None:

		j =  compteur_arg + 1 # sys.argv affiche le nom du script en premier parametre donc on ajoute un pour ne pas prendre un argument en trop
		vg_Param_r = "" # on initialise en texte pour eviter les messages d'erreurs du type str et nonetype
				
		while j < len(sys.argv):
			vg_Param_r = vg_Param_r + " " + sys.argv[j]
			j += 1
			
        
    # on lit la variable d environnement NBU afin de forcer les clients utilisant COFFRE_A sur NOMMEDIASERVEUR_COFFRE_A
    vg_Param_p = f_force_media_coffre (vg_Param_p)

    # on verifie sur quel master nous sommes pour effectuer la translation du nom de la politique ou pas
    vg_Param_p = f_verification_plateforme (__SYSTEM, vg_Param_p)

    if vg_Param_r == None and vg_Param_h == None:
        vl_Param = "-w -p " + str(vg_Param_p) + " -s " + str(vg_Param_s) + " " + str(vg_chaine_param)
    elif vg_Param_f != None:
        vl_Param =  str(vg_chaine_param) + " -w -p " + str(vg_Param_p) + " -s " + str(vg_Param_s) + " -f " + str(vg_Param_f) 
    elif vg_Param_r != None and vg_Param_h == None:
        vl_Param = str(vg_chaine_param) + " -w -p " + str(vg_Param_p) + " -s " + str(vg_Param_s) + " " + str(vg_Param_r)
    elif vg_Param_r == None and vg_Param_h != None:
        vl_Param = str(vg_chaine_param) + " -w -p " + str(vg_Param_p) + " -s " + str(vg_Param_s) + " -h " + str(vg_Param_h) 
        if str(vg_Param_p[:2]) == "VM":
            vg_Param_L = "NOLOG"
    elif vg_Param_r != None and vg_Param_h != None:
        p_Print_Usage(3)


    # ++++++++++++++++++++++++++++++++++

    #*****************************************************************************************************************************  #
    # Lancement de la commande selon la plateforme utilisee
    #*****************************************************************************************************************************  #
    if __SYSTEM == "win32":
		f_verification_rep_log(__SYSTEM)
		vl_Code_Retour = f_Lancement_Windows(vl_Param)
		f_purge_logs(__SYSTEM)
    elif __SYSTEM == "hp-ux11":
		f_verification_rep_log(__SYSTEM)
		vl_Code_Retour = f_Lancement_Hpux(vl_Param)
		f_purge_logs(__SYSTEM)
    elif __SYSTEM == "linux2":
		f_verification_rep_log(__SYSTEM)
		vl_Code_Retour = f_Lancement_Linux(vl_Param)
		f_purge_logs(__SYSTEM)
    elif __SYSTEM == "solaris":
		vl_Code_Retour = f_Lancement_Solaris(vl_Param)
    else:
		p_Print_Error("PF inconnue",CR_BL)

	
    #######################################
    # Verification du code retour         #
    #######################################
    if vl_Code_Retour not in (0, None):
        p_Print_Error("Erreur inattendue", CR_BL)
    else :
        vl_Code_Retour = CR_OK
    #######################################
    # Fin du Programme avec code_retour   #
    #######################################
    p_Print_Error("Fin du programme. " ,vl_Code_Retour)


