/************************************************************
 * Nom : sauvegarde.c
 * Langage : C
 * Auteur : Guillaume MICHON 19/08/2009 (v 1.0 - Création initiale)
 * Modif. : 
 *
 * Description :
 *    Script Client pour SE Sauvegarde en bulle internet
 *    Wrapper pour le setuid
 *
 * Paramètres & retour : Voir le script appelé
 ***********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
   setreuid(geteuid(),geteuid());
   setregid(getegid(),getegid());
   execvp("sauvegarde.pl", argv);
   return 3;
}
