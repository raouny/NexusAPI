#!/bin/sh
#****************************    Fiche signaletique shell  encodage: iso-8859-15    ****************************************#
# Nom du programme : bparchive.sh    But du programme : Lanceur "bparchive.py"     Version minimum de l'interpreteur python : 2.4
#***********************************************    Syntaxe    *************************************************************#
#                       
#**********************************************    Historique    ***********************************************************#
# Version       Date            AUTEUR          ENTREPRISE      Commentaires
# 1.0           ??/??/2015      T.VOLLET        La Poste        Creation
# 1.1           ??/??/2015      T.VOLLET        La Poste        Ajout de la variable "$XM_OUTIL"
#***************************************************************************************************************************#

python $XM_OUTIL/bparchive.py $*
