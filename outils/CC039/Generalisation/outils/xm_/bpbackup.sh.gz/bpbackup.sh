#!/bin/sh
#****************************    Fiche signaletique shell  encodage: iso-8859-15    ****************************************#
# Nom du programme : bpbackup.sh    But du programme : Lanceur "bpbackup.py"     Version minimum de l'interpreteur python : 2.4
#***********************************************    Syntaxe    *************************************************************#
#                       
#**********************************************    Historique    ***********************************************************#
# Version       Date            AUTEUR          ENTREPRISE      Commentaires
# 1.0           ??/??/20??      T.VOLLET        La Poste        Creation
# 1.1           ??/??/2015      T.VOLLET        La Poste        Ajout de la variable "$XM_OUTIL"
#***************************************************************************************************************************#

python $XM_OUTIL/bpbackup.py $*
