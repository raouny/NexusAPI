#!/bin/ksh
#  Description : Recherche des canaux en "RETRY" d'un GFA
#  LMD 29/09/2007 
# 
#-------------
# Parametres :
#-------------
# -m <Nom du GFA a afficher>
# -v affiche la version
# -h help!

#---------------
# Codes retour :
#---------------
#  - 0 : Execution correcte - pas de canaux en retry
#  - 1 : Execution correcte - il y a des canaux en retry
#  - 2 : Execution incorrecte - Pb d'environnement ou GFA arrete 
#  - 3 : Execution incorrecte - GFA ou FA inconnue

typeset TRACES=logs
#--------------------
# Test des parametres
#--------------------
# typeset SRV
SRV=""
for i 
do
case "$i" in
 -m*)
     GFATOT=$i
     GFA=`echo $GFATOT |cut -c 3- `
    ;; 

 -v*)
     echo "`basename $0` - LMD - Version 1.03  "
     exit 0 
    ;; 
 -h*)
     clear
     echo "                                   `tput smso` `basename $0` `tput rmso`"
     echo "                                  =================="
     echo " Ce shell permet de detecter les canaux en retry dans un GFA."
     echo " "
     echo "  Vous devez fournir les parametres suivants :"
     echo "  "
     echo "  `tput smso`-m`tput rmso`<nom_du GFA>"
     echo "  "
     echo "  (pas d'espace entre \"-m\" et le nom du GFA !)"
     echo "  "
     echo "  "
     exit 0;;

esac
done

#------------------------
#  Controle des  parametres obligatoires 
#------------------------
if [ -z "$GFA" ]
   then
     echo "Le nom du GFA est un parametre obligatoire."
    exit -1
fi

#--------------------
# Test des variables
#--------------------

typeset -i FLAG=0

if [ "$TRACES" = "" ]
then
   echo "\n*** ERREUR :Variable TRACES non declaree\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------------
# Test du contenu des variables
#------------------------------

typeset -i FLAG=0

if [ ! -d $TRACES ]
then
   echo "\n*** ERREUR :Repertoire $TRACES inexistant\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------
# Recuperation de la date
#------------------------
typeset date=`date '+%y%m%d%H%M%S'`

#---------------------------
# Definition des variables :
#---------------------------

typeset FIC_SORTI=$TRACES/${date}.`basename $0`.log

#------------------------------------------
# Definition de l'en-tete du fichier traces
#------------------------------------------
typeset ENTETE=`uname -n`" - "`whoami`" - "`date`" - SCRIPT: "`basename $0`" - PID: "$$
echo "${ENTETE}" > $FIC_SORTI
echo "---------------------------------------------------------------------------------" >> $FIC_SORTI


#------------------------
# Demarrage du script
#------------------------
echo "Recherche des canaux en retry sur le GFA $GFA"
echo "display chstatus(*) where(status EQ RETRYING)" | runmqsc $GFA > /dev/null
CODE_RETOUR=$?
# echo "code retour : $CODE_RETOUR"

case "$CODE_RETOUR" in
"0")
# La commande s'est terminée normalement, il y a donc des channels en retry
# on sort le résultat du runmqsc dans un fichier temp :
# 
# echo "dis chstatus(*) where(status EQ RETRYING)" | runmqsc $GFA | grep "AMQ8420" >/tmp/MQ_dspfa_tmp
echo "dis chstatus(*) where(status EQ RETRYING)" | runmqsc $GFA  >/tmp/MQ_dspfa_tmp
cat /tmp/MQ_dspfa_tmp
statut=$(cut -c1-7 /tmp/MQ_dspfa_tmp)
# echo "le statut est .$statut."


# Sortie fichier
echo "" >> ${FIC_SORTI}

echo "Il y a des canaux en retry sur le GFA $GFA."
cat /tmp/MQ_dspfa_tmp >> ${FIC_SORTI}
echo " ****  Warning - Il y a des canaux en retry sur le GFA $GFA. **** " >> ${FIC_SORTI}


echo ""
exit -1 
;;

"10")
# La commande s'est terminée en code 10, à priori il n'y a pas de canaux en erreur. Vérification :
# on sort le résultat du runmqsc dans un fichier temp :
# 
echo "dis chstatus(*) where(status EQ RETRYING)" | runmqsc $GFA | grep "AMQ8420" >/tmp/MQ_dspfa_tmp
# on vérifie la présence du n° de message pour "AMQ8420: Etat du canal introuvable"
statut=$(cut -c1-7 /tmp/MQ_dspfa_tmp)
# echo "le statut est .$statut."
# Sortie fichier
echo "" >> ${FIC_SORTI}
if [ "$statut" = "AMQ8420" ]
then 
echo "Tous les canaux sont OK sur le GFA $GFA."
echo " ****  Normal - Tous les canaux sont OK sur le GFA $GFA. **** " >> ${FIC_SORTI}
echo ""
exit -0 

else
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis runmqsc **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis runmqsc **** " >> ${FIC_SORTI}
echo ""
exit -2 
fi
;;



20)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis runmqsc **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis runmqsc **** " >> ${FIC_SORTI}
echo " ****  Le GFA $GFA ne semble pas en fonctionnement  **** " >> ${FIC_SORTI}
echo " ****  Le GFA $GFA ne semble pas en fonctionnement  **** " 
echo ""
exit -3 


;;
*)
echo "" >> ${FIC_SORTI}
echo ""
echo " ****  Erreur  **** "
echo " ****  Erreur  **** " >> ${FIC_SORTI}
echo " ****  code retour $CODE_RETOUR  **** "
echo " ****  code retour $CODE_RETOUR  **** " >> ${FIC_SORTI}
echo " ****  Affichage de la FA $FA du GFA $GFA impossible  **** " 
echo " ****  Affichage de la FA $FA du GFA $GFA impossible  **** " >> ${FIC_SORTI}
exit -3 ;;
esac



