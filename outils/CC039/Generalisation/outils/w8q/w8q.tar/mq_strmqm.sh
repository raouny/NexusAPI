#!/bin/ksh
#  Description : shell de demarrage d'un GFA
#  LMD 27/09/2007 
# 
#-------------
# Parametres :
#-------------
# -m <Nom du GFA a demarrer>
# -v affiche la version
# -h help!

#---------------
# Codes retour :
#---------------
#  - 0 : Execution correcte - GFA démarré
#  - 1 : Execution incorrecte - Pb d'environnement ou GFA deja démarré 
#  - 2 : Execution incorrecte - GFA en cours d'arret
#  - 3 : Execution incorrecte - Erreur grave sur GFA ou pb de droits

# typeset TRACES=logs
#--------------------
# Test des parametres
#--------------------
typeset SRV
SRV=""
for i 
do
case "$i" in
 -m*)
     GFATOT=$i
     GFA=`echo $GFATOT |cut -c 3- `
    ;; 
 -v*)
     echo "`basename $0` - LMD - Version 1.03  "
     exit 0 
    ;; 
 -h*)
     clear
     echo "                                   `tput smso` `basename $0` `tput rmso`"
     echo "                                  =================="
     echo " Ce shell permet de demarrer un GFA."
     echo " "
     echo "  Vous devez fournir les parametres suivants :"
     echo "  "
     echo "  `tput smso`-m`tput rmso`<nom_du GFA>"
     echo "  "
     echo "  (pas d'espace entre \"-m\" et le nom du GFA !)"
     echo "  "
     echo "  "
     exit 0;;

esac
done

#------------------------
#  Controle des  parametres obligatoires 
#------------------------
if [ -z "$GFA" ]
   then
     echo "Le nom du GFA a demarrer est un parametre obligatoire."
    exit -1
fi

#--------------------
# Test des variables
#--------------------

typeset -i FLAG=0

if [ "$TRACES" = "" ]
then
   echo "\n*** ERREUR :Variable TRACES non declaree\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------------
# Test du contenu des variables
#------------------------------

typeset -i FLAG=0

if [ ! -d $TRACES ]
then
   echo "\n*** ERREUR :Repertoire $TRACES inexistant\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------
# Recuperation de la date
#------------------------
typeset date=`date '+%y%m%d%H%M%S'`

#---------------------------
# Definition des variables :
#---------------------------

typeset FIC_SORTI=$TRACES/${date}.`basename $0`.log

#------------------------------------------
# Definition de l'en-tete du fichier traces
#------------------------------------------
typeset ENTETE=`uname -n`" - "`whoami`" - "`date`" - SCRIPT: "`basename $0`" - PID: "$$
echo "${ENTETE}" > $FIC_SORTI
echo "---------------------------------------------------------------------------------" >> $FIC_SORTI




#------------------------
# Demarrage
#------------------------
strmqm $GFA
CODE_RETOUR=$?
#echo "code retour : $CODE_RETOUR"

case "$CODE_RETOUR" in
"0")
echo "" >> ${FIC_SORTI}
echo " ****  Normal - code retour $CODE_RETOUR depuis strmqm **** " >> ${FIC_SORTI}
echo " ****  Le GFA $GFA a ete demarre  **** " >> ${FIC_SORTI}
echo ""
exit -0 

;;
5)
echo "" >> ${FIC_SORTI}
echo " ****  Warning - code retour $CODE_RETOUR depuis strmqm **** "
echo " ****  Warning - code retour $CODE_RETOUR depuis strmqm **** " >> ${FIC_SORTI}
echo " ****  Le GFA $GFA est deja demarre  **** " >> ${FIC_SORTI}
echo ""
exit -1 

;;
16)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** " >> ${FIC_SORTI}
echo " ****  Le GFA $GFA n'existe pas  **** " >> ${FIC_SORTI}
echo " ****  Echec du demarrage du GFA $GFA **** "
echo " ****  Echec du demarrage du GFA $GFA **** " >> ${FIC_SORTI}
echo ""
exit -3 

;;
23)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** " >> ${FIC_SORTI}
echo " ****  Les logs du GFA $GFA ne sont pas disponibles  **** " >> ${FIC_SORTI}
echo " ****  Echec du demarrage du GFA $GFA **** "
echo " ****  Echec du demarrage du GFA $GFA **** " >> ${FIC_SORTI}
echo ""
exit -3 

;;
24)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** " >> ${FIC_SORTI}
echo " ****  Un process lie a une instance precedente du GFA $GFA est toujours present **** " >> ${FIC_SORTI}
echo " ****  Echec du demarrage du GFA $GFA **** "
echo " ****  Echec du demarrage du GFA $GFA **** " >> ${FIC_SORTI}
echo ""
exit -3 

;;
49)
echo "" >> ${FIC_SORTI}
echo " ****  Warning - code retour $CODE_RETOUR depuis strmqm **** " >> ${FIC_SORTI}
echo " ****  Le GFA $GFA est en cours d'arret **** " >> ${FIC_SORTI}
echo " ****  Echec du demarrage du GFA $GFA **** "
echo " ****  Echec du demarrage du GFA $GFA **** " >> ${FIC_SORTI}
echo ""
exit -2 

;;
69)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** " >> ${FIC_SORTI}
echo " ****  Probleme d'espace disque pour le GFA $GFA **** " >> ${FIC_SORTI}
echo " ****  Echec du demarrage du GFA $GFA **** "
echo " ****  Echec du demarrage du GFA $GFA **** " >> ${FIC_SORTI}
echo ""
exit -3 

;;
72)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** " >> ${FIC_SORTI}
echo " ****  Erreur sur le nom du GFA $GFA **** " >> ${FIC_SORTI}
echo " ****  Echec du demarrage du GFA $GFA **** "
echo " ****  Echec du demarrage du GFA $GFA **** " >> ${FIC_SORTI}
echo ""
exit -3 

;;
100)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** " >> ${FIC_SORTI}
echo " ****  Chemin des logs non valide pour le GFA $GFA **** " >> ${FIC_SORTI}
echo " ****  Echec du demarrage du GFA $GFA **** "
echo " ****  Echec du demarrage du GFA $GFA **** " >> ${FIC_SORTI}
echo ""
exit -3 

;;
119)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis strmqm **** " >> ${FIC_SORTI}
echo " ****  L'utilisateur $USER n'a pas les droits pour demarrer le GFA $GFA **** " >> ${FIC_SORTI}
echo " ****  Echec du demarrage du GFA $GFA **** "
echo " ****  Echec du demarrage du GFA $GFA **** " >> ${FIC_SORTI}
echo ""
exit -3 


;;
*)
echo "" >> ${FIC_SORTI}
echo ""
echo " ****  Erreur  **** "
echo " ****  Erreur  **** " >> ${FIC_SORTI}
echo " ****  code retour $CODE_RETOUR  **** "
echo " ****  code retour $CODE_RETOUR  **** " >> ${FIC_SORTI}
echo " ****  Demarrage du GFA <<$GFA>> impossible  **** " 
echo " ****  Demarrage du GFA <<$GFA>> impossible  **** " >> ${FIC_SORTI}
exit -3 ;;
esac



