#!/bin/ksh
#  Description : Backup des systèmes de fichiers WebSphere MQ d'un serveur
#  LMD 04/10/2007 
# 
#-------------
# Parametres :
#-------------
# -v affiche la version
# -h help!

#---------------
# Codes retour :
#---------------
#  - 0 : Execution correcte - 
#  - 3 : Execution incorrecte - 

# typeset TRACES=logs
#--------------------
# Test des parametres
#--------------------
  for i 
  do
  case "$i" in
  
   -v*)
       echo "`basename $0` - LMD - Version 1.03  "
       exit 0 
      ;; 
   -h*)
       clear
       echo "                                   `tput smso` `basename $0` `tput rmso`"
       echo "                                  =================="
       echo " Ce shell permet de creer une archive comprimee des systèmes de fichers"
       echo " "
       echo "  /opt/mqm et /var/mqm d'un serveur"
       echo "  "
       echo " Il n'y a pas de parametres "
       echo "  "
       echo "  "
       exit 0;;
   *)
       echo ""
      ;; 
  esac
  done

#--------------------
# Test des variables
#--------------------

typeset -i FLAG=0

if [ "$TRACES" = "" ]
then
   echo "\n*** ERREUR :Variable TRACES non declaree\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------------
# Test du contenu des variables
#------------------------------

typeset -i FLAG=0

if [ ! -d $TRACES ]
then
   echo "\n*** ERREUR :Repertoire $TRACES inexistant\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------
# Recuperation de la date
#------------------------
typeset date=`date '+%y%m%d%H%M%S'`

#---------------------------
# Definition des variables :
#---------------------------

typeset FIC_SORTI=$TRACES/${date}.`basename $0`.log

#------------------------------------------
# Definition de l'en-tete du fichier traces
#------------------------------------------
typeset ENTETE=`uname -n`" - "`whoami`" - "`date`" - SCRIPT: "`basename $0`" - PID: "$$
echo "${ENTETE}" > $FIC_SORTI
echo "---------------------------------------------------------------------------------" >> $FIC_SORTI




#------------------------
# Demarrage
#------------------------
echo "Tar du systeme de fichier /opt/mqm " >> $FIC_SORTI
tar -zcvf /opt/bkp_mqm/opt.mqm.${date}.tar.z /opt/mqm/  >> $FIC_SORTI
CODE_RETOUR1=$?
echo "Tar du systeme de fichier /var/mqm "  >> $FIC_SORTI
tar -zcvf /opt/bkp_mqm/var.mqm.${date}.tar.z /var/mqm/  >> $FIC_SORTI
CODE_RETOUR=$?
case "$CODE_RETOUR" in
"0")
echo "" >> ${FIC_SORTI}
echo " ****  Normal - La sauvegarde des systemes de fichiers pour WebSphere MQ est terminée **** " >> ${FIC_SORTI}
echo " ****  Normal - La sauvegarde des systemes de fichiers pour WebSphere MQ est terminée **** "
echo ""
exit -0 
;;

*)
echo "" >> ${FIC_SORTI}
echo ""
echo " ****  Erreur  **** "
echo " ****  Erreur  **** " >> ${FIC_SORTI}
echo " ****  code retour $CODE_RETOUR  **** "
echo " ****  code retour $CODE_RETOUR  **** " >> ${FIC_SORTI}
echo " ****  La sauvegarde des systemes de fichiers pour WebSphere MQ a echoué  **** " 
echo " ****  La sauvegarde des systemes de fichiers pour WebSphere MQ a echoué  **** " >> ${FIC_SORTI}
exit -3 ;;
esac



