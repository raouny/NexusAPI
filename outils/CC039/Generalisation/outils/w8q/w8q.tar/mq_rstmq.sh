#!/bin/ksh
#  Description : Backup des systèmes de fichiers WebSphere MQ d'un serveur
#  LMD 04/10/2007 
# 
#-------------
# Parametres :
#-------------
# -v affiche la version
# -h help!

#---------------
# Codes retour :
#---------------
#  - 0 : Execution correcte - 
#  - 3 : Execution incorrecte - 

# typeset TRACES=logs
#--------------------
# Test des parametres
#--------------------
  for i 
  do
  case "$i" in
   -s*)
       FICTOT=$i
       FIC=`echo $FICTOT |cut -c 3- `
       ;; 
  
   -v*)
       echo "`basename $0` - LMD - Version 1.03  "
       exit 0 
      ;; 
   -h*)
       clear
       echo "                                   `tput smso` `basename $0` `tput rmso`"
       echo "                                  =================="
       echo " Ce shell permet de restaurer une archive comprimee des systèmes de fichers"
       echo " "
       echo "  /opt/mqm et /var/mqm d'un serveur"
       echo "  "
       echo " Il attend en parametre le nom qualifié de l'archive à restaurer. "
       echo " Il soit être exécuté depuis le compte root. "
       echo "  "
       exit 0;;
   *)
       echo ""
      ;; 
  esac
  done
#------------------------
#  Controle des  parametres obligatoires 
#------------------------
if [ -z "$FIC" ]
   then
     echo "Le nom de l'archive à restaurer un parametre obligatoire."
    exit -1
fi

#--------------------
# Test des variables
#--------------------

typeset -i FLAG=0

if [ "$TRACES" = "" ]
then
   echo "\n*** ERREUR :Variable TRACES non declaree\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------------
# Test du contenu des variables
#------------------------------

typeset -i FLAG=0

if [ ! -d $TRACES ]
then
   echo "\n*** ERREUR :Repertoire $TRACES inexistant\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------
# Recuperation de la date
#------------------------
typeset date=`date '+%y%m%d%H%M%S'`

#---------------------------
# Definition des variables :
#---------------------------

typeset FIC_SORTI=$TRACES/${date}.`basename $0`.log

#------------------------------------------
# Definition de l'en-tete du fichier traces
#------------------------------------------
typeset ENTETE=`uname -n`" - "`whoami`" - "`date`" - SCRIPT: "`basename $0`" - PID: "$$
echo "${ENTETE}" > $FIC_SORTI
echo "---------------------------------------------------------------------------------" >> $FIC_SORTI


#------------------------
# Demarrage
#------------------------
echo "Extraction de l'archive $FIC "
PWD=echo pwd >/dev/null
cd /
tar -xvf $FIC 
CODE_RETOUR=$?
cd -
case "$CODE_RETOUR" in
"0")
echo "" >> ${FIC_SORTI}
echo " ****  Normal - La restauration du systeme de fichiers a partir de $FIC est terminée **** " >> ${FIC_SORTI}
echo " ****  Normal - La restauration du systeme de fichiers a partir de $FIC est terminée **** "
echo ""
exit -0 
;;

*)
echo "" >> ${FIC_SORTI}
echo ""
echo " ****  Erreur  **** "
echo " ****  Erreur  **** " >> ${FIC_SORTI}
echo " ****  code retour $CODE_RETOUR  **** "
echo " ****  code retour $CODE_RETOUR  **** " >> ${FIC_SORTI}
echo " ****  La restauration du systeme de fichiers a partir de $FIC a echoué  **** " 
echo " ****  La restauration du systeme de fichiers a partir de $FIC a echoué  **** " >> ${FIC_SORTI}
exit -3 ;;
esac



