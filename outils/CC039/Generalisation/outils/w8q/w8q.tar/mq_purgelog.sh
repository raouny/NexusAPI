#!/bin/ksh
#  Description : purge des logs d'un GFA
#  LMD 27/09/2007 
# 
#-------------
# Parametres :
#-------------
# -m <Nom du GFA a demarrer>
# -v affiche la version
# -h help!

#---------------
# Codes retour :
#---------------
#  - 0 : Execution correcte - logs purgés
#  - 3 : Execution incorrecte - Erreur grave sur GFA ou pb de droits

# typeset TRACES=logs
#--------------------
# Test des parametres
#--------------------
typeset SRV
SRV=""
for i 
do
case "$i" in
 -m*)
     GFATOT=$i
     GFA=`echo $GFATOT |cut -c 3- `
    ;; 
 -v*)
     echo "`basename $0` - LMD - Version 1.02  "
     exit 0 
    ;; 
 -h*)
     clear
     echo "                                   `tput smso` `basename $0` `tput rmso`"
     echo "                                  =================="
     echo " Ce shell permet de purger les logs un GFA."
     echo " "
     echo "  Vous devez fournir les parametres suivants :"
     echo "  "
     echo "  `tput smso`-m`tput rmso`<nom_du GFA>"
     echo "  "
     echo "  (pas d'espace entre \"-m\" et le nom du GFA !)"
     echo "  "
     echo "  "
     exit 0;;

esac
done

#------------------------
#  Controle des  parametres obligatoires 
#------------------------
if [ -z "$GFA" ]
   then
     echo "Le nom du GFA a purger est un parametre obligatoire."
    exit -1
fi

#--------------------
# Test des variables
#--------------------

typeset -i FLAG=0

if [ "$TRACES" = "" ]
then
   echo "\n*** ERREUR :Variable TRACES non declaree\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------------
# Test du contenu des variables
#------------------------------

typeset -i FLAG=0

if [ ! -d $TRACES ]
then
   echo "\n*** ERREUR :Repertoire $TRACES inexistant\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------
# Recuperation de la date
#------------------------
typeset date=`date '+%y%m%d%H%M%S'`

#---------------------------
# Definition des variables :
#---------------------------

typeset FIC_SORTI=$TRACES/${date}.`basename $0`.log

#------------------------------------------
# Definition de l'en-tete du fichier traces
#------------------------------------------
typeset ENTETE=`uname -n`" - "`whoami`" - "`date`" - SCRIPT: "`basename $0`" - PID: "$$
echo "${ENTETE}" > $FIC_SORTI
echo "---------------------------------------------------------------------------------" >> $FIC_SORTI




#------------------------
# Demarrage
#------------------------
echo "Purge des logs du GFA $GFA "
echo ""
echo "Suppression des anciens gz"
rm -v /var/mqm/log/$GFA/active/*.gz > /dev/null
echo "Compaction des logs"
rcdmqimg -z -l -m $GFA -t all \*
echo "Gzip des logs inutiles"
$W8QOUTIL/cleanmqlogs -z $GFA 2> /tmp/cr_cleanmqlogs
CODE_RETOUR=$?
case "$CODE_RETOUR" in
"0")
echo "" >> ${FIC_SORTI}
cat /tmp/cr_cleanmqlogs >> ${FIC_SORTI}
cat /tmp/cr_cleanmqlogs
echo " ****  Normal - La purge des logs pour le GFA $GFA est terminée **** " >> ${FIC_SORTI}
echo " ****  Normal - La purge des logs pour le GFA $GFA est terminée **** "
echo ""
exit -0 
;;

*)
echo "" >> ${FIC_SORTI}
echo ""
echo " ****  Erreur  **** "
echo " ****  Erreur  **** " >> ${FIC_SORTI}
echo " ****  code retour $CODE_RETOUR  **** "
echo " ****  code retour $CODE_RETOUR  **** " >> ${FIC_SORTI}
cat /tmp/cr_cleanmqlogs
cat /tmp/cr_cleanmqlogs >> ${FIC_SORTI}
echo " ****  Impossible de purger les logs du GFA <<$GFA>>  **** " 
echo " ****  Impossible de purger les logs du GFA <<$GFA>>  **** " >> ${FIC_SORTI}
exit -3 ;;
esac



