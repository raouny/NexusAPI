#!/bin/ksh
#  Description : Affichage du statut d'un GFA
#  LMD 29/09/2007 
#
# Attention : ce sript suppose que la langue utilisée par le compte est le français (à cause du grep sur le résultat).
# 
#-------------
# Parametres :
#-------------
# -m <Nom du GFA a afficher>
# -v affiche la version
# -h help!

#---------------
# Codes retour :
#---------------
#  - 0 : Execution correcte - GFA fonctionnel
#  - 1 : Execution incorrecte - Pb d'environnement ou GFA arrete 
#  - 3 : Execution incorrecte - Erreur grave sur GFA 

# typeset TRACES=logs
#--------------------
# Test des parametres
#--------------------
typeset SRV
SRV=""
for i 
do
case "$i" in
 -m*)
     GFATOT=$i
     GFA=`echo $GFATOT |cut -c 3- `
    ;; 
 -v*)
     echo "`basename $0` - LMD - Version 1.03  "
     exit 0 
    ;; 
 -h*)
     clear
     echo "                                   `tput smso` `basename $0` `tput rmso`"
     echo "                                  =================="
     echo " Ce shell permet d'afficher le statut d'un GFA."
     echo " "
     echo "  Vous devez fournir les parametres suivants :"
     echo "  "
     echo "  `tput smso`-m`tput rmso`<nom_du GFA>"
     echo "  "
     echo "  (pas d'espace entre \"-m\" et le nom du GFA !)"
     echo "  "
     echo "  "
     echo "  La langue utilisee par le compte DOIT etre le francais."
     exit 0;;

esac
done

#------------------------
#  Controle des  parametres obligatoires 
#------------------------
if [ -z "$GFA" ]
   then
     echo "Le nom du GFA a afficher est un parametre obligatoire."
    exit -1
fi

#--------------------
# Test des variables
#--------------------

typeset -i FLAG=0

if [ "$TRACES" = "" ]
then
   echo "\n*** ERREUR :Variable TRACES non declaree\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------------
# Test du contenu des variables
#------------------------------

typeset -i FLAG=0

if [ ! -d $TRACES ]
then
   echo "\n*** ERREUR :Repertoire $TRACES inexistant\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------
# Recuperation de la date
#------------------------
typeset date=`date '+%y%m%d%H%M%S'`

#---------------------------
# Definition des variables :
#---------------------------

typeset FIC_SORTI=$TRACES/${date}.`basename $0`.log

#------------------------------------------
# Definition de l'en-tete du fichier traces
#------------------------------------------
typeset ENTETE=`uname -n`" - "`whoami`" - "`date`" - SCRIPT: "`basename $0`" - PID: "$$
echo "${ENTETE}" > $FIC_SORTI
echo "---------------------------------------------------------------------------------" >> $FIC_SORTI




#------------------------
# Demarrage
#------------------------
dspmq -m $GFA
CODE_RETOUR=$?
# echo "code retour : $CODE_RETOUR"

case "$CODE_RETOUR" in
"0")
# La commande s'est terminée normalement, on cherche le statut du GFA
var=$(dspmq -m $GFA)
# echo "variable statut \$var : $var"
# Recherche d'un pattern dans le resultat :
# "Mise" : GFA en cours d'arret
# "Arr"  : GFA arreté
# "En cours" : GFA en fonctionnement
#

# Test si GFA en cours d'arret
pattern="Mise"
# echo "recherche du pattern : $pattern ..."
dspmq -m $GFA | grep "$pattern" > /dev/null
# echo "code retour grep : $?"
if [ "$?" -eq "0" ]
then
	statut="est en cours d'arrêt"
	echo "Le GFA $GFA $statut" 
fi 

# Test si GFA arreté
pattern="Arr"
# echo "recherche du pattern : $pattern ..."
dspmq -m $GFA | grep "$pattern" > /dev/null
# echo "code retour grep : $?"
if [ "$?" -eq "0" ]
then
	statut="est arrêté"
	echo "Le GFA $GFA $statut" 
fi  

# Test si GFA ok
pattern="cours"
# echo "recherche du pattern : $pattern ..."
dspmq -m $GFA | grep "$pattern" > /dev/null
# echo "code retour grep : $?"
if [ "$?" -eq "0" ]
then
	statut="est en fonctionnement"
	echo "Le GFA $GFA $statut" 
fi  

# Sortie fichier
echo "" >> ${FIC_SORTI}
if [ "$statut" == "est en fonctionnement" ]
then 
echo " ****  Normal - Le GFA $GFA $statut **** " >> ${FIC_SORTI}
echo ""
exit -0 

else

echo " ****  Warning - "Le GFA $GFA $statut" **** " >> ${FIC_SORTI}
echo ""
exit -1 
fi

;;
16)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis dspmq **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis dspmq **** " >> ${FIC_SORTI}
echo " ****  Le GFA $GFA n'existe pas  **** " >> ${FIC_SORTI}
echo " ****  Echec d'affichage du GFA $GFA **** "
echo " ****  Echec d'affichage du GFA $GFA **** " >> ${FIC_SORTI}
echo ""
exit -3 

;;
23)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis dspmq **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis dspmq **** " >> ${FIC_SORTI}
echo " ****  Les logs du GFA $GFA ne sont pas disponibles  **** " >> ${FIC_SORTI}
echo " ****  Echec d'affichage du GFA $GFA **** "
echo " ****  Echec d'affichage du GFA $GFA **** " >> ${FIC_SORTI}
echo ""
exit -3 

;;
40)
echo "" >> ${FIC_SORTI}
echo " ****  Warning - code retour $CODE_RETOUR depuis dspmq **** "
echo " ****  Warning - Le GFA $GFA est arrete **** " >> ${FIC_SORTI}
echo ""
exit -1 

;;
49)
echo "" >> ${FIC_SORTI}
echo " ****  Warning - code retour $CODE_RETOUR depuis dspmq **** " >> ${FIC_SORTI}
echo " ****  Le GFA $GFA est en cours d'arret **** " >> ${FIC_SORTI}
echo ""
exit -2 

;;
72)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis dspmq **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis dspmq **** " >> ${FIC_SORTI}
echo " ****  Le nom du GFA $GFA est inconnu ou incorrect **** " >> ${FIC_SORTI}
echo " ****  Echec d'affichage du statut du GFA $GFA **** "
echo " ****  Echec d'affichage du statut **** " >> ${FIC_SORTI}
echo ""
exit -3 

;;
*)
echo "" >> ${FIC_SORTI}
echo ""
echo " ****  Erreur  **** "
echo " ****  Erreur  **** " >> ${FIC_SORTI}
echo " ****  code retour $CODE_RETOUR  **** "
echo " ****  code retour $CODE_RETOUR  **** " >> ${FIC_SORTI}
echo " ****  Affichage du statut du GFA <<$GFA>> impossible  **** " 
echo " ****  Affichage du statut du GFA <<$GFA>> impossible  **** " >> ${FIC_SORTI}
exit -3 ;;
esac



