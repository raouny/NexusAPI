#!/bin/ksh
#  Description : Affichage du statut d'une FA (nb de messages)
#  LMD 29/09/2007 
#
#
#-------------
# Parametres :
#-------------
# -m <Nom du GFA a afficher>
# -q <Nom de la FA a afficher>
# -v affiche la version
# -h help!

#---------------
# Codes retour :
#---------------
#  - 0 : Execution correcte - FA avec zéro messages
#  - 1 : Execution correcte - FA avec des messages
#  - 2 : Execution incorrecte - Pb d'environnement ou GFA arrete 
#  - 3 : Execution incorrecte - GFA ou FA inconnue

# typeset TRACES=logs
#--------------------
# Test des parametres
#--------------------
typeset SRV
SRV=""
for i 
do
case "$i" in
 -m*)
     GFATOT=$i
     GFA=`echo $GFATOT |cut -c 3- `
    ;; 
 -q*)
     FATOT=$i
     FA=`echo $FATOT |cut -c 3- `
    ;; 
 -v*)
     echo "`basename $0` - LMD - Version 1.03  "
     exit 0 
    ;; 
 -h*)
     clear
     echo "                                   `tput smso` `basename $0` `tput rmso`"
     echo "                                  =================="
     echo " Ce shell permet d'afficher le nombre de messages dans une FA."
     echo " "
     echo "  Vous devez fournir les parametres suivants :"
     echo "  "
     echo "  `tput smso`-m`tput rmso`<nom_du GFA>"
     echo "  `tput smso`-q`tput rmso`<nom_de la FA>"
     echo "  "
     echo "  (pas d'espace entre \"-m\" et le nom du GFA, ni entre le -q et le nom de la FA !)"
     echo "  "
     echo "  "
     exit 0;;

esac
done

#------------------------
#  Controle des  parametres obligatoires 
#------------------------
if [ -z "$GFA" -o -z "$FA" ]
   then
     echo "Le nom du GFA et le nom de la FA sont des parametres obligatoires."
    exit -1
fi

#--------------------
# Test des variables
#--------------------

typeset -i FLAG=0

if [ "$TRACES" = "" ]
then
   echo "\n*** ERREUR :Variable TRACES non declaree\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------------
# Test du contenu des variables
#------------------------------

typeset -i FLAG=0

if [ ! -d $TRACES ]
then
   echo "\n*** ERREUR :Repertoire $TRACES inexistant\n"
   typeset -i FLAG=1
fi

if [ "$FLAG" -eq 1 ]
then
   exit -1
fi

#------------------------
# Recuperation de la date
#------------------------
typeset date=`date '+%y%m%d%H%M%S'`

#---------------------------
# Definition des variables :
#---------------------------

typeset FIC_SORTI=$TRACES/${date}.`basename $0`.log

#------------------------------------------
# Definition de l'en-tete du fichier traces
#------------------------------------------
typeset ENTETE=`uname -n`" - "`whoami`" - "`date`" - SCRIPT: "`basename $0`" - PID: "$$
echo "${ENTETE}" > $FIC_SORTI
echo "---------------------------------------------------------------------------------" >> $FIC_SORTI


#------------------------
# Demarrage du script
#------------------------
echo "Recherche du nombre de messages de la FA $FA sur le GFA $GFA"
echo "display qlocal($FA) curdepth" | runmqsc $GFA > /dev/null
CODE_RETOUR=$?
# echo "code retour : $CODE_RETOUR"

case "$CODE_RETOUR" in
"0")
# La commande s'est terminée normalement, on cherche le statut du GFA
# on sort le résultat du runmqsc dans un fichier temp :
# 
echo "display qlocal($FA) curdepth" | runmqsc $GFA | grep "CURDEPTH" >/tmp/MQ_dspfa_tmp
# Recherche du resultat : le nombre de messages commence à la 13ième position
# et se termine avant la paranthèse fermante
#
# nbmessT : chaine de caractère commencçant au premier caractère du nb de message
nbmessT=$(cut -c13- /tmp/MQ_dspfa_tmp)
# calcul de la position du premier caractère blanc (derrière la parenthèse fermante)
premierBlanc=$(expr index "$nbmessT" " ")
# Suppression de la parenthèse fermante pour récupérer un numérique
dernierNum=$(expr $premierBlanc - 2)
# echo "Nombre de messages : $nbmessT, Premier blanc : $premierBlanc, dernierNum : $dernierNum"
nbmess=$(expr substr $nbmessT 1 $dernierNum)


# Sortie fichier
echo "" >> ${FIC_SORTI}
if [ "$nbmess" == "0" ]
then 
echo "Il n'y a aucun message dans la FA $FA du GFA $GFA."
echo " ****  Normal - Il n'y a aucun message dans la FA $FA du GFA $GFA. **** " >> ${FIC_SORTI}
echo ""
exit -0 

else
echo "Il y a $nbmess messages dans la FA $FA du GFA $GFA."
echo " ****  Warning - Il y a $nbmess messages dans la FA $FA du GFA $GFA. **** " >> ${FIC_SORTI}
echo ""
exit -1 
fi

;;
10)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis runmqsc **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis runmqsc **** " >> ${FIC_SORTI}
echo " ****  La FA $FA ne semble pas exister dans le GFA $GFA **** " >> ${FIC_SORTI}
echo ""
exit -2 

;;
20)
echo "" >> ${FIC_SORTI}
echo " ****  Erreur - code retour $CODE_RETOUR depuis runmqsc **** "
echo " ****  Erreur - code retour $CODE_RETOUR depuis runmqsc **** " >> ${FIC_SORTI}
echo " ****  Le GFA $GFA ne semble pas en fonctionnement  **** " >> ${FIC_SORTI}
echo ""
exit -3 


;;
*)
echo "" >> ${FIC_SORTI}
echo ""
echo " ****  Erreur  **** "
echo " ****  Erreur  **** " >> ${FIC_SORTI}
echo " ****  code retour $CODE_RETOUR  **** "
echo " ****  code retour $CODE_RETOUR  **** " >> ${FIC_SORTI}
echo " ****  Affichage de la FA $FA du GFA $GFA impossible  **** " 
echo " ****  Affichage de la FA $FA du GFA $GFA impossible  **** " >> ${FIC_SORTI}
exit -3 ;;
esac



