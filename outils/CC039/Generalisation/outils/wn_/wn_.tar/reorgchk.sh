#!/bin/ksh

# Fonctions a appeler

# Entete du Script
Entete()
{
echo " ********************************************************************************"
echo " Reorganisation de la base db2 d'une instance d'annuaire ITDS "
echo " reorgchk.sh"
echo " Cible : ITDS 6.2"
echo " "
echo " Parametres :  Aucun "
echo " "
echo " Exemple de commande :"
echo " \$WN_OUTIL/reorgchk.sh "
echo " "
echo " Version 1.0 du 23/04/10 EB"
echo " ********************************************************************************"
echo " "
}

# ***************************************
# MAIN
# ***************************************

Entete

echo "Execution de la commande : $0 $*"
echo " "
echo "Resultat :"
echo " "

# Execution du script
# -------------------

# Reorganisation de la base DB2
echo ""
echo "Reorganisation de la base DB2"
echo ""
db2 connect to $IDS_LDAP_INSTANCE
CodeR=$?
if [ "$CodeR" = "0" ]
	then
           echo " "
           echo "SUCCES Fin de connexion a la base DB2"
           db2 reorgchk update statistics on table all
	   CodeR=$?
	   if [ "$CodeR" = "0" ]
		then
		 echo " "
           	 echo "SUCCES Fin de reorganisation de la base DB2"
		 db2 terminate
		 if [ "$CodeR" = "0" ]
			then
			echo " "
           	 	echo "SUCCES Sortie du script en sortie 0"
		 else
		 	echo " "
           		echo "PROBLEME : Sortie du script en CR3"
           		exit 3	
		 fi
	  else
		echo " "
           	echo "ECHEC lors de la reorganisation de la base DB2"
		echo "Sortie du script en CR3"
           	exit 3
	  fi

else
    echo " "
    echo "ECHEC de connexion a la base DB2"
    echo "Sortie du script en CR3"
    exit 3
fi




