#!/bin/ksh

# Fonctions a appeler

# Entete du Script
Entete()
{
echo " ********************************************************************************"
echo " Arret/Redemarrage d'une instance d'annuaire ITDS "
echo " Start_Stop_ITDS_Instance.sh"
echo " Cible : ITDS 6.2"
echo " "
echo " Parametres :  -i instance -a action"
echo " avec action ="
echo " start : demarrage de l'instance"
echo " stop : arret de l'instance"
echo " "
echo " Exemple de commande :"
echo " \$WN_OUTIL/Start_Stop_ITDS_Instance.sh -i idsldap -a stop"
echo " "
echo " Version 1.1 du 07/06/10 EB"
echo " ********************************************************************************"
echo " "
}


# Usage du script
Usage()
{
  echo " "
  echo "Utilisation du script :"
  echo "-----------------------"
  echo "--> Login : Ce sript doit etre lance avec le compte d'instance itds"
  echo "--> Usage : \$WN_OUTIL/Start_Stop_ITDS_Instance.sh -i instance -a start/stop"
  echo "-----------------------"
  echo " "
}

# ***************************************
# MAIN
# ***************************************

Entete

echo "Execution de la commande : $0 $*"
echo " "
echo "Resultat :"
echo " "

# Affectation des arguments
# -------------------------
ARGSS="$*"
while getopts "i:a:" OPT
 do
 case ${OPT} in
        i) INSTANCE="${OPTARG}" ;;
        a) ACTION="${OPTARG}" ;;
        *) echo "Erreur : Option non valide "
            Usage
            echo "Sortie du script en CR 3"
            exit 3 ;;
 esac
done


# Test des arguments
# -------------------
if [ "$INSTANCE" = "" ]
then
 echo "Erreur : L'option -i n'a pas ete specifiee "
 echo "Le nom de l'instance est obligatoire "
 Usage
 echo "Sortie du script en CR 3"
 exit 3
fi

if [ "$ACTION" = "" ]
then
 echo "Erreur : L'option -a n'a pas ete specifiee "
 echo "L'action start ou stop est obligatoire "
 Usage
 echo "Sortie du script en CR 3"
 exit 3
else
 if [ "$ACTION" != "start" -a "$ACTION" != "stop" ]
 then
  echo "Erreur : L'option -a ne peut prendre comme valeur que start ou stop"
  Usage
  echo "Sortie du script en CR 3"
  exit 3
 fi
fi

# Execution du script
# -------------------
case $ACTION in
  start)

# Condition d'execution du script avec le compte d'instance itds

     user=`whoami`
     if [ $user != $INSTANCE ]
      then
      echo "Vous devez etre connecte via le compte d'instance \"$INSTANCE\" pour executer ce script"
      echo "Sortie du script en CR 3"
      exit 3
     else
         /opt/ibm/ldap/V6.2/sbin/idsslapd -I $INSTANCE
         CodeR=$?
         if [ "$CodeR" = "0" ]
          then
          /opt/ibm/ldap/V6.2/sbin/ibmdiradm -I $INSTANCE
	  CodeR=$?
        	if [ "$CodeR" = "0" ]
        	then
	 	 echo " "
		 echo " SUCCES lors du demarrage de l'instance LDAP $INSTANCE"
		 # Pause de 10 secondes pour laisser le temps à l'instance de bien démarrer
		 sleep 10	
		 echo ""
		 echo " Execution d'une requete LDAP de test sur l'annuaire:"
		 	if [ $INSTANCE = "itds4801" ]
		 	then
		 	 ENVIRONNEMENT="travail"
	   	 	else
		 	 ENVIRONNEMENT="exploitation"
		 	fi
			SUFFIXE=ou=application,dc=$ENVIRONNEMENT,dc=habilinet,dc=courrier,dc=intra,dc=laposte,dc=fr
			
			requete_test=`echo $REP_BIN/idsldapsearch -h $LDAP_SERVEUR -p $LDAP_PORT -K $LDAP_SSL_CLE -D $LDAP_DN_ADMIN -w $LDAP_MDP_ADMIN -s one -b $SUFFIXE -L '(objectclass=lpApplication)' dn lpAPPnom`
			echo $requete_test
$LDAP_REP_BIN/idsldapsearch -h $LDAP_SERVEUR -p $LDAP_PORT -K $LDAP_SSL_CLE -D $LDAP_DN_ADMIN -w $LDAP_MDP_ADMIN -s one -b $SUFFIXE -L '(objectclass=lpApplication)' dn ldAPPnom
		 	CodeR=$?
			echo "Le code retour de la requete LDAP est: $CodeR"
		 	if [ "$CodeR" = "0" ]
	          	 then
		  	  echo " SUCCES lors de l'execution de la requete LDAP de test "
		  	  echo " L'instance $INSTANCE est correctement demarree"
		  	  exit 0
		 	else 
          	  	  echo " ECHEC lors de l'execution de la requete LDAP de test "
		  	  echo " L'instance $INSTANCE n'est pas correctement demarree"
		 	fi
	        else
		 echo " "
                 echo " PROBLEME lors du demarrage de l'instance $INSTANCE"
                 echo " Sortie du script en CR 3"
                 exit 3
		fi
        else
         	 echo " "
         	 echo " PROBLEME lors du demarrage de l'instance $INSTANCE"
		 echo " Sortie du script en CR 3"
         	 exit 3
	 fi
     fi
;;
  stop)

# Condition d'execution du script avec le compte d'instance itds
       
      user=`whoami`
      if [ $user != $INSTANCE ]
       then
        echo "Vous devez etre connecte via le compte d'instance \"$INSTANCE\" pour executer ce script"
        echo "Sortie du script en CR 3"
        exit 3
     else
        /opt/ibm/ldap/V6.2/sbin/idsslapd -I $INSTANCE -k
        CodeR=$?
        if [ "$CodeR" = "0" ]
        then
	 /opt/ibm/ldap/V6.2/sbin/ibmdiradm -I $INSTANCE -k
	 CodeR=$?
		if [ "$CodeR" = "0" ]
                then
         	 echo " "
         	 echo "SUCCES : Sortie du script en CR 0"
         	 exit 0
		else
		 echo " "
                 echo "PROBLEME : Sortie du script en CR 3"
                 exit 3
		fi
        else
         	 echo " "
         	 echo "PROBLEME : Sortie du script en CR 3"
         	 exit 3
        fi
     fi
;;
esac

