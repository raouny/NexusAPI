#!/bin/ksh

# Fonctions a appeler

# Entete du Script
Entete()
{
echo " ********************************************************************************"
echo " Sauvegarde de la Base DB2 + configuration d'une instance d'annuaire ITDS "
echo " itds_backupdb.sh"
echo " Cible : ITDS 6.2"
echo " "
echo " Parametres : -i instance -d destination -t type"
echo " avec type ="
echo " full_offline : Sauvegarde totale a froid base db2 + fichiers de conf"
echo " full_online :  Sauvegarde totale a chaud base db2 + fichiers de conf"
echo " "
echo " Exemple de commande :"
echo " \$WN_OUTIL/itds_backupdb.sh -i idsldap -d /itdssave -t full_offline"
echo " "
echo " Version 1.0 du 19/10/09 EB"
echo " ********************************************************************************"
echo " "
}


# Usage du script
Usage()
{
  echo " "
  echo "Utilisation du script :"
  echo "-----------------------"
  echo "--> Login : Ce sript doit etre lance avec le compte proprietaire de l'instance DB2 "
  echo "--> Usage : \$WN_OUTIL/itds_backupdb.sh -i instance -d rep_destination -t type_sauvegarde"
  echo "-----------------------"
  echo " "
}

# Creation de l'arborescence de depot de la sauvegarde
creat_directory_save() {

if [ ! -d $1 ] ; then
	mkdir -p $1
	if [ $? -ne 0 ] ; then
		echo "Probleme lors de la creation du repertoire : " $1
		exit 3
	fi

	chmod 755 $1
	if [ $? -ne 0 ]; then
		echo "Probleme lors de l'affectation des droits du repertoire : " $1
		exit 3
	fi
fi

} # Fin fonction creation arborescence


# ***************************************
# MAIN
# ***************************************

Entete

echo "Execution de la commande : $0 $*"
echo " "
echo "Resultat :"
echo " "

# Affectation des arguments
# -------------------------
ARGSS="$*"
while getopts "i:d:t:" OPT
 do
 case ${OPT} in
	i) INSTANCE="${OPTARG}" ;;
        d) DESTINATION="${OPTARG}" ;;
        t) TYPE="${OPTARG}" ;;
	*) echo "Erreur : Option non valide "
            Usage
            echo "Sortie du script en CR 3"
            exit 3 ;;
 esac
done


# Test des arguments
# -------------------
if [ "$INSTANCE" = "" ]
then
 echo "Erreur : L'option -i n'a pas ete specifiee "
 echo "Le nom de l'instance est obligatoire "
 Usage
 echo "Sortie du script en CR 3"
 exit 3
fi

if [ "$DESTINATION" = "" ]
then
 echo "Erreur : L'option -d n'a pas ete specifiee "
 echo "Le repertoire de destination de la sauvegarde est obligatoire "
 Usage
 echo "Sortie du script en CR 3"
 exit 3
fi

if [ "$TYPE" = "" ]
then
 echo "Erreur : L'option -t n'a pas ete specifiee "
 echo "Le type de sauvegarde est obligatoire "
 Usage
 echo "Sortie du script en CR 3"
 exit 3
else
if [ "$TYPE" != "full_offline" -a "$TYPE" != "full_online" ]
 then
  echo "Erreur : L'option -t ne peut prendre comme valeur que full_offline ou full_online"
  Usage
  echo "Sortie du script en CR 3"
  exit 3
 fi
fi

# Execution du script
# -------------------
case $TYPE in
  full_offline)

	# Verification d'execution de la commande avec le compte d'instance DB2        
	user=`whoami`
	if [ $user != $INSTANCE ]
	 then
	 echo "Vous devez etre connecte via le compte d'instance DB2 \"$INSTANCEi\" pour executer ce script"
	 echo "Sortie du script en CR 3"
	 exit 3
	else
	 echo " Debut de la sauvegarde le `date +%m%b%Y%Hh%M`"
	 creat_directory_save $DESTINATION/$INSTANCE/full_offline	
         /opt/ibm/ldap/V6.2/sbin/idsdbback -n -I $INSTANCE -k $DESTINATION/$INSTANCE/full_offline 
         CodeR=$?
          if [ "$CodeR" = "0" ]
          then
	   echo " "
           echo "SUCCES Fin de la creation de l'image le `date +%m%b%Y%Hh%M` sans erreur" 
	   echo "Sortie du script en CR 0"
           exit 0
	  else
	   echo " "
           echo "PROBLEME : Sortie du script en CR 3"
           exit 3
	  fi
        fi
;;
 full_online)

        user=`whoami`
        if [ $user != $INSTANCE ]
         then
         echo "Vous devez etre connecte via le compte d'instance DB2 \"$INSTANCE\" pour executer ce script" 
         echo "Sortie du script en CR 3"
         exit 3
        else
         creat_directory_save $DESTINATION/$INSTANCE/full_online
	 creat_directory_save $DESTINATION/$INSTANCE/full_online/inactive_archive_log
	 echo " Debut de la sauvegarde le `date +%m%b%Y%Hh%M`"
	 /opt/ibm/ldap/V6.2/sbin/idsdbback -n -I $INSTANCE -u -k $DESTINATION/$INSTANCE/full_online -a $DESTINATION/$INSTANCE/full_online/inactive_archive_log  
         
	  CodeR=$?
          if [ "$CodeR" = "0" ]
          then
           echo " "
           echo "SUCCES Fin de la creation de l'image le `date +%m%b%Y%Hh%M` sans erreur"
	   echo "Sortie du script en CR 0"
           exit 0
          else
           echo " "
           echo "PROBLEME : Sortie du script en CR 3"
           exit 3
          fi
        fi
;;
esac

