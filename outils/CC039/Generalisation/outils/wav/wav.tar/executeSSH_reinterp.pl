#!/usr/bin/perl
#############################################################
# Nom : executeSSH_reinterp.pl
# Langage : Perl
# Auteur : Guillaume MICHON 28/04/2010 (v 1.0 - Création initiale)
# Modif. :
#
# Description : 
#     Script d'exécution à distance via SSH
#     Ce script permet la réinterprétation de variables d'environnement
#     sur le compte cible d'exécution
#
# Utilisation : Cf usage()
#
#############################################################


sub usage {
    print "Script de reinterpretation de variables d'environnement a distance\n";
    print "Utilisation :\n   $0 -d <car> <cmd>\n";
    print "      <cmd> :    Commande a lancer\n";
    print "      -d <car> : <car> indique le caractère spécifique qu'il faut remplacer par un '$' dans <cmd>\n";
    print "                 pour permettre l'interpretation des variables sur la cible.\n";
    exit 2;
}


# Analyse des paramètres
$ligne = '. $HOME/.profile ; ';
while ($arg = shift(@ARGV)) {
    if ($arg eq "-d") {
        $delim = shift(@ARGV);
    }
    else {
        push(@commande, $arg);
    }
}

&usage if ($delim =~ /^\s*$/);
&usage if ("@commande" =~ /^\s*$/);


# Exécution
foreach $arg (@commande) {
    $arg =~ s/$delim/\$/g;
    $ligne .= "$arg ";
}
exec $ligne;
exit 3;


