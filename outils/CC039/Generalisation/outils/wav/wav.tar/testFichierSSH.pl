#!/usr/bin/perl
#############################################################
# Nom : testFichierSSH.pl
# Langage : Perl
# Auteur : Guillaume MICHON 05/05/2010 (v 1.0 - Création initiale)
# Modif. :
#
# Description : 
#     Script de test de présence de fichier à distance via SSH
#
# Utilisation : Cf usage()
#
#############################################################


### Constantes
$DIRNAME = ".";
if ($0 =~ /^(.*)\/[^\/]+$/) {
    $DIRNAME = $1;
}
$DEFAUT_TIMEOUT = 60;
$EXIT_ERREUR = 2;
$EXECUTE_SSH = "$DIRNAME/executeSSH.py";
$TEST_FICHIER_LOCAL = "\$WAVOUTIL/testFichierSSH_local.sh";


sub usage {
    print "Script de test de presence de fichier a distance via SSH\n";
    print "Utilisation :\n   $0 -s <serveur> -f <fichier> [-u <compte>] [-d <delim>|-E] [-t <timeout>]\n";
    print "      -s <serveur> : Serveur sur lequel tester la presence du fichier\n";
    print "      -f <fichier> : Chemin absolu du fichier dont il faut tester la presence\n";
    print "    Parametres facultatifs :\n";
    print "      -u <compte>  : Compte avec lequel rechercher le fichier (défaut : root)\n";
    print "      -d <delim>   : Caractere remplacant '\$' pour les variables a interpreter par le compte cible\n";
    print "      -t <timeout> : Temps d'attente maximal de fin d'execution en secondes (defaut : $DEFAUT_TIMEOUT)\n";
    print "      -E           : Conserve l'environnement du compte ordonnancement sur la cible (defaut : non)\n\n";
    exit 2;
}


### Analyse des paramètres
while ($arg = shift(@ARGV)) {
    if ($arg eq "-s") {
        $serveur = shift(@ARGV);
        &usage() if ($serveur =~ /^-/);
    }
    elsif ($arg eq "-f") {
        $fichier = shift(@ARGV);
        &usage() if ($fichier =~ /^-/);
    }
    elsif ($arg eq "-u") {
        $compte = shift(@ARGV);
        &usage() if ($compte =~ /^-/);
    }
    elsif ($arg eq "-d") {
        $delim = shift(@ARGV);
        &usage() if ($delim =~ /^-/);
    }
    elsif ($arg eq "-t") {
        $timeout = shift(@ARGV);
        &usage if ($timeout !~ /^[0-9]+$/);
    }
    elsif ($arg eq "-E") {
        $conserve_env = 1;
    }
    else {
        &usage();
    }
}
&usage() unless ($serveur && $fichier);
$timeout = $DEFAUT_TIMEOUT unless($timeout);
$compte = "root" unless ($compte);

if ($conserve_env && $delim) {
    print "Erreur: -E et -d ne peuvent pas etre utilises en meme temps.\n\n";
    &usage();
}


### Construction de la commande à exécuter
@cmd_principale = ($EXECUTE_SSH, "-s", $serveur, "-u", $compte, "-t", $timeout);
push(@cmd_principale, "-E") if ($conserve_env);
push(@cmd_principale, "-d", $delim) if ($delim !~ /^$/);
push(@cmd_principale, "-c", "$TEST_FICHIER_LOCAL $fichier");

# Exécution dans un processus fils pour à la fois bénéficier de l'absence d'interprétation
# par le shell (utilisation de exec() ), et pouvoir collecter la sortie standard
if (defined($pid = open(FILS, "-|"))) {
    if ($pid) { # Père
        while ($ligne = <FILS>) {
            print $ligne;
            if ($ligne =~ /^OK:.*est present\s*$/) {
                $retour = 0; $trouve = 1;
            }
            if ($ligne =~ /^KO:.*est absent\s*$/) {
                $retour = 1; $trouve = 1;
            }
        }
        close(FILS);
        exit $retour if ($trouve);
        print "Erreur d'obtention d'information de presence du fichier\n";
        exit 3;
    }
    else { # Fils
        exec(@cmd_principale);
        print "Erreur au lancement du script de connexion SSH: $!\n";
        exit 3;
    }
}
else {
    print "Erreur : fork impossible: $!\n";
    exit 3;
}

