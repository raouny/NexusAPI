#!/usr/bin/python
# -*- coding: utf-8 -*-

#############################################################
# Nom : Log.py
# Langage : Python 2.4
# Auteur : Guillaume MICHON 12/08/2009 (v 1.0 - Création initiale)
# Modif. : 
#
# Description : 
#     Module de logging pour SE 2.0 en bulle internet
#
#############################################################

import logging, logging.handlers
from types import *

import sys


### Constantes ###
ERREUR_OK = 0
ERREUR_WARNING = 4
ERREUR_ARG = 5
ERREUR_FATALE = 6

DEBUG = logging.DEBUG
INFO = logging.INFO
WARNING = logging.WARNING
ERROR = logging.ERROR
CRITICAL = logging.CRITICAL


dict_niveau_log = {
    "debug" : DEBUG,
    "info" : INFO,
    "warning" : WARNING,
    "error" : ERROR,
    "critical" : CRITICAL
}


class SE2_LogException(Exception):
    pass

class NullHandler(logging.Handler):
    """
    Handler (au sens du module logging) ne faisant rien.
    Cette classe est ici pour éviter des messages d'avertissement sur l'absence de handler
    """
    def emit(self, record):
        pass

class Log:
    """
    Objet principal à instancier pour bénéficier d'un mécanisme de journalisation.
    """
    def __init__(self, niveau_log, fichier_log, format_log, taille_rotation, nombre_rotation, obligatoire, *args, **kw):
        """
        Constructeur.
        Paramètres :
            * niveau_log : Niveau minimum de log à enregistrer dans les journaux
            * fichier_log : Chemin complet du fichier de log
            * format_log : Chaîne de formattage des lignes de log (cf logging.Formatter)
            * taille_rotation : Taille en octets avant rotation
            * nombre_rotation : Nombre d'anciens fichiers de log conservés
            * obligatoire : Booléen. Si vrai, toute écriture de log non satisfaite remonte en exception
        """
        self.__liste_canal = []
        self.__dict_canal = {}
        self.__niveau = dict_niveau_log.get(niveau_log, dict_niveau_log["debug"])
        self.__fichier = fichier_log
        self.__rotation = taille_rotation
        self.__nb_rotation = nombre_rotation
        self.__obligatoire = obligatoire
        self.__format = logging.Formatter(format_log)


    def getCanal(self, canal):
        """
        Initialise un canal de logging et retourne un objet dédié
        loggant tous les messages dans ce canal
        Paramètres :
            * canal : Canal de journalisation (ex : msbi.generateurNum)
        """
        try:
            retour = self.__dict_canal[canal]
        except KeyError:
            retour = CanalLog(self, canal)
            retour = self.__dict_canal[canal] = retour
        return retour

        
    def getLogger(self, canal):
        """
        Retourne une instance d'un objet permettant de logger
        avec le canal indiqué. L'objet en question contient
        des méthodes debug(), info(), warning(), error() et critical().
        Paramètres :
            * canal : Nom hiérarchical de l'élément journalisant (ex : msbi.generateurNum)
        Retourne : Un objet logging.Logger
        """
        logger = logging.getLogger(canal)
        # Configuration du logger s'il n'a jamais été appelé
        if canal not in self.__liste_canal:
            self.__liste_canal.append(canal)
            logger.addHandler(NullHandler())
            try:
                handler = logging.handlers.RotatingFileHandler(
                    self.__fichier,
                    maxBytes = self.__rotation,
                    backupCount = self.__nb_rotation
                )
                handler.setFormatter(self.__format)
                handler.setLevel(self.__niveau)
                logger.setLevel(self.__niveau)
                logger.addHandler(handler)
            except IOError, e:
                if self.__obligatoire:
                    raise SE2_LogException("E02_000: Impossible d'initialiser le log : " + " ".join([str(a) for a in e.args]))
        return logger


    def log(self, niveau, canal, message, *args, **kw):
        """
        Journalise un message dans le fichier de log.
        Paramètres :
            * niveau : Niveau de log (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            * canal : Canal à utiliser (ex : msbi.generateurNum)
            * message : Message à journaliser
            * args, kw : Arguments utilisés pour un printf sur le message
        Retourne : Rien
        """
        # Prétraitement pour éviter les problèmes d'encodage
        ligne = []
        kw_ok = {}
        for m in [message] + list(args):
            if isinstance(m, UnicodeType):
                m = m.encode('utf-8')
            ligne.append(m)
        message = ligne.pop(0)
        for clef, valeur in kw.items():
            if isinstance(valeur, UnicodeType):
                valeur = valeur.encode('utf-8')
            kw_ok[clef] = valeur
        try:
            logger = self.getLogger(canal)
            logger.log(niveau, message, *ligne, **kw_ok)
        except IOError, e:
            if self.__obligatoire:
                raise SE2_LogException("E02_010: Impossible de journaliser un message : " + " ".join([str(a) for a in e.args]))
    def debug(self, canal, message, *args, **kw):
        self.log(DEBUG, canal, message, *args, **kw)
    def info(self, canal, message, *args, **kw):
        self.log(INFO, canal, message, *args, **kw)
    def warning(self, canal, message, *args, **kw):
        self.log(WARNING, canal, message, *args, **kw)
    def error(self, canal, message, *args, **kw):
        self.log(ERROR, canal, message, *args, **kw)
    def critical(self, canal, message, *args, **kw):
        self.log(CRITICAL, canal, message, *args, **kw)

    def exception(self, canal, message, *args, **kw):
        """
        Journalise un message avec la trace d'exécution (à appeler d'un except:)
        Paramètres : Habituels
        Retourne : Rien
        """
        try:
            logger = self.getLogger(canal)
            logger.exception(message, *args, **kw)
        except IOError, e:
            if self.__obligatoire:
                raise SE2_LogException("E02_020: Impossible de journaliser un message : " + " ".join([str(a) for a in e.args]))
        

    def genererErreur(self, niveau, canal, message):
        """
        Génère une erreur sur la sortie d'erreur et dans le log. Quitte si l'erreur est fatale.
        Paramètres :
            * niveau : A choisir parmi les ERREUR_*
            * message : Message d'erreur explicite pour l'appelant
            * canal : Générateur de l'erreur
        """
        if not isinstance(message, StringTypes):
            message = repr(message)
        sys.stderr.write(message + "\n")
        if niveau in (ERREUR_ARG, ERREUR_FATALE):
            try:
                self.critical(canal, message)
            except:
                pass
            sys.exit(niveau)
        else:
            self.error(canal, message)



class CanalLog:
    """
    Classe de journalisation dédiée à un canal particulier.
    Permet de ne pas devoir répéter systématiquement le canal
    """
    def __init__(self, log, canal):
        self.__canal = canal
        self.__log = log

    def log(self, niveau, message, *args, **kw):
        self.__log.log(niveau, self.__canal, message, *args, **kw)
    def debug(self, message, *args, **kw):
        self.log(DEBUG, message, *args, **kw)
    def info(self, message, *args, **kw):
        self.log(INFO, message, *args, **kw)
    def warning(self, message, *args, **kw):
        self.log(WARNING, message, *args, **kw)
    def error(self, message, *args, **kw):
        self.log(ERROR, message, *args, **kw)
    def critical(self, message, *args, **kw):
        self.log(CRITICAL, message, *args, **kw)
    def exception(self, message, *args, **kw):
        self.__log.exception(self.__canal, message, *args, **kw)
    
    def genererErreur(self, niveau, message):
        self.__log.genererErreur(niveau, self.__canal, message)




