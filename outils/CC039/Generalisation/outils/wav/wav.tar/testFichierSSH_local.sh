#!/bin/sh
#############################################################
# Nom : testFichierSSH_local.sh
# Langage : Perl
# Auteur : Guillaume MICHON 30/04/2010 (v 1.0 - Création initiale)
# Modif. :
#
# Description : 
#     Script de test de présence de fichier à distance via SSH - partie locale
#     Ce script très simple permet de déporter la ligne de commande un peu
#     complexe du côté du serveur qui l'exécute, et évite ainsi les éventuelles
#     interprétations au cours des différentes étapes de l'exécution SSH.
#
# Utilisation : testFichierSSH_local.sh <nom fichier>
# Retour : "OK|KO: <nom fichier> est present|absent"
# Code retour : 0 dans tous les cas (OK ou KO), 1 si erreur
#
#############################################################


if [ $# -ne 1 ] ; then
    echo "Test de presence de fichier a distance via SSH - partie locale"
    echo "Utilisation :"
    echo "  $0 <nom fichier>"
    echo "  -> OK: <nom fichier> est present"
    echo "  -> KO: <nom fichier> est absent"
    exit 2
fi

if [ -e "$1" ] ; then
    echo "OK: $1 est present"
    exit 0
else
    echo "KO: $1 est absent"
    exit 0
fi

