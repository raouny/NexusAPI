#!/usr/bin/python
# -*- coding: utf-8 -*-

#############################################################
# Nom : executeSSH.py
# Langage : Python 2.4
# Auteur : Guillaume MICHON 26/04/2010 (v 1.0 - Création initiale)
# Modif. : Guillaume MICHON 01/08/2011 (v 1.1 - Ajout option -w)
# Modif. : Guillaume MICHON 20/09/2011 (v 1.2 - Support Ubuntu 10)
#
# Description : 
#     Script d'exécution à distance via SSH
#
#############################################################

import os, signal, time, select
from subprocess import *
from threading import Thread, RLock
from datetime import datetime
from optparse import OptionParser
from exceptions import SystemExit
from Log import *

LOG_FICHIER = "./executeSSH.log"
LOG_FORMAT = "%(asctime)s - %(levelname)s - %(name)s [%(process)s] - %(message)s"
LOG_TAILLE = 10 * 1024 * 1024 # octets
LOG_ROTATION = 5
LOG_NIVEAU = DEBUG # cf Log.py

SSH_COMPTE = "ordonnancement"
SSH_SUFFIXE = "-exploit"
SSH_SCRIPT_REBUILD = "$WAVOUTIL/executeSSH_reinterp.pl"


class SSHTimeoutException(Exception): pass


class ExecutionSSH:
    def __init__(self, *args, **kw):
        try:
            self.log = Log(
                niveau_log = LOG_NIVEAU,
                fichier_log = LOG_FICHIER,
                format_log = LOG_FORMAT,
                taille_rotation = LOG_TAILLE,
                nombre_rotation = LOG_ROTATION,
                obligatoire = True
            ).getCanal("ordonnancement")
    
            self.log.info("##### executeSSH.py appele avec parametres :" + repr(sys.argv))
            # Initialisation des variables
            self.dict_arguments = self.verifierArguments(*self.analyserArguments())
            self.timeout = self.dict_arguments["timeout"]
            self.serveur = self.dict_arguments["serveur"] + SSH_SUFFIXE
    
            # Vérifications avant exécution
            if not CacheSudo.getInstance(self.log, 60).verifierAutorisationDistante("ALL", SSH_COMPTE, self.serveur, sudo_local=None):
                raise Exception("Le compte %s n'a pas le droit de faire un sudo ALL sur %s" % (repr(SSH_COMPTE), repr(serveur)))
    
            self.realiserExecution()
        except SSHTimeoutException, e:
            sys.stderr.write(" ".join([str(a) for a in e.args]) + "\n")
            sys.stderr.write("Fichier de log : %s\n" % LOG_FICHIER)
            print "Timeout d'execution atteint mais option -w utilisee : sortie en code Warning"
            sys.exit(1)
        except Exception, e:
            if not isinstance(e, SystemExit):
                sys.stderr.write(" ".join([str(a) for a in e.args]) + "\n")
                sys.stderr.write("Fichier de log : %s\n" % LOG_FICHIER)
                sys.exit(ERREUR_FATALE)
            raise


    def realiserExecution(self):
        """
        Exécute la commande attendue par l'appelant, en fonction des paramètres
        fournis initialement au lancement du script.
        Paramètres : Aucun
        Retourne : Rien
        """
        liste_commande = ["/usr/bin/ssh", "-o", "PasswordAuthentication=no", "-o", "BatchMode=yes", "-l", SSH_COMPTE, self.serveur]
        # cmd simple : . $HOME/.profile ; cmd
        # cmd sudoee : . $HOME/.profile ; /usr/bin/sudo -H (-u user) cmd
        # cmd sudoee avec -E : . $HOME/.profile ; /usr/bin/sudo -E (-u user) cmd
        # cmd sudoee avec reinterp : . $HOME/.profile ; /usr/bin/sudo -H (-u user) (script reinterp) cmd
        liste_commande_distante = [". $HOME/.profile ;"]
        compte = self.dict_arguments["compte"]
        if compte is not None:
            liste_commande_distante.append("/usr/bin/sudo")
            if compte != "root":
                liste_commande_distante.append("-u %s" % compte)
            # -E : preserve environment, -H : change home directory
            liste_commande_distante.append(self.dict_arguments["environnement"] and "-E" or "-H")
            delim = self.dict_arguments["delim"]
            if delim is not None:
                liste_commande_distante.append("%s -d %s" % (SSH_SCRIPT_REBUILD, delim))
        liste_commande_distante.append(self.dict_arguments["commande"])
        liste_commande.append(" ".join(liste_commande_distante))
        #print " ".join(["'%s'" % c for c in liste_commande])
        cr, stdout, stderr = self._executerCommande(liste_commande)
        if stderr:
            for ligne in stderr.split("\n"):
                if not ligne.endswith("stdin: is not a tty"):
                    sys.stderr.write("%s\n" % ligne)
        print stdout
        if cr in (ERREUR_WARNING, ERREUR_ARG, ERREUR_FATALE):
            # Sortie en erreur fatale et ajout d'information textuelle pour supprimer l'ambiguïté
            sys.stderr.write("Le code retour de la commande etait %s, sortie en code retour %s " % (cr, ERREUR_FATALE) +
                             "pour eviter la confusion avec les codes retour du script d'execution de commande a distance\n")
            sys.exit(ERREUR_FATALE)
        sys.exit(cr)


    def _executerCommande(self, liste_commande):
        """
        Exécute la commande indiquée, et vérifie le résultat.
        Remonte une exception en cas de code retour différent de 0.
        Il n'est pas nécessaire de protéger les paramètres car le shell n'est pas appelé.
        Paramètres :
            * liste_commande : Liste contenant la commande en premier paramètre, chaque paramètre ensuite
            * exception_si_stderr : Remonte une exception si la sortie d'erreur n'est pas vide
        Retourne : Un tuple contenant dans l'ordre :
            * Le code retour de la commande
            * La sortie standard
            * La sortie d'erreur
        """
        # Lancement dans un thread pour surveiller la bonne exécution
        # (par exemple, la commande peut rester bloquée en attente d'une intervention
        # utilisateur du type "entrez votre mot de passe")
        heure_debut = time.time()
        execution = ThreadExecutionCommande(liste_commande=liste_commande, log=self.log)
        try:
            while execution.enCours():
                # Alarme si la commande n'a pas retourné après un certain temps
                if time.time() - heure_debut > self.timeout:
                    if self.dict_arguments["warning_sur_timeout"]:
                        raise SSHTimeoutException("E03_080: La commande n'a pas retourne apres %s secondes" % self.timeout)
                    raise Exception("E03_080: La commande n'a pas retourne apres %s secondes" % self.timeout)
                time.sleep(1)
            # Exécution terminée, vérification des erreurs
            if execution.enErreur():
                raise Exception("E03_020: Erreur de lancement de la commande")
        except:
            # En cas d'erreur quelconque, on est dans un état inconnu du processus lancé.
            # Donc on le kille, au cas où
            execution.terminer()
            raise
        (code_retour, stdout, stderr) = execution.getResultat()
        if code_retour or stderr:
            self.log.error("Erreur d'exécution : code retour = %s" % code_retour)
            self.log.error("Sortie standard : %s" % stdout)
            self.log.error("Sortie d'erreur : %s" % stderr)
            #raise Exception("E03_030: Erreur d'exécution")
        return (code_retour, stdout, stderr)


    def analyserArguments(self):
        """
        Analyse les arguments fournis en ligne de commande.
        Paramètres : Aucun
        Retourne : Un tuple de deux éléments :
              * Objet dont chaque propriété correspond à une option fournie (ou None si non fournie)
              * La liste des paramètres positionnels
        """
        parser = OptionParser()
        parser.add_option("-s", "--serveur", dest="serveur", help="Serveur d'execution cible", metavar="SERVEUR")
        parser.add_option("-c", "--commande", dest="commande", help="Commande a lancer sur la cible", metavar="CMD")
        parser.add_option("-u", "--user", dest="compte", help="Compte d'execution cible (facultatif)", metavar="USER")
        parser.add_option("-d", "--delim", dest="delim", metavar="DELIM",
                    help="Caractere remplacant '$' pour les variables a interpreter par le compte cible (facultatif)")
        parser.add_option("-t", "--timeout", dest="timeout", metavar="TIMEOUT", default=600, type="int",
                    help="Temps d'attente maximal de fin d'execution en secondes (defaut : 600)")
        parser.add_option("-E", "--environnement", dest="environnement", action="store_true",
                                help="Conserver l'environnement du compte ordonnancement sur la cible (defaut : non)")
        parser.add_option("-w", "--warnontimeout", dest="warning_sur_timeout", action="store_true",
                                help="Sur timeout, ne pas retourner en erreur mais en warning (defaut : non)")
        try:
            retour = parser.parse_args()
        except SystemExit:
            self.log.genererErreur(ERREUR_ARG, "Ligne de commande mal formatee")
        return retour
    
    
    def verifierArguments(self, obj_option, liste_param):
        """
        Vérifie l'intégrité des arguments fournis
        Paramètres : Tuple retourné par analyserArguments()
        Retourne : Un dictionnaire d'arguments simple
        """
        dict_retour = {}
        for arg in ("serveur", "commande", "compte", "environnement", "delim", "timeout", "warning_sur_timeout"):
            dict_retour[arg] = getattr(obj_option, arg, None)
        # Vérification des arguments obligatoires
        for obligatoire in ("serveur", "commande", "timeout"):
            if dict_retour[obligatoire] is None:
                self.log.genererErreur(ERREUR_ARG, "Argument '%s' obligatoire" % obligatoire)
        # Vérification des collisions d'arguments
        if dict_retour["environnement"] is not None:
            if dict_retour["compte"] is None:
                self.log.genererErreur(ERREUR_ARG, "-E ne peut etre utilise que si -u est specifie")
            if dict_retour["delim"] is not None:
                self.log.genererErreur(ERREUR_ARG, "-d ne peut pas etre utilise si -E est specifie")
        if dict_retour["compte"] is None and dict_retour["delim"] is not None:
            self.log.genererErreur(ERREUR_ARG, "-d ne peut etre utilise qu'avec -u")

        return dict_retour
        

class ThreadExecutionCommande(Thread):
    """
    Classe permettant l'exécution asynchrone d'une commande externe.
    La classe fournit une interface minimale pour obtenir le code retour
    de la commande, ses sorties standard et d'erreur, ainsi que son état
    (en cours ou terminée) et ses erreurs d'exécution.
    """

    def __init__(self, liste_commande, log, *args, **kw):
        """
        Paramètres :
            * liste_commande : Commande à lancer sous forme de liste de chaînes de caractères
            * log : Instance de Log.CanalLog
        """
        Thread.__init__(self, *args, **kw)
        self.__lock = RLock()
        self.__liste_commande = liste_commande
        self.log = log
        self.__stdout = None
        self.__stderr = None
        self.__code_retour = None
        self.__erreur_commande = None
        self.__force_fin = False
        self._pid = None
        self.start()

    def run(self):
        """
        Méthode standard de Thread représentant le coeur du thread
        """
        # L'ensemble de la méthode doit gérer elle-même ses erreurs puisqu'elle est threadée
        cmd = " ".join(["'%s'" % c for c in self.__liste_commande])
        self.log.info("Commande lancee : %s" % cmd)
        try:
            try:
                execution = Popen(args=self.__liste_commande, stdin=PIPE, stdout=PIPE, stderr=PIPE)
                self.__lock.acquire()
                self._pid = execution.pid
                self.__erreur_commande = False
                self.__stdout = ""
                self.__stderr = ""
                self.__lock.release()
            except OSError, e:
                self.log.error("Erreur d'execution de la commande : " + " ".join([str(a) for a in e.args]))
                self.__lock.acquire()
                self.__erreur_commande = True
                self.__lock.release()
                return
            # On attend que l'exécution se termine, ou qu'on nous oblige à sortir
            # self.__force_fin est placé à True uniquement en cas de kill du process
            while execution.poll() is None and not self.__force_fin:
                time.sleep(1)
                # On soulage stdout et stderr pour éviter un interblocage lié au remplissage du buffer interne
                rlist, wlist, xlist = select.select([execution.stdout, execution.stderr], [], [], 1)
                if execution.stdout in rlist:
                    self.__lock.acquire()
                    self.log.info("Vidage de stdout pendant l'execution. Longueur avant = %s" % repr(len(self.__stdout)))
                    self.__stdout += os.read(execution.stdout.fileno(), 1048576)
                    self.log.info("Vidage de stdout pendant l'execution. Longueur après = %s" % repr(len(self.__stdout)))
                    self.__lock.release()
                if execution.stderr in rlist:
                    self.__lock.acquire()
                    self.log.info("Vidage de stderr pendant l'execution. Longueur avant = %s" % repr(len(self.__stderr)))
                    self.__stderr += os.read(execution.stderr.fileno(), 1048576)
                    self.log.info("Vidage de stderr pendant l'execution. Longueur après = %s" % repr(len(self.__stderr)))
                    self.__lock.release()
            if self.__force_fin:
                # Process killé, il n'y a rien à en récupérer
                return
            (stdout, stderr) = execution.communicate()
            code_retour = execution.returncode
            self.__lock.acquire()
            self.__stdout += stdout
            self.__stderr += stderr
            self.__code_retour = code_retour
            self.__lock.release()
        except Exception, e:
            self.log.exception("Erreur d'execution de la commande")
            self.__lock.acquire()
            self.__erreur_commande = True
            self.__lock.release()

    def enCours(self):
        """
        Retourne vrai si la commande est toujours en cours d'exécution
        """
        return self.isAlive()

    def enErreur(self):
        """
        Retourne vrai si le lancement de la commande a été un échec
        """
        self.__lock.acquire()
        retour = self.__erreur_commande
        self.__lock.release()
        return retour

    def getResultat(self):
        """
        Retourne le résultat de la commande sous la forme (code_retour, stdout, stderr)
        """
        self.__lock.acquire()
        retour = (self.__code_retour, self.__stdout, self.__stderr)
        self.__lock.release()
        return retour

    def terminer(self):
        """
        Termine abruptement l'exécution par l'envoi d'un SIGTERM
        (à utiliser uniquement au sein d'un traitement d'exception)
        """
        try:
            if self._pid is not None:
                try:
                    self.log.error("Envoi d'un SIGTERM au process %s..." % self._pid)
                    os.kill(self._pid, signal.SIGTERM)
                    time.sleep(1)
                    self.log.error("Envoi d'un SIGKILL au process %s..." % self._pid)
                    os.kill(self._pid, signal.SIGKILL)
                except OSError, e:
                    self.log.error("Erreur a l'envoi du signal, le processus ne doit plus exister")
                    self.log.exception("Details de l'erreur :")
                    pass
        finally:
            self.__force_fin = True


class CacheSudo:
    """
    Classe utilitaire permettant d'interroger les autorisations d'exécution de sudo,
    en local ou sur une machine distante. Les interrogations sont faites de manière
    intelligente, pour éviter les appels multiples.
    Pour interroger sudo, on utilise la commande "sudo -l". Cette commande peut retourner
    des informations différentes selon :
        * la machine d'exécution
        * le compte d'exécution
    """
    @classmethod
    def getInstance(cls, log, timeout):
        """
        Retourne une instance unique de la classe CacheSudo, en la créant
        ou la retournant simplement si elle existe déjà.
        Dans la mesure où l'instance cache beaucoup de choses, il est préférable
        d'en utiliser une seule pour optimiser ce cache.
        Paramètres :
            * log : Instance de Log.CanalLog
            * timeout : Temps en secondes avant abandon
        """
        if getattr(cls, "instance_objet", None) is None:
            cls.instance_objet = CacheSudo(log, timeout)
        return cls.instance_objet


    def __init__(self, log, timeout, **kw):
        """
        L'initialisation lance automatiquement une interrogation locale car peu coûteuse.
        Paramètres :
            * log : Instance de Log.CanalLog
            * timeout : Temps en secondes avant abandon
        """
        self.log = log
        self.timeout = timeout
        #self.__cache_local = self._interrogerSudoLocal()
        self.__cache_distant = {}


    def verifierAutorisationLocale(self, binaire, compte="root"):
        """
        Vérifie que le compte d'exécution actuel a le droit de lancer un sudo
        vers le binaire indiqué, avec les droits du compte indiqué.
        Paramètres :
            * binaire : Binaire qui sera lancé ensuite via sudo (chemin absolu)
            * compte : Compte vers lequel sera lancé ensuite le sudo
        Retourne : Un booléen. Vrai si autorisation.
        """
        if self.__cache_local is None:
            self.__cache_local = self._interrogerSudoLocal()
        return self._verifierAutorisation(binaire=binaire, compte=compte, dict_autorisation=self.__cache_local)


    def verifierAutorisationDistante(self, binaire, compte_ssh, serveur, compte_distant="root", sudo_local="root"):
        """
        Vérifie qu'un compte distant a le droit de lancer le sudo vers le
        binaire indiqué, avec les droits du compte indiqué.
        Paramètres :
            * binaire : Binaire qui sera lancé ensuite via sudo (chemin absolu)
            * compte_ssh : Nom du compte à tester à distance (compte de connexion SSH)
            * serveur : Hostname ou IP du serveur distant
            * compte_distant : Nom du compte cible du sudo
            * sudo_local : Si None, la commande SSH est lancée en direct (sans sudo)
                           Sinon, le compte fourni est utilisé pour faire un sudo ssh
        Retourne : Un booléen. Vrai si autorisation.
        """
        if sudo_local is not None and not self.verifierAutorisationLocale("/usr/bin/ssh", sudo_local):
            raise Exception("E03_120: Pas d'autorisation locale de sudo ssh : verification des autorisations sudo distantes impossible")
        cache = self.__cache_distant.get( (compte_ssh, serveur), None)
        if cache is None:
            cache = self._interrogerSudoDistant(compte_ssh, serveur, sudo_local)
            self.__cache_distant[(compte_ssh, serveur)] = cache
        return self._verifierAutorisation(binaire=binaire, compte=compte_distant, dict_autorisation=cache)


    def _verifierAutorisation(self, binaire, compte, dict_autorisation):
        """
        Analyse les autorisations sudo et détermine si le compte a le droit de lancer la commande indiquée.
        Paramètres :
            * binaire : Binaire qui sera lancé ensuite via sudo (chemin absolu)
            * compte : Compte vers lequel sera lancé ensuite le sudo
            * dict_autorisation : Dictionnaire tel que retourné par les méthodes __interrogerSudo*()
        Retourne : Un booléen. Vrai si autorisation.
        """
        return binaire in dict_autorisation.get(compte, []) or binaire in dict_autorisation.get("ALL", [])


    def _interrogerSudoLocal(self):
        """
        Interroge les autorisations sudo locales. La commande lancée n'est pas
        threadée car elle ne passe pas par le réseau.
        Paramètres : Aucun
        Retourne : Un dictionnaire ; chaque clef représente un compte cible autorisé,
                    chaque valeur est une liste de commandes autorisées en NOPASSWD
                    (une commande n'ayant pas de NOPASSWD n'est pas retenue)
        """
        liste_commande = ["/usr/bin/sudo", "-l"]
        cmd = " ".join(["'%s'" % c for c in liste_commande])
        self.log.info("Interrogation des autorisations sudo locales. Commande lancee : %s" % cmd)
        try:
            try:
                execution = Popen(args=liste_commande, stdin=PIPE, stdout=PIPE, stderr=PIPE)
            except OSError, e:
                self.log.error("Erreur d'execution de la commande : " + " ".join([str(a) for a in e.args]))
                raise Exception("E03_090: Erreur d'interrogation des autorisations sudo locales")
            (stdout, stderr) = execution.communicate()
            code_retour = execution.returncode
            if code_retour or stderr:
                self.log.error("Erreur d'execution de la commande d'interrogation sudo local : code retour = %s" % code_retour)
                self.log.error("Sortie standard : %s" % stdout)
                self.log.error("Sortie d'erreur : %s" % stderr)
                raise Exception("E03_100: Erreur d'interrogation des autorisations sudo locales")
            return self._interpreterSudo(stdout)
        except Exception, e:
            self.log.exception("Erreur d'execution de la commande : " + " ".join([str(a) for a in e.args]))
            raise Exception("E03_110: Erreur d'interrogation des autorisations sudo locales")


    def _interrogerSudoDistant(self, compte_ssh, serveur, sudo_local="root"):
        """
        Interroge les autorisation sudo sur un serveur distant. La commande lancée
        est threadée pour éviter les cas d'attente de saisie utilisateur.
        Paramètres :
            * compte_ssh : Nom du compte à tester à distance (compte de connexion SSH)
            * serveur : Hostname ou IP du serveur distant
            * sudo_local : Si None, la commande SSH est lancée en direct (sans sudo)
                           Sinon, le compte fourni est utilisé pour faire un sudo ssh
        Retourne : Un dictionnaire ; chaque clef représente un compte cible autorisé,
                    chaque valeur est une liste de commandes autorisées en NOPASSWD
                    (une commande n'ayant pas de NOPASSWD n'est pas retenue)
        """
        liste_commande = []
        if sudo_local is not None:
            liste_commande.append("/usr/bin/sudo")
            if sudo_local != "root":
                liste_commande += ["-u", sudo_local]
        liste_commande += [ "/usr/bin/ssh", "-o", "BatchMode=yes", "-o", "PasswordAuthentication=no",
                            "%s@%s" % (compte_ssh, serveur),
                            "/usr/bin/sudo", "-l"
        ]
        cmd = " ".join(["'%s'" % c for c in liste_commande])
        self.log.info("Interrogation des autorisations sudo distantes. Commande lancee : %s" % cmd)
        # Lancement dans un thread pour surveiller la bonne exécution
        # (par exemple, la commande peut rester bloquée en attente d'une intervention
        # utilisateur du type "entrez votre mot de passe")
        heure_debut = time.time()
        execution = ThreadExecutionCommande(log=self.log, liste_commande=liste_commande)
        try:
            while execution.enCours():
                if time.time() - heure_debut > self.timeout:
                    raise Exception("E03_130: Interrogation des autorisations sudo distantes non terminee après %s secondes" % self.timeout)
                time.sleep(1)
            # Exécution terminée, vérification des erreurs
            if execution.enErreur():
                raise Exception("E03_140: Erreur d'interrogation des autorisations de sudo distantes")
        except:
            # En cas d'erreur quelconque, on est dans un état inconnu du processus lancé.
            # Donc on le kille, au cas où
            execution.terminer()
            raise
        (code_retour, stdout, stderr) = execution.getResultat()
        if code_retour or stderr:
            self.log.error("Erreur d'interrogation des autorisations de sudo distantes : code retour = %s" % code_retour)
            self.log.error("Sortie standard : %s" % stdout)
            self.log.error("Sortie d'erreur : %s" % stderr)
            raise Exception("E03_150: Erreur d'interrogation des autorisations de sudo distantes")
        return self._interpreterSudo(stdout)


    def _interpreterSudo(self, stdout):
        """
        Interprète le retour de la commande sudo, et retourne les informations formatées.
        Paramètres :
            * stdout : Sortie standard d'une commande sudo -l
        Retourne : Un dictionnaire ; chaque clef représente un compte cible autorisé,
                    chaque valeur est une liste de commandes autorisées en NOPASSWD
                    (une commande n'ayant pas de NOPASSWD n'est pas retenue)
        """
        # Ligne typique (Ubuntu 8) : (root) NOPASSWD: /usr/bin/rsync
        # Ligne typique (Ubuntu 10) : (root) NOPASSWD: /usr/bin/rsync, (root) /usr/bin/du, (root) /bin/df
        dict_retour = {}
        interpretation = False
        entree = {"modif":None, "compte":None, "commandes":[]}
        for ligne in stdout.split("\n"):
            if not interpretation:
                interpretation = ligne.find("may run the following commands") != -1
                continue
            for mot in ligne.split():
                if entree["modif"] is None:
                    if entree["compte"] is None:
                        entree["compte"] = mot[1:-1]
                        continue
                    entree["modif"] = "PASSWD"
                    if mot.endswith(":"):
                        if mot.find("NOPASSWD") != -1:
                            entree["modif"] = "NOPASSWD"
                        continue
                if mot.startswith("(") and mot.endswith(")"):
                    # Le mot est un rappel du compte cible juste avant le binaire : on l'ignore
                    pass
                else:
                    # Le mot est un binaire qu'on traite
                    fin_entree = not mot.endswith(",")
                    entree["commandes"].append(fin_entree and mot or mot[:-1])
                    if fin_entree:
                        # S'il n'y a pas de virgule, on est à la fin d'une entrée,
                        # on supprime donc les informations "modif" et "compte"
                        if entree["modif"] == "NOPASSWD":
                            compte = entree["compte"]
                            dict_retour[compte] = dict_retour.get(compte, []) + entree["commandes"]
                        entree = {"modif":None, "compte":None, "commandes":[]}
        return dict_retour


if __name__ == "__main__":
    ExecutionSSH()

