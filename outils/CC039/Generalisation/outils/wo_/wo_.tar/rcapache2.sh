#!/bin/ksh

# Fonctions a appeler

# Entete du Script
Entete()
{
echo " ********************************************************************************"
echo " Arret/Redemarrage du service APACHE2 "
echo " rcapache2.sh"
echo " Cible : Apache2"
echo " "
echo " Parametres :  -i instance -a action"
echo " avec instance = www[nn][yyy] par exemple www06001"
echo " avec action ="
echo " start : demarrage de l'instance"
echo " stop : arret  de l'instance"
echo " "
echo " Exemple de commande :"
echo " $WO_OUTIL/rcapache2.sh -i www06001 -a stop"
echo " "
echo " Version 1.0 du 24/04/09 IP"
echo " ********************************************************************************"
echo " "
}


# Usage du script
Usage()
{
  echo " "
  echo "Utilisation du script :"
  echo "-----------------------"
  echo "--> Login : Ce sript est a execute avec le login root"
  echo "--> Usage : $WO_OUTIL/rcapache2.sh -i www[nn][yyy] -a start/stop/startssl"
  echo "-----------------------"
  echo " "
}

# ***************************************
# MAIN
# ***************************************

Entete

echo "Execution de la commande : $0 $*"
echo " "
echo "Resultat :"
echo " "

# Affectation des arguments
# -------------------------
ARGSS="$*"
while getopts "i:a:" OPT
 do
 case ${OPT} in
        i) INSTANCE="${OPTARG}" ;;
        a) ACTION="${OPTARG}" ;;
        *) echo "Erreur : Option non valide "
                Usage
                echo "Sortie du scripte en CR 3"
                exit 3 ;;
 esac
done

# Test des arguments
# ------------------
if [ "$INSTANCE" = "" ]
then
 echo "Erreur : L'option -i n'a pas ete specifiee "
 echo "Le nom de l'instance est obligatoire "
 Usage
 echo "Sortie du script en CR 3"
 exit 3
fi

if [ "$ACTION" = "" ]
then
 echo "Erreur : L'option -a n'a pas ete specifiee"
 echo "L'action start ou stop est obligatoire"
 Usage
 echo "Sortie du script en CR 3"
 exit 3
else
 if [ "$ACTION" != "start" -a "$ACTION" != "stop" -a "$ACTION" != "startssl" ]
 then
  echo "Erreur : L'option -a ne peut prendre comme valeur que start, startssl ou stop"
  Usage
  echo "Sortie du script en CR 3"
  exit 3
 fi
fi

# Execution du script
# -------------------

grep $INSTANCE /etc/passwd
CodeR=$?
if [ "$CodeR" != "0" ]
then
 echo " Erreur : Le login $INSTANCE n'existe pas dans /etc/passwd "
 echo " Erreur : Le nom de votre instance est incorrect"
 echo " Sortie du script en CR 3 "
 exit 3
else
 case $ACTION in
    start)
        su - $INSTANCE -c '/apachedata/'$INSTANCE'/rcapache2 start'
        CodeR=$?
        if [ "$CodeR" = "0" ]
        then
         echo " "
         echo "SUCCES : L'instance Apache2 $INSTANCE a demarre"
         echo "Sortie du Script en CR 0"
         exit 0
        else
         echo " "
         echo "PROBLEME lors du demarrage de l'instance Apache2 $INSTANCE"
         echo "Sortie du script en CR 3"
         exit 3
        fi
 ;;
     stop)
        su - $INSTANCE -c '/apachedata/'$INSTANCE'/rcapache2 stop'
        CodeR=$?
        if [ "$CodeR" = "0" ]
        then
         echo " "
         echo "SUCCES : L'instance Apache2 $INSTANCE est arretee"
         echo "Sortie du Script en CR 0"
         exit 0
        else
         echo " "
         echo "PROBLEME lors de l'arret de l'instance Apache2 $INSTANCE"
         echo "Sortie du script en CR 3"
         exit 3
        fi
 ;;
    startssl)
        su - $INSTANCE -c '/apachedata/'$INSTANCE'/rcapache2 startssl'
        CodeR=$?
        if [ "$CodeR" = "0" ]
        then
         echo " "
         echo "SUCCES : L'instance Apache2 $INSTANCE a demarre avec prise en compte SSL"
         echo "Sortie du Script en CR 0"
         exit 0
        else
         echo " "
         echo "PROBLEME lors du demarrage de l'instance Apache2 $INSTANCE avec prise en compte SSL"
         echo "Sortie du script en CR 3"
         exit 3
        fi
 ;;
 esac
fi

